import os, sys, os, tempfile, re, zlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, search, chunking

store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")

DIM = 256
def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), DIM), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, zlib.crc32(tok.encode()) % DIM] += 1
        n = np.linalg.norm(out[i]); out[i] /= (n or 1)
    if progress: progress(len(texts), len(texts))
    return out, (model_name or "fake-model")
embed.embed_texts = fake_embed

long_para = " ".join(f"Sentence number {i} talks about colligative properties of solutions and osmosis." for i in range(60))
units = [
  {"heading": "1.2 Concentration of Solutions", "level": 2, "path": "1.2 Concentration of Solutions", "page_start": 4, "page_end": 5,
   "paragraphs": [{"page": 4, "text": "Molality is defined as the number of moles of solute per kilogram of solvent."},
                  {"page": 5, "text": "Molarity is the number of moles of solute per litre of solution and changes with temperature."}]},
  {"heading": "1.3.2 Solubility of a Gas in a Liquid", "level": 3, "path": "1.3 Solubility > 1.3.2", "page_start": 7, "page_end": 8,
   "paragraphs": [{"page": 7, "text": "Henry's law states that the solubility of a gas in a liquid is proportional to its partial pressure."}]},
  {"heading": "2.1 Colligative", "level": 2, "path": "2.1 Colligative", "page_start": 10, "page_end": 12,
   "paragraphs": [{"page": 10, "text": long_para}]},
]
for u in units: u["text"] = "\n\n".join(p["text"] for p in u["paragraphs"])

# 1. chunking
items = []
for u in units:
    chunks = chunking.chunk_unit(u)
    items.append({"unit": u, "chunks": chunks})
sizes = [len(c["text"].split()) for c in items[2]["chunks"]]
print("1: chunks per unit:", [len(i["chunks"]) for i in items], "| long unit chunk sizes:", sizes)
assert max(sizes) <= chunking.HARD_WORDS and len(items[2]["chunks"]) >= 3
assert items[0]["chunks"][0]["page_start"] == 4 and items[0]["chunks"][0]["page_end"] == 5

# 2. save + load
texts = [i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]]
vecs, m = fake_embed(texts)
res = store.save_pdf("chem.pdf", 30, items, vecs, m)
print("2:", res, store.list_docs())
rows, matrix, model, skipped = store.load_chunks()
assert len(rows) == res["chunks"] and matrix.shape == (len(rows), DIM) and model == "fake-model"

# 3. search finds the right chunk, with citation info
out = search.search("what is molality", k=3)
top = out["results"][0]
print("3:", top["heading"], "| pages", top["page_start"], "-", top["page_end"], "| found by", top["found_by"],
      "| dense", top["dense"], "| engines", out["dense_engine"], out["keyword_engine"])
assert top["heading"].startswith("1.2") and "molality" in top["text"].lower()
out2 = search.search("partial pressure of a gas Henry", k=2)
assert out2["results"][0]["heading"].startswith("1.3.2"); print("   henry ->", out2["results"][0]["heading"])

# 4. off-topic question has a lower best similarity than an on-topic one
off = search.search("football world cup winners", k=2)
print("4: on-topic best_dense", out["best_dense"], "| off-topic best_dense", off["best_dense"])
assert off["best_dense"] < out["best_dense"]

# 5. saving the same file again replaces it
store.save_pdf("chem.pdf", 30, items, vecs, m)
assert len(store.load_chunks()[0]) == res["chunks"]; print("5: re-save replaces, still", res["chunks"], "chunks")

# 6. chunks made by another model are skipped, not mixed
store.save_pdf("other.pdf", 3, items[:1], vecs[:1], "another-model")
rows, matrix, model, skipped = store.load_chunks()
print("6: using", model, "| skipped", skipped); assert skipped == 1 and model == "fake-model"
print("ALL TESTS PASSED")
