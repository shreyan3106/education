import os, sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_ingest.py")).read().split("r = analyze(pages)")[0])
from src import organize, llm, store
store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")

result = analyze(pages)
print("headings:", [(h["id"], h["level"], h["text"]) for h in result["headings"]])
print("units   :", [(u["heading_id"], u["heading"], len(u["text"].split())) for u in result["units"]])

# 1. apply_edits: remove 'Solution' (id 1) and re-level 'Intext Questions' (id 2) to 3
new = organize.apply_edits(result, {1}, {2: 3})
print("after   :", [(u["heading_id"], u["heading"], u["level"], u["path"]) for u in new["units"]])
ids = [u["heading_id"] for u in new["units"]]
assert 1 not in ids and 1 not in [h["id"] for h in new["headings"]]
ex = [u for u in new["units"] if u["heading"] == "Example 1.3"][0]
assert "Molar mass" in ex["text"], "removed heading's text must be merged into the section above"
assert [u for u in new["units"] if u["heading"] == "Intext Questions"][0]["level"] == 3
assert len(result["units"]) == len(new["units"]) + 1   # original untouched
assert any(u["heading_id"] == 1 for u in result["units"])

# 2. removing the very first heading when nothing is above it
new2 = organize.apply_edits(result, {0}, {})
print("first removed ->", [(u["heading"]) for u in new2["units"]][:3])

# 3. parser: tolerant of chatter, ignores ids outside the batch, ignores text in brackets
rm, lv = organize._parse_cleanup("Remove: 1, 99 (they are labels 2)\nLevels: 2=3, 5=9, 3=2", {0, 1, 2, 3})
print("3:", rm, lv); assert rm == {1} and lv == {2: 3, 3: 2}
assert organize._parse_cleanup("Remove: none\nLevels: none", {0, 1}) == (set(), {})

# 4. clean_headings end to end with a fake model; and the safety guard
def fake_ask(job, messages, max_tokens=1500, **kw):
    return {"text": "Remove: 1\nLevels: 2=3", "model": "x"}
llm.ask = fake_ask
cleaned, note = organize.clean_headings(result)
print("4:", note); assert "removed 1" in note and len(cleaned["units"]) == len(result["units"]) - 1
llm.ask = lambda *a, **k: {"text": "Remove: 0, 1, 2, 3, 4", "model": "x"}
same, note = organize.clean_headings(result); print("   guard:", note); assert same is result
def busy(*a, **k): raise llm.AllModelsBusy("busy")
llm.ask = busy
same, note = organize.clean_headings(result); print("   busy :", note); assert same is result

# 5. tagging: parse model output, map to unit ids, stop softly when the model is unavailable
reply = """Unit 1
Topic: Solubility of gases
Concepts: Henry's law; partial pressure; dissolution
Prerequisites: gas laws

Unit 2
Topic: Concentration
Concepts: molality; molarity
Prerequisites: none
Some chatter"""
organize.MIN_TAG_WORDS = 0
llm.ask = lambda *a, **k: {"text": reply, "model": "x"}
rows = [{"id": 11, "heading": "1.3.2 Gas in liquid", "text": "Henry's law ..."}, {"id": 12, "heading": "1.2 Conc", "text": "molality ..."}]
tags, note = organize.tag_units(rows)
print("5:", tags, repr(note))
assert tags[11]["concepts"][0] == "Henry's law" and tags[12]["prerequisites"] == [] and tags[12]["topic"] == "Concentration"
calls = {"n": 0}
def flaky(*a, **k):
    calls["n"] += 1
    if calls["n"] == 1: return {"text": reply, "model": "x"}
    raise llm.AllModelsBusy("busy")
llm.ask = flaky
many = [{"id": i, "heading": f"H{i}", "text": "text"} for i in range(1, 13)]
tags, note = organize.tag_units(many)
print("   partial:", len(tags), "tagged;", note); assert len(tags) == 2 and "Stopped early" in note
organize.MIN_TAG_WORDS = 25                      # very short units get an empty tag without a model call
llm.ask = lambda *a, **k: (_ for _ in ()).throw(AssertionError("no model call for tiny units"))
tiny, note = organize.tag_units([{"id": 5, "heading": "i i", "text": "a b c"}])
assert tiny == {5: {"topic": "", "concepts": [], "prerequisites": []}} and note == ""
organize.MIN_TAG_WORDS = 0

# 6. storage round trip
items = [{"unit": u, "chunks": [{"text": u["text"] or "x", "page_start": u["page_start"], "page_end": u["page_end"]}]} for u in result["units"][:3]]
import numpy as np
store.save_pdf("t.pdf", 6, items, np.zeros((3, 4), dtype="float32"), "m")
un = store.untagged_units("t.pdf"); assert len(un) == 3
store.save_tags({un[0]["id"]: {"topic": "T", "concepts": ["a", "b"], "prerequisites": ["x"]}})
print("6:", store.tag_table("t.pdf"), "| untagged left:", len(store.untagged_units("t.pdf")))
assert len(store.untagged_units("t.pdf")) == 2
store.delete_doc("t.pdf"); assert store.tag_table("t.pdf") == [] and store.units_for("t.pdf") == []
print("ALL ORGANIZE TESTS PASSED")
