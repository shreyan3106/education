"""Tests for src/benchmark.py with fake models: scoring, ranking, saving the order."""
import os, sys, tempfile, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src import benchmark as bm, llm, fmt, outline, quiz, tutor

tmp = tempfile.mkdtemp()
llm.DB_PATH = os.path.join(tmp, "t.db")
llm.LADDER_FILE = os.path.join(tmp, "ladders.json")

GOOD = ("nvidia", "z-ai/glm-5.3")
MID = ("groq", "openai/gpt-oss-120b")
BAD = ("groq", "openai/gpt-oss-20b")
VIS = ("nvidia", "z-ai/glm-5.3-flash")


def good_reply(system, user):
    if system.startswith("You fix the FORMATTING"):
        return "Force is $F = k\\frac{q_1 q_2}{r^2}$ and the distance $r_{13}$ matters for the vector $\\mathbf{E}$."
    if system.startswith("You sort the structure"):
        out = ["Topics:", "T1 = Electric charge", "T2 = Coulomb's law", "Units:"]
        roles = {1: "title|-", 2: "section|T1", 3: "fragment|T1", 4: "section|T2", 5: "fragment|T2", 6: "example|T2", 7: "exercise|-"}
        return "\n".join(out + [f"{i} | {v.split('|')[0]} | {v.split('|')[1]}" for i, v in roles.items()])
    if system.startswith("You are an exam setter"):
        return ("Q1\nSource: 1\nType: SHORT\nDifficulty: easy\nConcept: law\nQuestion: What does Coulomb's law say about distance?\n\n"
                "Q2\nSource: 1\nType: SHORT\nDifficulty: easy\nConcept: law\nQuestion: When do two point charges repel each other?")
    if system.startswith("You are an exam moderator"):
        return ("Verdict: OK\nEvidence: the electrostatic force between two point charges is directly proportional to the product "
                "of the magnitudes of the charges and inversely proportional to the square of the distance between them\n"
                "Correct: B\nExplanation: Inverse square.\nMistake: thinks it halves.")
    if system.startswith("You grade"):
        return "Verdict: INCORRECT\nFeedback: no" if "mass" in user else "Verdict: CORRECT\nFeedback: yes"
    if system.startswith("You are a study tutor"):
        return "The force is proportional to the product of the charges and inversely proportional to the square of the distance [1]."
    return "a figure with +q1 and -q2 separated by distance r with a force F between the charges"


def fake_ask(job, messages, max_tokens=1500, ladder=None, **kw):
    prov, model = ladder[0]
    system = messages[0]["content"] if messages[0]["role"] == "system" else ""
    user = messages[-1]["content"] if isinstance(messages[-1]["content"], str) else ""
    if (prov, model) == BAD:
        return {"text": "I do not know.", "model": model, "truncated": False}
    if (prov, model) == ("nvidia", "no-such"):
        raise llm.AllModelsBusy("down")
    text = good_reply(system, user)
    if (prov, model) == MID and system.startswith("You grade"):
        text = "Verdict: CORRECT\nFeedback: yes"          # the middle model grades everything as correct
    return {"text": text, "model": model, "truncated": (prov, model) == MID and job == "answer"}
llm.ask = fake_ask

res = bm.run([GOOD, MID, BAD, VIS])
by = {(r["provider"], r["model"]): r for r in res}
g, m, b, v = by[GOOD], by[MID], by[BAD], by[VIS]
assert g["scores"] == {"format": 1.0, "outline": 1.0, "setter": 1.0, "key": 1.0, "grade": 1.0, "tutor": 1.0}, g["scores"]
assert v["scores"]["vision"] == 1.0
assert "vision" not in m["scores"] and "vision" not in g["scores"]                      # only vision models get the picture task
assert m["scores"]["grade"] == 0.5 and m["cut_off"] == 1                             # a lax grader and a cut-off are both seen
assert b["scores"] == {t: 0.0 for t in bm.TASKS_TEXT}
assert bm.quality(g) == 1.0 and bm.quality(b) == 0.0 and bm.quality(g) > bm.quality(m) > bm.quality(b)
print("scores ok:", {k[1]: round(bm.quality(r), 2) for k, r in by.items()})

for r in res:                                                                        # pretend the good model is slow, the middle one fast
    r["seconds"] = {t: (95.0 if (r["provider"], r["model"]) == GOOD else 2.0) for t in r["scores"]}
order = bm.rank(res)
assert [tuple(p) for p in order["key"]][:2] == [MID, VIS] or [tuple(p) for p in order["key"]][0] != GOOD, order["key"]
assert tuple(order["key"][-1]) in (GOOD, BAD) and BAD not in [tuple(p) for p in order["key"]]                 # zero-score model is left out
assert tuple(order["vision"][0]) == VIS and all(p[1] in {m for _, m in llm.LADDERS["vision"]} for p in order["vision"])
assert [tuple(p) for p in order["outline"]] == [VIS, GOOD]                                                    # long-context models only; equal score: faster first
assert all(tuple(p) in {tuple(x) for x in llm.LADDERS["rewrite"]} for p in order["rewrite"])
for r in res:
    r["seconds"] = {t: 2.0 for t in r["scores"]}
order = bm.rank(res)
assert tuple(order["key"][0]) == GOOD                                                                          # fast and best: first
bm.save_order(order)
assert llm.ladder_for("key")[0] == GOOD and llm.ladder_for("grade")[0] == GOOD
bm.clear_order()
assert llm.ladder_for("key") == llm.LADDERS["key"]
rows = bm.table(res)
assert rows[0]["Quality"] == 100 and rows[-1]["Quality"] == 0 and "Total seconds" in rows[0] and "Starts in (s)" in rows[0]
print("ranking, saving and the table ok")
print("ALL BENCHMARK TESTS PASSED")
