"""Tests for src/learner.py: no models, no internet. Checks the maths, the fallbacks and what the model is used for."""
import os, sys, tempfile, re, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, chunking, outline, learner, quiz

store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")
DAY = learner.DAY


def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), 64), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
        out[i] /= (np.linalg.norm(out[i]) or 1)
    return out, "fake-model"


def unit(heading, level, page, text):
    u = {"heading": heading, "level": level, "path": heading, "page_start": page, "page_end": page,
         "paragraphs": [{"page": page, "text": text}]}
    u["text"] = text
    return u


# a small course: a title, four topics, a summary
SPEC = [("Intro to Programming", 1), ("Variables", 2), ("Loops", 2), ("Functions", 2), ("Recursion", 2), ("Summary", 1)]
units = [unit(h, lv, 1 + i, f"{h} " + "text about the idea " * 12) for i, (h, lv) in enumerate(SPEC)]
items = [{"unit": u, "chunks": chunking.chunk_unit(u)} for u in units]
vecs, m = fake_embed([i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]])
store.save_pdf("course.pdf", 10, items, vecs, m)
saved = {u["heading"]: u["id"] for u in store.units_for("course.pdf")}
store.save_tags({saved["Variables"]: {"topic": "t", "concepts": ["variable", "assignment"], "prerequisites": []},
                 saved["Loops"]: {"topic": "t", "concepts": ["for loop", "while loop"], "prerequisites": ["variable"]},
                 saved["Functions"]: {"topic": "t", "concepts": ["function", "parameter"], "prerequisites": ["for loop"]},
                 saved["Recursion"]: {"topic": "t", "concepts": ["recursion"], "prerequisites": ["function", "stack"]}})
outline.ensure_rules("course.pdf")
TOPICS = [t["topic"] for t in outline.topics()]
assert TOPICS == ["Variables", "Loops", "Functions", "Recursion"], TOPICS
T0 = 1_700_000_000.0

# ---------------- 1. BKT (main method) ----------------
p = 0.30
up = learner.bkt_update(p, 1.0, "mcq", "medium")
down = learner.bkt_update(p, 0.0, "mcq", "medium")
half = learner.bkt_update(p, 0.5, "mcq", "medium")
assert down < p < up and down < half < up
assert learner.bkt_update(p, 1.0, "numerical", "medium") > up                 # a lucky guess is rarer: more evidence
assert learner.bkt_update(p, 0.0, "mcq", "hard") > learner.bkt_update(p, 0.0, "mcq", "easy")   # missing a hard one says less
q = p
for _ in range(6):
    q = learner.bkt_update(q, 1.0, "mcq", "medium")
assert q > 0.9
assert 0.02 <= learner.bkt_update(0.98, 0.0, "short", "easy") <= 0.98          # never certain
print("1: BKT ok:", round(up, 3), round(down, 3), round(q, 3))

# ---------------- 2. IRT-style ability (supporting method) ----------------
def ev(score, diff="medium", qtype="mcq", ts=0):
    return {"source": "quiz", "score": score, "difficulty": diff, "qtype": qtype, "ts": ts}
th_good, se_good = learner.irt_theta([ev(1, "hard", "short")] * 4, 0.0)
th_bad, _ = learner.irt_theta([ev(0, "easy", "short")] * 4, 0.0)
assert th_good > 0.8 and th_bad < -0.8 and th_good > th_bad
_, se_few = learner.irt_theta([ev(1)] * 2, 0.0)
_, se_many = learner.irt_theta([ev(1)] * 12, 0.0)
assert se_many < se_few
improving, _ = learner.irt_theta([ev(0)] * 3 + [ev(1)] * 3, 0.0)                # newer answers count more
declining, _ = learner.irt_theta([ev(1)] * 3 + [ev(0)] * 3, 0.0)
assert improving > declining
try:
    learner.irt_theta([], 0.0); raise SystemExit("IRT accepted no data")
except ValueError:
    pass
print("2: IRT ok: theta good/bad", round(th_good, 2), round(th_bad, 2), "se", round(se_few, 2), "->", round(se_many, 2))

# ---------------- 3. spaced repetition (supporting method) ----------------
s1 = learner.sr_step(None, None, T0, 1.0, "medium")
assert abs(s1 - 2.0 * 1.3 * 1.15) < 1e-9
same_session = learner.sr_step(s1, T0, T0 + 600, 1.0, "medium")
assert s1 < same_session < s1 * 1.1                                            # 7 answers in one sitting do not inflate it
after_gap = learner.sr_step(s1, T0, T0 + 4 * DAY, 1.0, "medium")
assert after_gap > s1 * 1.8                                                    # spaced success is worth much more
assert learner.sr_step(s1, T0, T0 + 4 * DAY, 0.0, "medium") < s1 * 0.5
assert learner.sr_step(s1, T0, T0 + 4 * DAY, 0.5, "medium") == s1 * 1.1
r0, r5 = learner.retrievability(s1, T0, T0), learner.retrievability(s1, T0, T0 + 5 * DAY)
assert r0 == 1.0 and 0 < r5 < r0
due = learner.days_until_due(s1, T0, T0)
assert abs(due - s1 * 0.3567) < 0.01 and learner.days_until_due(s1, T0, T0 + 10 * DAY) < 0
assert learner.days_until_due(None, None, T0) is None
print("3: spaced repetition ok: stability", round(s1, 2), "->", round(after_gap, 2), "days; due in", round(due, 2), "days")

# ---------------- 4. combined mastery, fallbacks ----------------
S = "stu"
st0 = learner.topic_state(S, "Loops", T0)
assert not st0["assessed"] and st0["methods"] == "bkt" and st0["confidence"] == "none"
assert abs(st0["mastery"] - learner.NO_INTAKE_PRIOR) < 1e-6
learner.record_answer(S, "Loops", 1.0, "medium", "mcq", 1, now=T0)
st1 = learner.topic_state(S, "Loops", T0)
assert st1["methods"] == "bkt+sr" and st1["n_answers"] == 1 and st1["mastery"] > st0["mastery"]   # one answer: IRT waits
learner.record_answer(S, "Loops", 1.0, "hard", "short", 2, now=T0 + 60)
learner.record_answer(S, "Loops", 1.0, "medium", "numerical", 3, now=T0 + 120)
st3 = learner.topic_state(S, "Loops", T0 + 180)
assert st3["methods"] == "bkt+irt+sr" and st3["theta"] is not None and st3["se"] is not None and st3["confidence"] == "medium"
assert st3["mastery"] > 0.6 and st3["low"] < st3["mastery"] < st3["high"]
later = learner.topic_state(S, "Loops", T0 + 40 * DAY)                         # a month without practice
assert later["mastery"] < st3["mastery"] and later["due_in_days"] < 0 and later["mastery"] >= st3["knowledge"] * 0.6 - 2e-3
# the same answer is never counted twice
assert learner.record_answer(S, "Loops", 0.0, "medium", "mcq", 1, now=T0 + 5) is False
assert learner.topic_state(S, "Loops", T0 + 180)["n_answers"] == 3
# fallback: if the IRT method breaks, BKT and spaced repetition still give a result
real = learner.irt_theta
learner.irt_theta = lambda *a, **k: (_ for _ in ()).throw(ValueError("boom"))
fb = learner.topic_state(S, "Loops", T0 + 180)
learner.irt_theta = real
assert fb["methods"] == "bkt+sr" and 0 < fb["mastery"] < 1
print("4: combined mastery ok:", st0["mastery"], "->", st1["mastery"], "->", st3["mastery"], "| a month later", later["mastery"],
      "| fallback", fb["methods"])

# ---------------- 5. tutor questions are NOT results: counted, but they do not move the number ----------------
before = learner.topic_state("tut", "Functions", T0)
learner.record_tutor("tut", ["Functions", "Functions", "Recursion"], now=T0)
after = learner.topic_state("tut", "Functions", T0)
assert after["n_tutor"] == 1 and not after["assessed"] and after["mastery"] == before["mastery"]
assert learner.event_count("tut") == 0                                         # tutor questions are not "answers"
learner.record_answer("tut", "Functions", 1.0, "medium", "short", 9001, now=T0 + 10)
with_q = learner.topic_state("tut", "Functions", T0 + 20)
learner.record_tutor("tut", ["Functions"], now=T0 + 15)
assert learner.topic_state("tut", "Functions", T0 + 20)["mastery"] == with_q["mastery"]      # still only the quiz answer
print("5: tutor questions are counted but never change mastery:", before["mastery"], "->", after["mastery"])

# ---------------- 6. new students: intake sets the prior ----------------
assert learner.needs_intake("new") and learner.get_profile("new") is None
learner.set_profile("beginner_s", "beginner", "exam", None, now=T0)
learner.set_profile("expert_s", "advanced", "revision", None, now=T0)
mb, ma = learner.topic_state("beginner_s", "Loops", T0)["mastery"], learner.topic_state("expert_s", "Loops", T0)["mastery"]
assert mb < learner.NO_INTAKE_PRIOR < ma and not learner.needs_intake("beginner_s")
print("6: intake prior ok: beginner", mb, "| advanced", ma)

# ---------------- 7. prerequisites from the course's own tags ----------------
pm = learner.prerequisite_map()
assert pm["Loops"] == ["Variables"] and pm["Functions"] == ["Loops"] and pm["Recursion"] == ["Functions"] and pm["Variables"] == []
print("7: prerequisites:", pm)

# ---------------- 8. recommendations ----------------
R = "rec"
learner.set_profile(R, "some", "exam", None, now=T0)
for k in range(6):
    learner.record_answer(R, "Variables", 1.0, "medium", "short", 100 + k, now=T0 + k * 3600)        # strong (six right answers)
for k in range(4):
    learner.record_answer(R, "Functions", 0.0, "medium", "short", 200 + k, now=T0 + k * 3600)        # weak
    learner.record_answer(R, "Loops", 0.0, "medium", "short", 250 + k, now=T0 + k * 3600)            # weak, and Functions builds on it
now = T0 + 30 * DAY                                                          # a month later: Variables is overdue
recs = learner.recommend(R, 4, now)
names = [r["topic"] for r in recs]
assert names[0] == "Loops" and names[1] == "Functions", recs                   # the weak prerequisite is studied first
assert any(r["action"] == "assess" for r in learner.recommend(R, 4, now)) and all(r["reason"] and r["pages"] for r in recs)
assert "builds on Loops" in next(r for r in recs if r["topic"] == "Functions")["reason"]
fn = next(r for r in recs if r["topic"] == "Functions")
assert fn["action"] == "learn" and "Weak" in fn["reason"]
assert any(r["topic"] == "Variables" and r["action"] == "review" for r in learner.recommend(R, 6, now))   # overdue after a month
# an exam within a week raises urgency
learner.set_profile("exam_soon", "some", "exam", time.strftime("%Y-%m-%d", time.gmtime(now + 3 * DAY)), now=now)
learner.record_answer("exam_soon", "Functions", 0.0, "medium", "short", 300, now=now - 100)
learner.record_answer(R, "Functions", 0.0, "medium", "short", 301, now=now - 100)
soon = next(r for r in learner.recommend("exam_soon", 4, now) if r["topic"] == "Functions")
base = next(r for r in learner.recommend(R, 4, now) if r["topic"] == "Functions")
print("8: recommendations:", [(r["topic"], r["action"]) for r in recs], "| urgency", base["priority"], "->", soon["priority"])
assert soon["priority"] > 0

# ---------------- 9. difficulty plan ----------------
good, weak, fresh = "good", "weak", "fresh"
for k in range(6):
    learner.record_answer(good, "Variables", 1.0, "hard", "short", 400 + k, now=T0 + k)
    learner.record_answer(weak, "Variables", 0.0, "easy", "short", 500 + k, now=T0 + k)
pg, pw, pf = (learner.difficulty_plan(x, ["Variables"], 7, T0 + 100) for x in (good, weak, fresh))
for plan in (pg, pw, pf):
    assert plan["easy"] + plan["medium"] + plan["hard"] == 7
assert pg["hard"] > pf["hard"] > pw["hard"] and pw["easy"] > pf["easy"] > pg["easy"], (pg, pf, pw)
print("9: difficulty plans: strong", pg, "| new", pf, "| weak", pw)

# ---------------- 10. tutor guidance ----------------
gw = learner.guidance(R, ["Functions"], now)
assert gw["style"] == "from_basics" and "basics" in gw["note"] and "Adapted" in gw["caption"] and gw["prerequisite"] in (None, "Loops")
gs = learner.guidance(R, ["Variables"], T0 + 6 * 3600)
assert gs["style"] == "concise" and "challenge" in gs["note"], gs
assert learner.guidance("nobody", ["Loops"], now)["caption"] == ""               # nothing known: no adaptation, no caption
assert learner.guidance("beginner_s", ["Loops"], now)["style"] == "from_basics"  # intake only
assert learner.guidance("expert_s", ["Loops"], now)["style"] == "concise"
print("10: guidance:", gw["style"], "|", gs["style"], "|", gw["caption"])

# ---------------- 11. old quiz answers are imported (current topics only) ----------------
conn = quiz._conn()
conn.execute("INSERT INTO quiz_sets (id, kind, scope, wanted, created) VALUES (1, 'topic', 'x', 2, 1)")
conn.execute("INSERT INTO quiz_sets (id, kind, scope, wanted, created) VALUES (2, 'diagnostic', 'x', 2, 1)")
for qid, setid, topic in ((1, 1, "Loops"), (2, 1, "Old noisy tag"), (3, 2, "Functions")):
    conn.execute("INSERT INTO quiz_questions (id, set_id, pos, topic, qtype, difficulty, question) VALUES (?,?,?,?,?,?,?)",
                 (qid, setid, qid, topic, "mcq", "medium", "q"))
    conn.execute("INSERT INTO quiz_answers VALUES (?,?,?,?,?,?,?)", (qid, setid, "A", 1.0, "", "code", T0))
conn.commit(); conn.close()
assert learner.import_quiz_history("old") == 2 and learner.import_quiz_history("old") == 0
assert learner.event_count("old") == 2
print("11: history import ok")

# ---------------- 12. the dashboard list: current topics only, in book order ----------------
states = learner.all_states(R, now)
assert [s["topic"] for s in states] == TOPICS and all("pages" in s and "mastery" in s for s in states)
assert learner.topics_for_units([saved["Loops"], saved["Summary"], 10 ** 9]) == ["Loops"]
learner.reset("old")
assert learner.needs_intake("old") and learner.event_count("old") == 0
assert learner.import_quiz_history("old") == 0                                 # a reset stays reset
learner.reset("rec")
assert learner.needs_intake("rec") and learner.event_count("rec") == 0
print("12: all_states, topics_for_units, reset ok")
# ---------------- 13. one answer is not certainty: shrinkage, evidence and range ----------------
learner.set_profile("one", "some", "x", None, now=T0)
learner.record_answer("one", "Loops", 1.0, "easy", "short", 7001, now=T0)
o = learner.topic_state("one", "Loops", T0 + 60)
assert o["mastery"] < 0.6 and o["evidence"] == "1 of 1 right" and o["high"] - o["low"] > 0.6, o       # was 83% before
learner.set_profile("many", "some", "x", None, now=T0)
for k in range(8):
    learner.record_answer("many", "Loops", 1.0, "medium", "mcq", 7100 + k, now=T0 + k * 60)
mny = learner.topic_state("many", "Loops", T0 + 600)
assert mny["mastery"] > 0.75 and mny["evidence"] == "8 of 8 right" and mny["high"] - mny["low"] < o["high"] - o["low"]
assert 0 <= mny["low"] <= mny["mastery"] <= mny["high"] <= 1
print("13: one answer", o["mastery"], "range", o["low"], "-", o["high"], "| eight answers", mny["mastery"], "range", mny["low"], "-", mny["high"])

# ---------------- 14. every kind of quiz counts, each question once ----------------
learner.set_profile("allq", "some", "x", None, now=T0)
for kind_no, source in enumerate(("quiz", "diagnostic", "quiz")):                # topic quiz, diagnostic, mock exam
    learner.record_answer("allq", "Loops", 1.0, "medium", "mcq", 7200 + kind_no, source=source, now=T0 + kind_no * 600)
assert learner.topic_state("allq", "Loops", T0 + 2000)["n_answers"] == 3
assert learner.record_answer("allq", "Loops", 0.0, "medium", "mcq", 7200, now=T0 + 3000) is False

# ---------------- 15. review dates: never "0 days", a clear phrase, a 12-hour minimum after a mistake ----------------
learner.set_profile("slip", "some", "x", None, now=T0)
learner.record_answer("slip", "Loops", 0.0, "medium", "short", 7300, now=T0)
sl = learner.topic_state("slip", "Loops", T0 + 60)
assert 0.45 <= sl["due_in_days"] <= 0.5, sl["due_in_days"]
assert learner.due_phrase(sl["due_in_days"]) == "in about 12 hours"
assert learner.due_phrase(None) == "-" and learner.due_phrase(-0.2) == "due now" and learner.due_phrase(-3.2) == "overdue by 3 days"
assert learner.due_phrase(0.02) == "within the hour" and learner.due_phrase(0.1) == "in about 2 hours"
assert learner.due_phrase(1.1) == "tomorrow" and learner.due_phrase(3.4) == "in 3 days"
print("15: review dates:", learner.due_phrase(sl["due_in_days"]), "|", learner.due_phrase(1.1), "|", learner.due_phrase(3.4))

# ---------------- 16. study next: mistakes first, thin evidence next, untested last (the 10 Oct screenshot case) ----------------
learner.set_profile("shot", "some", "x", None, now=T0)
learner.record_answer("shot", "Variables", 1.0, "easy", "short", 7400, now=T0)                       # one right answer
for k, sc in enumerate((1, 1, 0, 1, 1)):                                                             # five answers, one wrong
    learner.record_answer("shot", "Loops", float(sc), "medium", "mcq", 7410 + k, now=T0 + 30 * k)
learner.record_answer("shot", "Functions", 1.0, "medium", "short", 7420, now=T0 + 10)               # one right answer
recs = learner.recommend("shot", 4, T0 + 600)
names = [r["topic"] for r in recs]
assert names[0] == "Loops" and recs[0]["action"] == "review" and "retest" in recs[0]["reason"], recs
assert set(names[1:3]) == {"Variables", "Functions"} and all(r["action"] == "assess" and "Too early" in r["reason"] for r in recs[1:3]), recs
assert names[3] == "Recursion" and recs[3]["action"] == "assess" and "not been tested" in recs[3]["reason"]
print("16: study next:", [(r["topic"], r["action"]) for r in recs])

# a topic with a single wrong answer is a clear 'learn', ahead of everything but the weakest
learner.set_profile("miss", "some", "x", None, now=T0)
learner.record_answer("miss", "Loops", 0.0, "medium", "mcq", 7500, now=T0)
r1 = learner.recommend("miss", 2, T0 + 60)[0]
assert r1["topic"] == "Loops" and r1["action"] == "learn" and "missed" in r1["reason"], r1

# ---------------- 17. accuracy check with simulated students whose true knowledge is known ----------------
import random
rng = random.Random(7)
covered, errs = 0, []
levels = [0.1, 0.2, 0.35, 0.5, 0.65, 0.8, 0.9]
for trial in range(70):
    true = levels[trial % len(levels)]
    sid = f"sim{trial}"
    learner.set_profile(sid, "some", "x", None, now=T0)
    for k in range(10):
        qtype = ("mcq", "short", "numerical")[k % 3]
        diff = ("easy", "medium", "hard")[k % 3]
        g = learner.GUESS[qtype]
        slip = learner.SLIP[diff]
        p_right = true * (1 - slip) + (1 - true) * g                      # what the student's true knowledge produces
        learner.record_answer(sid, "Loops", 1.0 if rng.random() < p_right else 0.0, diff, qtype, 8000 + trial * 20 + k, now=T0 + 60 * k)
    est = learner.topic_state(sid, "Loops", T0 + 700)
    errs.append(abs(est["mastery"] - true))
    covered += est["low"] <= true <= est["high"]
mean_err = sum(errs) / len(errs)
assert mean_err < 0.2 and covered / 70 >= 0.75, (mean_err, covered)
ests = [learner.topic_state(f"sim{k}", "Loops", T0 + 700)["mastery"] for k in range(70)]
trues = [levels[k % 7] for k in range(70)]
mx, my = sum(trues) / 70, sum(ests) / 70
corr = (sum((x - mx) * (y - my) for x, y in zip(trues, ests))
        / (sum((x - mx) ** 2 for x in trues) ** 0.5 * sum((y - my) ** 2 for y in ests) ** 0.5))
low = sum(e for e, x in zip(ests, trues) if x <= 0.35) / sum(1 for x in trues if x <= 0.35)
high = sum(e for e, x in zip(ests, trues) if x >= 0.65) / sum(1 for x in trues if x >= 0.65)
assert corr > 0.6 and high - low > 0.25, (corr, low, high)                      # more knowledge -> a clearly higher estimate
by_level = {"correlation": round(corr, 2), "weak students": round(low, 2), "strong students": round(high, 2)}
print("17: simulated students: mean error", round(mean_err, 3), "| true level inside the range", f"{covered}/70", "|", {k: round(v, 2) for k, v in by_level.items()})
print("ALL LEARNER TESTS PASSED")
