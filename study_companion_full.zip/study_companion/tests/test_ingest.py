import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.ingest_pdf import analyze

BODY = ("Bookman-Light", 10.5, 0x231f20)

def span(text, font="Bookman-Light", size=10.5, color=0x231f20, flags=0):
    return {"text": text, "font": font, "size": size, "color": color, "flags": flags}

def line(spans, x, y):
    return {"spans": spans, "bbox": (x, y, x + 100, y + 10)}

def block(lines):
    xs = [l["bbox"][0] for l in lines]; ys = [l["bbox"][1] for l in lines]
    return {"type": 0, "lines": lines, "bbox": (min(xs), min(ys), min(xs)+100, max(ys)+10)}

def para(text_lines, x=65, y=65):
    return block([line([span(t)], x, y + 13 * i) for i, t in enumerate(text_lines)])

def heading(text, y, x=20, font="Bookman-Demi", size=10.5, color=0x6d6f71, copies=1):
    return [block([line([span(text, font, size, color)], x, y)]) for _ in range(copies)]

def footer(page_no, name):
    return [block([line([span(str(page_no), size=9.5, color=0x6d6f71)], 60, 708)]),
            block([line([span(name, size=9.5, color=0x6d6f71)], 90, 708)]),
            block([line([span("Reprint 2026-27", "Arial", 8.0, 0)], 250, 762)])]

pages = []
for n in range(1, 7):
    blocks = footer(n, "Solutions" if n % 2 else "Chemistry")
    if n == 5:
        blocks += heading("1.3 Solubility", 617, x=60, font="BallroomTango", size=14.0, color=0x231f20, copies=5)
        blocks += [para(["Solubility of a substance is its maximum amount", "that can be dissolved in a specified amount."], y=620)]
        blocks += heading("Example 1.3", 240, font="BallroomTango", size=13.0, color=0x00aeef, copies=5)
        blocks += [block([line([span("Calculate molality of 2.5 g of ethanoic acid (CH")], 65, 243),
                          line([span("3", size=6.8)], 65, 250),
                          line([span("COOH) in 75 g of benzene.")], 65, 243+8)])]
        blocks += heading("Solution", 266, font="BallroomTango", size=13.0, color=0x00aeef, copies=5)
        blocks += [para(["Molar mass of C2H4O2 = 60 g per mol"], y=268)]
        blocks += heading("Intext Questions", 413, font="BallroomTango", size=13.0, copies=5)
        blocks += [block([line([span("1.1", "Bookman-Demi"), span(" Calculate the mass percentage of benzene")], 65, 435)])]
    if n == 6:
        blocks += [para(["Every solid does not dissolve in a given liquid.", "Polar solutes dissolve in polar solvents."], y=65)]
        blocks += heading("1.3.1 Solubility of a Solid in a Liquid", 66, x=10)
        blocks += [para(["Pressure does not have any significant effect on solubility", "of solids in liquids."], y=599)]
        blocks += [block([line([span("Effect of temperature", "BookmanOldStyle,BoldItal", 9.5, 0x6d6f71, 16)], 65, 476)])]
        blocks += [para(["The solubility of a solid in a liquid is significantly affected."], y=490)]
        blocks += heading("1.3.2 Solubility of a Gas in a Liquid", 646, x=10)
        blocks += [para(["Many gases dissolve in water. Oxygen dissolves only to a small extent", "in water."], y=646)]
        blocks += [block([line([span("Fig. 1.1:", "Bookman-DemiItalic", 9.5), span(" Effect of pressure on the solubility of a gas. The concentration is proportional.", "Bookman-LightItalic", 9.5)], 378, 378)])]
    if n in (1, 2, 3, 4):
        blocks += [para([f"Filler paragraph on page {n} that is long enough to be body text.", "Second line of filler text for the body style."], y=100 + n)]
        blocks += [para(["More filler body text so the body style is the most common one."], y=200)]
    pages.append({"number": n, "height": 783.0, "blocks": blocks})

r = analyze(pages)
print("body:", r["body_style"])
print("dropped:", r["dropped"][:4], "... total", len(r["dropped"]))
print("HEADINGS")
for h in r["headings"]:
    print("  ", "  " * (h["level"]-1), h["text"], "| p", h["page"], "| score", h["score"])
print("UNITS")
for u in r["units"]:
    print("-", u["heading"], "|", u["path"], "| pages", u["page_start"], u["page_end"])
    print("    ", u["text"][:140].replace("\n", " / "))
