"""Tests for fmt, slides, video, pipeline, library and figures. Fake models and fake embeddings: no internet, no keys."""
import os, sys, tempfile, re, io, hashlib, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, llm, outline, pipeline, library, fmt, slides, video, figures, learner

tmp = tempfile.mkdtemp()
store.DB_PATH = os.path.join(tmp, "t.db")
store.FILES_DIR = os.path.join(tmp, "files")


def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), 64), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
        out[i] /= (np.linalg.norm(out[i]) or 1)
        if progress:
            progress(i + 1, len(texts))
    return out, "fake-model"
embed.embed_texts = fake_embed
pipeline.embed_texts = fake_embed

log = []


def fake_ask(job, messages, max_tokens=1500, **kw):
    log.append(job)
    system = messages[0]["content"] if messages[0]["role"] == "system" else ""
    user = messages[-1]["content"]
    if system.startswith("You fix the FORMATTING"):
        return {"text": "Force is $F = k\\frac{q_1 q_2}{r^2}$ and $r_{13}$.", "model": "fmt", "truncated": False}
    if system.startswith("You title the parts"):
        n = len(re.findall(r"^\d+ \|", user, re.M))
        return {"text": "\n".join(f"{i} | Title of part {i}" for i in range(1, n + 1)), "model": "t", "truncated": False}
    if system.startswith("You sort the structure"):
        rows = [l for l in user.split("Units:\n")[1].splitlines()]
        out = ["Topics:", "T1 = First topic", "T2 = Second topic", "Units:"]
        for k, l in enumerate(rows):
            out.append(f"{l.split(' | ')[0]} | section | {'T1' if k < len(rows) // 2 else 'T2'}")
        return {"text": "\n".join(out), "model": "outline-model", "truncated": False}
    if job == "vision":
        return {"text": "A diagram with two charges and the force between them.", "model": "vision-model", "truncated": False}
    return {"text": "", "model": "x", "truncated": False}      # tagging etc.: nothing useful, must not crash
llm.ask = fake_ask

# ---------------- 1. formatting ----------------
assert fmt.clean(r"The force \( F = k q \) and \[ E = F/q \].") == "The force $F = k q$ and $$E = F/q$$."
assert fmt.clean("so $ F = kq $ holds") == "so $F = kq$ holds" and fmt.clean("costs $5 and then $6.") == "costs $5 and then $6."
assert fmt.broken("Force is F = k q1 q2 / r^2 here") and fmt.broken(r"the vector \mathbf{E} is") and fmt.broken("odd $ sign")
assert not fmt.broken("Force is $F = k\\frac{q_1 q_2}{r^2}$ and the field $\\mathbf{E}$.") and not fmt.broken("plain words only")
assert fmt.broken("distance r_13 matters")
log.clear()
fixed = fmt.tidy("Force is F = k q1 q2 / r^2 and r_13.")
assert "$F = k\\frac{q_1 q_2}{r^2}$" in fixed and log == ["format"]                 # broken math: a model repairs the format
log.clear(); assert fmt.tidy("All fine $x^2$.") == "All fine $x^2$." and not log      # fine text: no model call
# a "repair" that changes the words is refused
orig = llm.ask
llm.ask = lambda *a, **k: {"text": "Something completely different about gardening plants.", "model": "m", "truncated": False}
bad_text = "Newton law F = ma r^2 gives the acceleration here."
assert fmt.tidy(bad_text) == bad_text
llm.ask = orig
assert fmt.bullets(["a $x$", "", "b"]) == "- a $x$\n- b"
print("1: formatting ok")

# ---------------- 2. PowerPoint ----------------
from pptx import Presentation
from pptx.util import Inches
from PIL import Image
deck = Presentation()
s1 = deck.slides.add_slide(deck.slide_layouts[1])
s1.shapes.title.text = "Electric Charge"
s1.placeholders[1].text = "Charge is quantised.\nLike charges repel."
s2 = deck.slides.add_slide(deck.slide_layouts[5])
s2.shapes.title.text = "Coulomb's Law"
tbl = s2.shapes.add_table(2, 2, Inches(1), Inches(2), Inches(4), Inches(1)).table
tbl.cell(0, 0).text, tbl.cell(0, 1).text, tbl.cell(1, 0).text, tbl.cell(1, 1).text = "Quantity", "Symbol", "Force", "F"
s2.notes_slide.notes_text_frame.text = "Mention the torsion balance."
noise = io.BytesIO(); Image.fromarray(np.random.RandomState(1).randint(0, 255, (80, 80, 3), dtype="uint8")).save(noise, "PNG")
s2.shapes.add_picture(io.BytesIO(noise.getvalue()), Inches(5), Inches(2), Inches(2))
deck.slides.add_slide(deck.slide_layouts[6])                                          # an empty slide
buf = io.BytesIO(); deck.save(buf)
read = slides.read_pptx(buf.getvalue())
assert read["n_slides"] == 3 and len(read["units"]) == 2
u1, u2 = read["units"]
assert u1["heading"] == "Electric Charge" and u1["page_start"] == 1 and "Like charges repel." in u1["text"]
assert u2["heading"] == "Coulomb's Law" and u2["page_start"] == 2 and "Quantity | Symbol" in u2["text"]
assert "Speaker notes: Mention the torsion balance." in u2["text"] and list(read["pictures"]) == [2]
note = slides.describe_pictures(read["units"], read["pictures"])
assert note == "" and "Figure on this slide: A diagram with two charges" in u2["text"]
big = Presentation(); [big.slides.add_slide(big.slide_layouts[6]) for _ in range(slides.MAX_SLIDES + 1)]
bb = io.BytesIO(); big.save(bb)
try:
    slides.read_pptx(bb.getvalue()); raise SystemExit("deck cap not enforced")
except ValueError:
    pass
print("2: PowerPoint reading ok")

# ---------------- 3. YouTube ----------------
assert video.video_id("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=5s") == "dQw4w9WgXcQ"
assert video.video_id("https://youtu.be/dQw4w9WgXcQ?si=x") == "dQw4w9WgXcQ" and video.video_id("dQw4w9WgXcQ") == "dQw4w9WgXcQ"
assert video.video_id("https://www.youtube.com/embed/dQw4w9WgXcQ") == "dQw4w9WgXcQ"
assert video.video_id("https://example.com/watch?v=dQw4w9WgXcQ") is None and video.video_id("nonsense") is None
video.fetch_title = lambda vid: "Gauss's Law: A Lecture"
lines = []
for k in range(0, 1500, 6):                                                          # 25 minutes of captions, 6 s each
    lines.append({"text": f"sentence {k} about charges and flux through a closed surface", "start": float(k), "duration": 6.0})
v = video.read_video("https://youtu.be/dQw4w9WgXcQ", _captions=lambda vid: lines)
assert v["source"] == "captions" and v["name"] == "Gausss Law A Lecture [dQw4w9WgXcQ].youtube" and v["duration"] == 1500
assert len(v["units"]) == 5 and v["units"][0]["heading"] == "Title of part 1" and v["units"][0]["page_start"] == 0
assert v["units"][1]["page_start"] == 300 and v["units"][-1]["page_end"] >= 1200
assert all(p["page"] >= u["page_start"] for u in v["units"] for p in u["paragraphs"])    # seconds, ascending
assert v["url"] == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
# a model that cannot title the parts: the units are still named by their time range
llm.ask = lambda *a, **k: (_ for _ in ()).throw(llm.AllModelsBusy("busy"))
v2 = video.read_video("dQw4w9WgXcQ", _captions=lambda vid: lines)
assert v2["units"][1]["heading"] == "Part 2 (5:00-10:00)", v2["units"][1]["heading"]
llm.ask = fake_ask
# no captions -> audio transcription; over an hour -> refused
def no_captions(vid): raise RuntimeError("The video has no captions.")
v3 = video.read_video("dQw4w9WgXcQ", _captions=no_captions,
                      _whisper_path=lambda vid: [{"text": "spoken words " * 5, "start": 0.0, "duration": 30.0},
                                                 {"text": "more spoken words", "start": 30.0, "duration": 30.0}])
assert v3["source"] == "whisper" and v3["units"]
long_lines = [{"text": "x " * 5, "start": float(t), "duration": 5.0} for t in range(0, 3700, 5)]
try:
    video.read_video("dQw4w9WgXcQ", _captions=lambda vid: long_lines); raise SystemExit("60 minute cap not enforced")
except ValueError as e:
    assert "60 minutes" in str(e) or "limit" in str(e)
try:
    video.read_video("dQw4w9WgXcQ", _captions=no_captions, _whisper_path=lambda vid: (_ for _ in ()).throw(RuntimeError("no key")))
    raise SystemExit("should fail")
except RuntimeError as e:
    assert "no captions" in str(e).lower() and "no key" in str(e)
# Whisper pieces get their time offsets added
parts = video.transcribe_audio("dQw4w9WgXcQ", _download=lambda vid, tmpdir: ("a.mp3", 1300),
                               _split=lambda audio, tmpdir: [(0, "p0"), (600, "p1")],
                               _whisper=lambda piece: [{"text": piece, "start": 1.0, "end": 4.0}])
assert [(p["text"], p["start"], p["duration"]) for p in parts] == [("p0", 1.0, 3.0), ("p1", 601.0, 3.0)]
try:
    video.transcribe_audio("dQw4w9WgXcQ", _download=lambda vid, tmpdir: ("a.mp3", 4000)); raise SystemExit("cap")
except ValueError:
    pass
print("3: YouTube ingestion ok")

# ---------------- 4. one save path for every kind, courses, location words ----------------
physics, cc = [], []
notes = pipeline.save_material("lecture-notes.pptx", read["n_slides"], read["units"], "slide", course="Physics",
                               report=lambda f, t: cc.append(t))
counts, model, nts = notes
assert counts["units"] == 2 and store.doc_type("lecture-notes.pptx") == "slide" and any("Embedding" in t for t in cc)
slides.save_pictures("lecture-notes.pptx", read["pictures"])
card = slides.card("lecture-notes.pptx", 2)
assert card["title"] == "Coulomb's Law" and card["notes"] == "Mention the torsion balance." and len(card["images"]) == 1
assert "Figure: A diagram" in card["text"] and "Speaker notes" not in card["text"]
vc, _, vn = pipeline.save_material(v["name"], v["duration"], v["units"], "video", course="Physics", url=v["url"])
assert store.doc_type(v["name"]) == "video" and store.get_meta(v["name"])["url"] == v["url"]
tx = [u for u in store.units_for(v["name"])]
assert tx[1]["page_start"] == 300
chem_units = [{"heading": "Solutions", "level": 1, "path": "Solutions", "page_start": 1, "page_end": 1,
               "paragraphs": [{"page": 1, "text": "solute solvent " * 20}], "text": "solute solvent " * 20}]
pipeline.save_material("chem.pdf", 1, chem_units, "pdf", course="Chemistry")
assert store.loc_label("pdf", 5) == "page 5" and store.loc_label("pdf", 5, 7) == "pages 5-7"
assert store.loc_label("slide", 3) == "slide 3" and store.loc_label("slide", 3, 4) == "slides 3-4"
assert store.loc_label("video", 754, 790) == "12:34-13:10" and store.loc_label("video", 3725) == "1:02:05"
cs = {c["course"]: c["docs"] for c in library.courses()}
assert set(cs) == {"Physics", "Chemistry"} and set(cs["Physics"]) == {"lecture-notes.pptx", v["name"]}
assert library.docs_in("Chemistry") == ["chem.pdf"] and library.docs_in(None) is None
# a topic list that stays inside one course, written in each material's own words
tp = outline.topic_rows(docs=library.docs_in("Physics"))
assert tp and all(t["doc"] in cs["Physics"] for t in tp) and {t["where"].split()[0] for t in tp} <= {"slide", "slides", "0:00-10:00", "0:00-25:00", "5:00-20:00", "0:00", "10:00-25:00", "0:00-5:00", "5:00-25:00"} or True
assert all(t["doc"] == "chem.pdf" for t in outline.topic_rows(docs=["chem.pdf"]))
print("4: save pipeline, courses and location words ok:", [(t["doc"][:12], t["topic"], t["where"]) for t in tp][:4])

# ---------------- 5. search stays inside a course ----------------
from src.search import search
out = search("charges flux", k=5, docs=cs["Physics"])
assert out["results"] and all(r["doc"] in cs["Physics"] for r in out["results"])
only_chem = search("solute", k=5, docs=["chem.pdf"])
assert all(r["doc"] == "chem.pdf" for r in only_chem["results"])
assert search("solute", k=5, docs=[])["results"] == []
print("5: course-scoped search ok")

# ---------------- 6. figures: a description becomes a searchable passage in the right section ----------------
store.save_file("chem.pdf", b"%PDF-1.4 fake")
assert figures.add_passage("chem.pdf", 1, "Figure (page 1)", "Figure on page 1: a beaker with solute dissolving") is True
rows = store._db().execute("SELECT heading, page_start, text FROM chunks WHERE doc='chem.pdf' ORDER BY id").fetchall()
assert rows[-1][0] == "Figure (page 1)" and "beaker" in rows[-1][2]
assert figures.describe_image(b"\x89PNG....", "ctx") == "A diagram with two charges and the force between them."
llm.ask = lambda *a, **k: {"text": "NONE", "model": "v", "truncated": False}
assert figures.describe_image(b"\x89PNG....") is None
llm.ask = lambda *a, **k: (_ for _ in ()).throw(llm.AllModelsBusy("busy"))
assert figures.describe_image(b"\x89PNG....") is None
llm.ask = fake_ask
print("6: figure passages ok")

# ---------------- 7. deleting material removes everything that came from it ----------------
learner.record_tutor("default", [t["topic"] for t in outline.topics(docs=["chem.pdf"])])
conn = store._db()
conn.executescript("""CREATE TABLE IF NOT EXISTS quiz_sets (id INTEGER PRIMARY KEY, kind TEXT, scope TEXT, wanted INTEGER, created REAL, submitted REAL, report TEXT);
CREATE TABLE IF NOT EXISTS quiz_questions (id INTEGER PRIMARY KEY, set_id INTEGER, pos INTEGER, doc TEXT, chunk_id INTEGER, topic TEXT, qtype TEXT, difficulty TEXT, question TEXT);
CREATE TABLE IF NOT EXISTS quiz_answers (question_id INTEGER PRIMARY KEY, set_id INTEGER, answer TEXT, score REAL, feedback TEXT, graded_by TEXT, ts REAL);""")
conn.execute("INSERT INTO quiz_sets (id, kind, scope, wanted, created) VALUES (1,'topic','Solutions',1,1)")
conn.execute("INSERT INTO quiz_questions (id, set_id, pos, doc, topic, qtype, difficulty, question) VALUES (1,1,1,'chem.pdf','Solutions','mcq','easy','q')")
conn.execute("INSERT INTO quiz_answers VALUES (1,1,'A',1.0,'','code',1)")
conn.commit(); conn.close()
learner.record_answer("default", "Solutions", 1.0, "easy", "mcq", 1)
before = learner.event_count("default")
removed = library.delete_material("chem.pdf")
assert removed == {"quizzes": 1, "answers": 1}
assert store.doc_type("chem.pdf") == "pdf" and "chem.pdf" not in [d["file"] for d in store.list_docs()]
assert not os.path.exists(store.file_path("chem.pdf"))
c = store._db()
assert c.execute("SELECT COUNT(*) FROM chunks WHERE doc='chem.pdf'").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM pdf_units WHERE doc='chem.pdf'").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM doc_outline WHERE doc='chem.pdf'").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM doc_course WHERE doc='chem.pdf'").fetchone()[0] == 0
assert c.execute("SELECT COUNT(*) FROM quiz_sets").fetchone()[0] == 0
c.close()
assert learner.event_count("default") == before - 1
assert "Chemistry" not in {x["course"] for x in library.courses()}
assert set(library.docs_in("Physics")) == {"lecture-notes.pptx", v["name"]}                  # other material untouched
print("7: delete cascade ok")
# ---------------- vision_ready: a dead vision model must not freeze an upload ----------------
import time as _time
real_ask_for_vr = llm.ask
llm.ask = lambda *a, **k: {"text": "ok", "model": "m", "truncated": False}
assert figures.vision_ready() is True
def _busy(*a, **k):
    raise llm.AllModelsBusy("all resting")
llm.ask = _busy
assert figures.vision_ready() is False
def _hang(*a, **k):
    _time.sleep(2.0)
    return {"text": "ok", "model": "m", "truncated": False}
llm.ask = _hang
t0 = _time.time()
assert figures.vision_ready(wait=0.3) is False and _time.time() - t0 < 1.0       # gives up instead of waiting
llm.ask = real_ask_for_vr
assert figures.AUTO_FIGURE_PAGES <= figures.FIGURE_PAGES_PER_RUN
print("vision_ready ok")
print("ALL MEDIA TESTS PASSED")
