# Run this ONCE in the terminal:  python download_embedding_model.py
# It downloads the small embedding model and shows a progress bar, so the
# app does not have to do it while the page looks frozen.
from sentence_transformers import SentenceTransformer

name = "BAAI/bge-small-en-v1.5"
print("Downloading", name, "...")
model = SentenceTransformer(name)
print("Done. Test:", model.encode(["molality"]).shape)