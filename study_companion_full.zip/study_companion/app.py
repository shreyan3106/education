import streamlit as st

from src import benchmark, figures, learner, library, outline, pipeline, slides, store, video, viewer
from src.ingest_pdf import MAX_PAGES, extract_units
from src.learner_ui import render_dashboard
from src.llm import AllModelsBusy, all_models, ask, parse_labeled_lines, usage_summary
from src.organize import clean_headings
from src.search import search
from src.store import list_docs
from src.tutor import answer_outside, answer_question
from src.quiz_ui import render_quiz_tab

st.set_page_config(page_title="Study Companion", layout="wide")
st.title("Study Companion")

st.session_state.setdefault("ingest_errors", {})
st.session_state.setdefault("chats", {})                # one chat per course
st.session_state.setdefault("ingest_notes", {})
st.session_state.setdefault("uploader_n", 0)
st.session_state.setdefault("course", None)
st.session_state.setdefault("adopted", set())


@st.cache_data(show_spinner="Reading the PDF...")
def read_pdf(pdf_bytes):
    return extract_units(pdf_bytes)


def report_bar(bar):
    """A progress callback for the pipeline that moves a Streamlit progress bar."""
    def report(fraction, text):
        bar.progress(min(max(fraction, 0.0), 1.0), text=text)
    return report


# =====================================================================
# Sidebar: choose a course, or create one
# =====================================================================
st.sidebar.header("Courses")
known = library.courses()
names = [c["course"] for c in known]
if "_select_course" in st.session_state:                       # set after creating or renaming: jump to that course
    st.session_state["course_choice"] = st.session_state.pop("_select_course")
if names and st.session_state.get("course_choice") not in names:
    st.session_state["course_choice"] = names[0]
choice = None
if names:
    choice = st.sidebar.selectbox("Study this course", names, key="course_choice",
                                  help="The tutor, the quizzes, the dashboard and your progress stay inside the course you pick.")

with st.sidebar.expander("Create a new course", expanded=not names):
    with st.form("new_course_form", clear_on_submit=True):
        nc_name = st.text_input("Course name", placeholder="for example: UPSC Polity, or Semester 1")
        nc_desc = st.text_area("What is it for? (optional)", height=70,
                               placeholder="for example: CDS exam preparation, all subjects")
        nc_instr = st.text_area("Instructions for the tutor (optional)", height=90,
                                placeholder="for example: explain simply, give examples from daily life")
        if st.form_submit_button("Create course"):
            try:
                created = library.create_course(nc_name, nc_desc, nc_instr)
                st.session_state["_select_course"] = created["course"]
                st.rerun()
            except ValueError as e:
                st.error(str(e))

course = choice
course_info = library.get_course(course) if course else None
course_docs = course_info["docs"] if course_info else []
course_instructions = course_info["instructions"] if course_info else ""
st.session_state["course"] = course                                  # read by the other tabs
learner.set_current_student(library.student_for(course))             # every course has its own progress
if course and course not in st.session_state.adopted:                # progress saved before courses were separate
    library.adopt_legacy(course)
    st.session_state.adopted.add(course)
if st.session_state.get("_active_course") != course:                 # another course: forget the open quiz
    for key in [k for k in st.session_state if k.startswith("quiz_")]:
        st.session_state.pop(key, None)
    st.session_state["_active_course"] = course
if course_info:
    st.sidebar.caption(f"{len(course_docs)} material(s) in this course" if course_docs else "No material in this course yet: add some in the Course tab.")


# =====================================================================
# Adding material (PDF, slides, video) into the chosen course
# =====================================================================
def process_uploads(files, target):
    """Save every new file into the course automatically: nothing to press. Returns True if something was saved."""
    saved_names = {d["file"] for d in list_docs()}
    errors = st.session_state.ingest_errors
    changed = False
    for f in files or []:
        name = f.name
        if name in saved_names or name in errors:
            continue
        bar = st.progress(0.0, text=f"Reading {name}...")
        report = report_bar(bar)
        try:
            if name.lower().endswith(".pdf"):
                data = f.getvalue()
                result = read_pdf(data)
                notes = []
                report(0.05, "Cleaning up headings with a language model...")
                result, clean_note = clean_headings(result)
                if clean_note:
                    notes.append(clean_note)
                scans = []
                try:
                    scans = figures.scanned_pages(data)
                except Exception:
                    pass
                if scans:                                    # pages with no text layer are read by a vision model
                    report(0.06, f"{len(scans)} scanned pages: a vision model is reading them...")
                    extra, note = figures.ocr_units(
                        data, scans, progress=lambda d, t: report(0.06 + 0.03 * d / max(t, 1), f"Reading scanned page {d} of {t}"))
                    result = dict(result)
                    result["units"] = sorted(list(result["units"]) + extra, key=lambda u: u["page_start"])
                    notes.append(note)
                counts, model, notes = pipeline.save_material(name, result["n_pages"], result["units"], "pdf",
                                                              course=target, file_bytes=data, report=report, notes=notes)
                try:                                         # figures are read automatically: nothing to press
                    report(0.97, "Checking for a vision model to read the figures...")
                    if figures.vision_ready():
                        report(0.98, "A vision model is describing the figures...")
                        _, figure_note = figures.describe_pdf_figures(
                            name, limit=figures.AUTO_FIGURE_PAGES,
                            progress=lambda a_, b_: report(0.98 + 0.02 * a_ / max(b_, 1), f"Describing figure page {a_} of {b_}..."))
                        notes = list(notes) + [figure_note]
                    else:
                        notes = list(notes) + ["Figures were not read: no vision model answered. Fix it in the Settings, "
                                               "Model check tab, then press 'Describe figures' on this file."]
                except Exception as e:
                    notes = list(notes) + [f"Figures were skipped: {e}"]
            else:
                read = slides.read_pptx(f.getvalue())
                notes = []
                if read["pictures"]:
                    report(0.05, "A vision model is describing the pictures on the slides...")
                    note = slides.describe_pictures(read["units"], read["pictures"])
                    if note:
                        notes.append(note)
                slides.save_pictures(name, read["pictures"])
                counts, model, notes = pipeline.save_material(name, read["n_slides"], read["units"], "slide",
                                                              course=target, file_bytes=f.getvalue(), report=report, notes=notes)
            st.session_state.ingest_notes[name] = notes
            changed = True
        except Exception as e:
            errors[name] = str(e)
        bar.empty()
    return changed


def process_video(link, target):
    bar = st.progress(0.0, text="Fetching the video transcript...")
    report = report_bar(bar)
    try:
        v = video.read_video(link.strip())
        if v["name"] in {d["file"] for d in list_docs()}:
            bar.empty()
            st.info("This video is already saved.")
            return False
        report(0.08, f"Transcript ready ({v['source']}). Saving...")
        _, _, notes = pipeline.save_material(v["name"], v["duration"], v["units"], "video", course=target,
                                             url=v["url"], report=report)
        st.session_state.ingest_notes[v["name"]] = notes
        bar.empty()
        return True
    except Exception as e:
        bar.empty()
        st.error(f"Could not add this video: {e}")
        return False


# =====================================================================
# Tabs
# =====================================================================
tab_course, tab_chat, tab_kb, tab_quiz, tab_dash, tab_models = st.tabs(
    ["Course", "Tutor chat", "Knowledge base", "Quiz", "Dashboard", "Model check"])
KINDS = {"pdf": "PDF", "slide": "Slides", "video": "Video"}

# =====================================================================
# Course: settings, material, adding material
# =====================================================================
with tab_course:
    if not course_info:
        st.info("Create your first course in the sidebar (a name is enough), then add your material here. "
                "A course can hold one subject or many: you decide its scope.")
    else:
        st.header(course)
        if course_info["description"]:
            st.write(course_info["description"])
        if course_instructions:
            st.caption("Tutor instructions: " + course_instructions)

        # ---- add material ----
        st.subheader("Add material")
        files = st.file_uploader("PDF textbook or PowerPoint slides", type=["pdf", "pptx"], accept_multiple_files=True,
                                 key=f"uploader-{st.session_state.uploader_n}-{course_info['id']}",
                                 help=f"A PDF can have up to {MAX_PAGES} pages. Everything you add lands in this course.")
        c_link, c_btn = st.columns([4, 1])
        youtube_link = c_link.text_input("Or a YouTube link (up to 60 minutes)", key=f"yt_link-{course_info['id']}")
        add_video = c_btn.button("Add this video", disabled=not youtube_link.strip(), key=f"yt_add-{course_info['id']}")
        if process_uploads(files, course) or (add_video and process_video(youtube_link, course)):
            st.rerun()
        for name, message in list(st.session_state.ingest_errors.items()):
            st.error(f"{name}: {message}")
            if st.button("Dismiss", key=f"dismiss-{name}"):
                st.session_state.ingest_errors.pop(name, None)
                st.rerun()

        # ---- material in this course ----
        st.subheader("Material in this course")
        mine = [d for d in list_docs() if d["file"] in set(course_docs)]
        if mine:
            st.table([{"File": d["file"], "Type": KINDS.get(d["type"], d["type"]),
                       "Length": (store.fmt_time(d["pages"]) if d["type"] == "video"
                                  else f"{d['pages']} {'slides' if d['type'] == 'slide' else 'pages'}"),
                       "Units": d["units"], "Passages": d["chunks"]} for d in mine])
            others = [n for n in names if n != course]
            if others:
                with st.expander("Move material to another course"):
                    mv_doc = st.selectbox("Material", [d["file"] for d in mine], key="mv_doc")
                    mv_to = st.selectbox("Move to", others, key="mv_to")
                    st.caption("Your quiz answers on this material move with it.")
                    if st.button("Move", key="mv_go"):
                        moved = library.move_material(mv_doc, mv_to)
                        st.session_state["_select_course"] = mv_to
                        st.success(f"Moved. {moved} answer(s) moved with it.")
                        st.rerun()
        else:
            st.info("Nothing in this course yet. Add a PDF, a PowerPoint deck or a YouTube link above: it is read, split, "
                    "embedded, tagged and sorted automatically.")

        # ---- settings ----
        with st.expander("Course settings"):
            with st.form(f"settings-{course_info['id']}"):
                s_name = st.text_input("Name", value=course)
                s_desc = st.text_area("What is it for?", value=course_info["description"], height=80)
                s_instr = st.text_area("Instructions for the tutor", value=course_instructions, height=110,
                                       help="Used for tone, language and level in the tutor's answers. "
                                            "The grounding rules (answer only from your material, cite pages) always win.")
                if st.form_submit_button("Save settings"):
                    try:
                        updated = library.update_course(course, description=s_desc, instructions=s_instr, new_name=s_name)
                        st.session_state["_select_course"] = updated["course"]
                        if updated["course"] != course:
                            st.session_state.chats[updated["course"]] = st.session_state.chats.pop(course, [])
                        st.rerun()
                    except ValueError as e:
                        st.error(str(e))
            st.markdown("**Delete this course**")
            st.caption("Removes the course, all its material and everything made from it (sections, topics, search entries, "
                       "quizzes) and your progress in it. This cannot be undone.")
            sure_course = st.checkbox("Yes, delete this course for good", key=f"sure-course-{course_info['id']}")
            if st.button("Delete course", disabled=not sure_course, key=f"del-course-{course_info['id']}"):
                removed = library.delete_course(course)
                st.session_state.chats.pop(course, None)
                st.session_state.uploader_n += 1
                st.session_state.pop("_active_course", None)
                st.success(f"Deleted. {removed['materials']} material(s) and {removed['quizzes']} quiz(zes) were removed with it.")
                st.rerun()

# =====================================================================
# Knowledge base: the course's material (one card each), test search
# =====================================================================
with tab_kb:
    st.subheader("Saved material" + (f" in {course}" if course else ""))
    docs = [d for d in list_docs() if d["file"] in set(course_docs)]
    if docs:
        st.table([{"File": d["file"], "Type": KINDS.get(d["type"], d["type"]),
                   "Length": (store.fmt_time(d["pages"]) if d["type"] == "video"
                              else f"{d['pages']} {'slides' if d['type'] == 'slide' else 'pages'}"),
                   "Units": d["units"], "Passages": d["chunks"]} for d in docs])
    else:
        st.info("Nothing saved in this course yet. Add a PDF, a PowerPoint deck or a YouTube link in the Course tab: "
                "it is read, split, embedded, tagged and sorted automatically.")

    for d in docs:
        name = d["file"]
        with st.expander(f"{name}"):
            for note in st.session_state.ingest_notes.get(name, []):
                st.caption(note)
            by = outline.source_of(name)
            st.caption("Outline sorted by: " + ("simple rules only (no helper model has sorted it yet)"
                                                if by in ("", "rules") else by))
            topic_rows = outline.topic_rows(name)
            st.markdown("**Topics** (what the Quiz tab offers)")
            if topic_rows:
                st.table([{"Topic": t["topic"], "Where": t["where"], "Key concepts": t["concepts"]} for t in topic_rows])
            else:
                st.caption("No topics found in this material.")
            st.markdown("**Every heading, sorted** (role = what it is; topic = where it belongs)")
            st.dataframe(outline.table(name), hide_index=True, height=360)

            c1, c2, c3 = st.columns(3)
            if c1.button("Sort again with the helper model", key=f"sort-{name}"):
                bar = st.progress(0.0, text="Sorting the outline...")
                note = pipeline.sort_saved(name, report_bar(bar), force=True)
                bar.empty()
                st.session_state.ingest_notes[name] = [note] if note else []
                st.rerun()
            if d["type"] == "pdf" and c2.button("Describe figures (30 pages at a time)", key=f"fig-{name}"):
                bar = st.progress(0.0, text="A vision model is describing the figures...")
                n, note = figures.describe_pdf_figures(name, progress=lambda a, b: bar.progress(a / max(b, 1)))
                bar.empty()
                st.session_state.ingest_notes[name] = [note]
                st.rerun()
            if d["type"] == "video":
                url = store.get_meta(name)["url"]
                if url:
                    st.video(url)

            st.markdown("**Delete this material**")
            st.caption("Saving is permanent. Deleting removes this file and everything made from it: its sections and "
                       "topics, search entries, the quizzes made from it and your progress on its topics.")
            sure = st.checkbox("Yes, delete it for good", key=f"sure-{name}")
            if st.button("Delete", key=f"del-{name}", disabled=not sure):
                removed = library.delete_material(name)
                st.session_state.ingest_notes.pop(name, None)
                st.session_state.uploader_n += 1                     # empty the upload box so it is not saved again
                st.session_state.pop("quiz_set_id", None)
                st.success(f"Deleted. {removed['quizzes']} quizzes were removed with it.")
                st.rerun()

    st.subheader("Test search")
    st.caption("This is the search the tutor uses behind the scenes, limited to the chosen course.")
    query = st.text_input("Type a question or a topic", key="kb_query")
    if query and docs:
        try:
            out = search(query, k=5, docs=course_docs)
            st.caption(f"Embedding model: {out['model']} | meaning search: {out['dense_engine']} | "
                       f"keyword search: {out['keyword_engine']} | best similarity: {out['best_dense']}")
            if out["skipped"]:
                st.warning(f"{out['skipped']} saved chunks were made with a different embedding model and are ignored.")
            for r in out["results"]:
                preview = " ".join(r["text"].split())[:90]
                where = store.loc_label(store.doc_type(r["doc"]), r["page_start"], r["page_end"])
                with st.expander(f"{r['doc']}, {where}  |  {preview}..."):
                    st.caption(f"similarity {r['dense']}  |  found by {r['found_by']}  |  section: {r['heading']}")
                    st.text(r["text"])
        except Exception as e:
            st.error(f"Search failed: {e}")


# =====================================================================
# Tutor chat (one chat per course)
# =====================================================================
def render_assistant(i, m, is_last):
    meta = m.get("meta") or {}
    st.markdown(m["content"])                 # draws $...$ formulas with LaTeX
    if meta.get("badge"):
        st.caption(meta["badge"])
    if meta.get("adapted"):
        st.caption(meta["adapted"])
    if meta.get("quiz_note"):
        st.info("From your quizzes\n\n" + meta["quiz_note"])

    sources = meta.get("sources") or []
    if sources:
        with st.expander(f"Sources ({len(sources)})", expanded=is_last):
            for s in sources:
                where = viewer.where(s["doc"], s["page_start"], s["page_end"])
                st.markdown(f"**[{s['n']}] {s['heading']}**  \n{s['doc']}, {where}" + ("  (cited)" if s["cited"] else ""))
                st.text(s["text"][:700])
                viewer.show_source(s["doc"], s["page_start"], s["page_end"], key=f"chat{i}-{s['n']}",
                                   highlight=s["text"][:80])

    if meta.get("status") == "not_in_material":
        if meta.get("outside"):
            st.markdown("**Outside knowledge (not from your material):**")
            st.markdown(meta["outside"])
        elif st.button("Answer from general knowledge instead", key=f"out-{i}"):
            try:
                with st.spinner("Writing an answer from general knowledge..."):
                    meta["outside"] = answer_outside(meta["question"])
            except AllModelsBusy as e:
                meta["outside"] = f"No model is available right now. ({e})"
            st.rerun()

    if meta.get("standalone") and meta["standalone"] != meta.get("question") and not meta.get("coach"):
        st.caption(f"Understood as: {meta['standalone']}")


with tab_chat:
    if not course_info:
        st.info("Create a course in the sidebar and add material to it first. Then ask anything about it here.")
    elif not course_docs:
        st.info("This course has no material yet. Add a PDF, a PowerPoint deck or a YouTube link in the Course tab.")

    messages = st.session_state.chats.setdefault(course or "", [])
    for i, m in enumerate(messages):
        with st.chat_message(m["role"]):
            if m["role"] == "assistant":
                render_assistant(i, m, is_last=(i == len(messages) - 1))
            else:
                st.write(m["content"])

    question = st.chat_input("Ask about your material, or ask how you are doing", disabled=not course_docs)
    if question:
        with st.chat_message("user"):
            st.write(question)
        history = [{"role": m["role"], "content": m["content"], **({"coach": True} if (m.get("meta") or {}).get("coach") else {})}
                   for m in messages]          # coach=True marks an earlier answer about the student's own progress
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    r = answer_question(question, history, docs=course_docs, instructions=course_instructions)
                except Exception as e:
                    r = {"status": "error", "answer": f"Something went wrong: {e}",
                         "sources": [], "badge": "", "question": question}
        messages.append({"role": "user", "content": question})
        messages.append({"role": "assistant", "content": r["answer"], "meta": r})
        st.rerun()

with tab_quiz:
    render_quiz_tab()

with tab_dash:
    render_dashboard()

# =====================================================================
# Model check
# =====================================================================
with tab_models:
    st.write("Send a tiny test message to a model and see the reply, speed and tokens used. "
             "Models are grouped by provider; edit the lists in src/llm.py.")

    current = None
    for provider, model in all_models():
        if provider != current:
            st.markdown(f"**{provider}**")
            current = provider
        c1, c2 = st.columns([4, 1])
        c1.write(model)
        if "paste-" in model:
            c2.write("(id not set)")
            continue
        if c2.button("Test", key=f"test-{provider}-{model}"):
            try:
                r = ask("answer", [{"role": "user", "content": "Reply with the single word: ready"}],
                        max_tokens=600, use_cache=False, timeout=90, ladder=[(provider, model)])
                st.success(f"{model}: {r['text']}  |  {r['seconds']} s  |  {r['tokens']} tokens")
            except AllModelsBusy as e:
                st.error(str(e))

    st.markdown("**Which model is best for which job?**")
    st.caption("Runs the same small tasks on the models you pick (fixing math formatting, sorting a heading outline, "
               "writing a question, preparing an answer key, grading, a short tutor answer, describing a figure) and "
               "scores them. Then you can save the best-first order, and the app uses it from then on. "
               "Free OpenRouter and Hugging Face models have small limits (daily requests, monthly credits): leave them out unless you need them.")
    candidates = benchmark.candidate_models()
    labels = {f"{p}/{m}": (p, m) for p, m in candidates}
    default = [k for k in labels if not k.startswith(("openrouter/", "huggingface/"))]
    picked = st.multiselect("Models to measure", list(labels), default=default, key="bench_models")
    if st.button("Run the benchmark", disabled=not picked, key="bench_run"):
        bar = st.progress(0.0, text="Starting...")
        results = benchmark.run([labels[k] for k in picked],
                                progress=lambda d, t, text: bar.progress(d / max(t, 1), text=text))
        bar.empty()
        st.session_state["bench_results"] = results
    results = st.session_state.get("bench_results")
    if results:
        st.dataframe(benchmark.table(results), hide_index=True)
        proposed = benchmark.rank(results)
        st.caption("Proposed order for the quiz answer key: " + ", ".join(m for _, m in proposed.get("key", [])[:5]))
        b1, b2 = st.columns(2)
        if b1.button("Use this order from now on", key="bench_save"):
            benchmark.save_order(proposed)
            st.success("Saved. The app now tries models in this order.")
        if b2.button("Go back to the built-in order", key="bench_clear"):
            benchmark.clear_order()
            st.success("The built-in order is used again.")

    st.markdown("**Vision check** (only the models that can read pictures: one small picture each, quick and cheap)")
    st.caption("Figures, scanned pages and picture descriptions need a model that answers this test. "
               "A model that does not start answering within 60 seconds is marked as failed.")
    vision_pairs = [(p, m) for p, m in candidates if benchmark.is_vision(m)]
    if not vision_pairs:
        st.info("No vision model has a key yet. Add NVIDIA_API_KEY or HF_TOKEN to your .env file.")
    if st.button("Test the vision models", disabled=not vision_pairs, key="bench_vision"):
        vbar = st.progress(0.0, text="Starting...")
        st.session_state["vision_results"] = benchmark.run(
            vision_pairs, tasks=benchmark.TASKS_VISION, progress=lambda d, t, text: vbar.progress(d / max(t, 1), text=text))
        vbar.empty()
    vres = st.session_state.get("vision_results")
    if vres:
        st.dataframe([{"Model": f"{r['provider']}/{r['model']}",
                       "Reads pictures (0-100)": round(100 * r["scores"].get("vision", 0)),
                       "Starts in (s)": benchmark.starts_in(r),
                       "Total seconds": benchmark.typical_seconds(r) if r["seconds"] else None,
                       "Problem": (r["errors"][0][:120] if r["errors"] else "")} for r in vres], hide_index=True)
        working = [r for r in vres if r["scores"].get("vision", 0) >= 0.5]
        if working:
            st.success(f"{len(working)} vision model(s) work. The app tries them in the order of its vision list.")
        else:
            st.warning("No vision model answered correctly. Check the HF_TOKEN or NVIDIA_API_KEY in .env, or add model ids in src/llm.py.")

    st.markdown("**Extraction test** (free text in a simple template, as concept extraction will use)")
    if st.button("Run extraction test"):
        try:
            r = ask("extract", [{"role": "user", "content":
                                 "From this sentence list the key concepts and the prerequisite concepts. "
                                 "Reply in exactly two lines:\nConcepts: a; b; c\nPrerequisites: x; y\n"
                                 "Sentence: Molality is the number of moles of solute per kilogram of solvent."}],
                    use_cache=False)
            st.success(f"{r['provider']} / {r['model']}  |  {r['seconds']} s  |  {r['tokens']} tokens")
            st.text(r["text"])
            st.write("Parsed:", parse_labeled_lines(r["text"]))
        except AllModelsBusy as e:
            st.error(str(e))

    st.markdown("**Usage counter** (kept in SQLite)")
    st.table(usage_summary())
