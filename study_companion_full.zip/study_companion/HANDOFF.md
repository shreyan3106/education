# HANDOFF: paste this file and the project files into the next chat

Project: **Study Companion** for Multimodal AI Hackathon 2026 (IIT Mandi), **Track D**.
Submission deadline: **14 Oct 2026 afternoon** (Devpost shows 15 Oct 12:15 AM IST, so treat the 14th as the deadline).
Deliverables: working prototype, documentation, evaluation results, 3-10 minute YouTube demo video, Devpost page.
Scoring: grounding 20, personalization 20, assessment quality 15, UX and video 15, system evaluation 15, technical implementation 15.

## How to work with me (the user)

- (Resolved 11 Oct: I renamed the quiz files myself, so they are now `src/quiz.py`, `src/quiz_ui.py` and `tests/test_quiz.py`, imported as `from src import quiz`. Older notes below that say `uiz` mean these files.)

- I do not write code; I run what you give me. Always give COMPLETE files (not patches) and tell me exactly where each goes.
- Tell me options and decisions in plain language BEFORE building, and wait for my choice. "Go with yours" is fine when I say it.
- I want results visible inside the app, not in the terminal. No manual preprocessing steps for users.
- When something fails I send a screenshot and the last lines of the terminal.
- Laptop: Intel i5-1235U, 16 GB RAM, no real GPU. Windows. I use VS Code. I will not use Gemini or Ollama.

## Where we are

Verified by me in the real app: the app runs; all models in the Model check tab answered; PDF reading and heading detection work; automatic upload and search work on the NCERT physics chapter (leph101.pdf, 44 pages).
First tutor test found problems; **fixes were delivered but I have not confirmed them yet**:
answer cut off (token limit), wrong source from "Points to Ponder", examples cited for concept questions, formulas not rendered, blank / squeezed tables, 8 units untagged.
Tested only with fake models (not with real models yet): reranking, example filtering, cut-off handling, tag retry, and the whole quiz engine.

**Update (4 Oct, evening):** I confirmed the tutor fixes in the real app (cited answers, Verified badge, formulas render, off-chapter question declined). Quiz generation (step 2) is now BUILT and tested with fake models only: `src/uiz.py`, `src/uiz_ui.py`, `tests/test_uiz.py`. I have NOT yet run it with real models.
Quiz rules I chose: topic quiz = 7 questions on a typed topic; mock exam = 30 questions on exactly 5 topics picked from the tagged topics (6 each); all questions shown at once, instant feedback per answer, Submit gives the report (weak topics, likely misconceptions, pages to revise). The setter model writes questions only; a different-family model writes the answer key and must copy the proving sentence (code checks it is in the passage); numerical answers are cross-checked by our own calculator; short answers are graded by a different-family model; questions too similar to earlier ones are dropped (history in SQLite, no repeats).

**Update (5 Oct):** I tested the quiz in the real app: generation, explanations, report and saving all work; a topic quiz takes about 2-3 minutes to generate. One question sometimes was not graded. Fixes delivered (not yet confirmed by me): a short-answer verdict is now accepted even if the grader's reply is cut off, with a retry and a clear fallback; text answers use a form (Enter or button); numerical answers also read 1/4 and 10^-3 written with superscripts. The topic list in the Quiz tab is now the document's own sections in book order (pages and key concepts), and every question's topic tag is its section (about 16 clean topics instead of 100+ noisy per-unit tags), which is what the learner model will use.

**Update (5 Oct, later):** the document outline helper is built (`src/outline.py`, tests in `tests/test_outline.py`): after upload, a helper model reads the whole heading outline in windows and sorts every unit into a role (title / section / subsection / example / exercise / summary / other) and groups sections into topics; saved in the table `doc_outline`; rules (heading levels plus a few common words, no numbering assumptions) are the fallback and the table says which was used. The Knowledge base tab shows it as a clean table; the tutor uses the roles (concept questions skip examples, exercises and contents); the quiz topic list, mock-exam topics and every question's topic tag come from it. Older saved documents are sorted automatically once per session. NOT yet confirmed by me in the real app. Principle: nothing may depend on one document or one textbook style. He offered to add one more model (ID + provider) to `src/llm.py` if needed.

**Update (5 Oct, evening):** the LEARNER MODEL is built (`src/learner.py`, `src/learner_ui.py`, `tests/test_learner.py`). Three methods: BKT = main per-topic estimate; IRT-style ability (MAP, recency-weighted) = second opinion, confidence and the difficulty to aim at (~70% success); spaced repetition (stability in days, forgetting curve, due dates) = decay and review scheduling; mastery = BKT blended with IRT as evidence grows, times (0.6 + 0.4 x recall). Everything is recomputed from the event log table `learner_events` (profile in `learner_profile`), so it can be replayed and simulated (all functions take `student` and `now`). Evidence: quiz/diagnostic answers (strong), tutor questions (light). New students: 3-tap intake in the Dashboard tab sets the prior, and a Diagnostic quiz mode (1 question per topic) in the Quiz tab. Used by: quiz difficulty mix (the setter is told how many easy/medium/hard), "Suggested for you" topics, the tutor (teaching note: from basics / standard / concise, plus a caption in the chat), and the "Study next" list. The Dashboard tab now exists. I removed the startup auto-sort from app.py (it was the cause of the ingest_notes crash after a long spinner); older documents are sorted by rules instantly and can be sorted by the model with the "Sort again" button in the Knowledge base tab. NOT yet confirmed by me in the real app. Next: slides and video ingestion (location = page / slide / timestamp), then evaluation (simulated students use the learner API; the question bank is reused so no model calls are needed to simulate answers).

**Update (8 Oct): BIG ROUND, all built and tested with fake models only, NOT yet run by me in the real app.**
- Models: llm.py has the new models (NVIDIA: z-ai/glm-5.3, z-ai/glm-5.3-flash, nvidia/nemotron-3-nano-omni-30b-a3b-reasoning, meta/llama-3.2-90b-vision-instruct; OpenRouter: thinkingmachines/inkling-small:free, nvidia/nemotron-3.5-lightning:free). DeepSeek (separate system) and the Gemma swap are PARKED on my request. Ladders are BEST FIRST per job (answer, check, extract, outline, setter, key, grade, report, format, rewrite, rerank, vision); rewrite/rerank use fast models only. The Model check tab can benchmark models and save a measured order to data/ladders.json. A cut-off reply is retried with a bigger limit, then the next model; never shown half if avoidable.
- Quiz: setter, answer-key maker and grader are three different families; options are shuffled BEFORE the key is made (fixes the wrong option letter in explanations); questions that say "according to the passage" are rejected; key points are a bullet list; all text goes through src/fmt.py (math cleaning, model repair when broken).
- Outline: new role "fragment" (formula pieces mistaken for headings) so garbled topic names cannot appear; the outline helper reads up to 250 units per call on long-context models.
- Courses: sidebar picks ONE course; tutor, quizzes, diagnostic, dashboard stay inside it. Saved material can be deleted (library.delete_material). Outline per saved file is shown in the Knowledge base cards (so "Sorted by" shows after a restart). Exam date picker only shows when ticked.
- Tutor: short answers (about 120 words), WRITER_TOKENS 2000; coach mode answers "how do I improve / what should I revise" from quiz results with no sources; a "From your quizzes" note under content answers.
- Slides (.pptx), YouTube (captions, else yt-dlp + Groq Whisper, max 60 min), scanned PDF pages and figure descriptions (vision model), textbooks up to 450 pages. Locations are page / slide / seconds (store.loc_label). pip install python-pptx youtube-transcript-api yt-dlp imageio-ffmpeg pillow.
- Nemotron OCR was NOT used (not feasible on this laptop); a vision model reads scans instead.
- Next: run everything for real, fix what breaks; evaluation (RAGAS + simulated students); docs, demo video, Devpost.

**Update (10 Oct): first real run done (UPSC Polity one-liners PDF + a YouTube link). Timings: video about 15 min, PDF about 6 min, sorting about 10-12 min; results very good, only minor problems; topic quiz: 2 questions not graded.** I raised: the tutor could not see quiz status (cause: the coach only triggered on certain words and ignored the earlier chat), the Mastery table (same % for different evidence), "in 0 days" review dates, Study next showing only untested topics, a title page ("Gifted with Blessings...") as a topic, many benchmark models failing (time-outs, not wrong answers; no vision model answered).
My decisions: 60 s is the time to START answering (thinking counts); no total cap while answering; 60 s of silence mid-reply = hand over to the next model at once, fastest first, same context; ladders best first; mastery must be accurate and built from ALL quizzes (topic, mock, diagnostic), quizzes only (tutor questions do not count); courses like Claude Projects (create a course, add materials, any scope); memory file on the student's device is in the track but comes AFTER the other work; extra models: Ling 3.1 Flash, Apodex 1.1 Mini, Nemotron 3 Super via OpenRouter, plus the Nemotron Rerank VL 1B as a rerank fallback. Not used: Blue Minds (anonymous reseller), FreeLLMAPI (extra server), Mercury Decide (not a chat model), Liquid embeddings (training-retention note, local embeddings are better), Voyage rerank (paid).
BUILT AND TESTED WITH FAKE MODELS (round 1, NOT yet run by me in the real app): src/llm.py (streaming, time rules, hand-over, saved rests, speed table, rerank_api, the 3 models), src/benchmark.py ("Starts in" column), src/coach.py + src/tutor.py (progress follow-ups, rescue, rerank fallback), src/learner.py + src/learner_ui.py (quizzes-only mastery, shrinkage, range, evidence, plain review dates, new Study next order, LEARN_QUIZ 0.06), src/outline.py (title pages and tiny pages are not topics), app.py (marks coach answers in the chat history).
NEXT: (1) I run round 1 and report; (2) COURSES like Claude Projects (a course table with name, description, tutor instructions; add materials inside it; progress, chats and the dashboard per course; learner events need a course id); (3) evaluation (RAGAS on the teammate's CSV; simulated students already tested in test_learner.py test 17); (4) docs, demo video, Devpost; (5) memory on the student's device if time allows. Two quiz questions were not graded: send the message shown on the question; a grading fallback is already in uiz.py (keyword match).

**Update (10 Oct, round 2): COURSES like Claude Projects, built and tested with fake models (tests/test_courses.py), NOT yet run by me in the real app.** A course is created first (name, description, tutor instructions), material is added INTO it (Course tab), material can be moved between courses, a course can be renamed or deleted. Every course has its own learner record (progress, intake, answers): the student id is `course-<id>` (`library.student_for`), set at the start of each run with `learner.set_current_student` (kept per thread); progress saved before courses existed is adopted once per course (`library.adopt_legacy`). The chat is per course (kept in the session). The course's tutor instructions go to the tutor and the coach after the rules (never instead of them). Files: src/library.py (rewritten), app.py (new Course tab, sidebar picks the course), src/learner.py, learner_ui.py, uiz_ui.py, uiz.py, tutor.py, coach.py. The chat history is not saved across restarts yet.
NEXT: evaluation (RAGAS on the teammate's CSV, simulated students are already in tests/test_learner.py test 17), docs, demo video, Devpost; memory on the student's device only if time allows.

**Update (14 Oct, 00:30 IST): the laptop died two days ago; work continues on a friend's laptop. Deadline: afternoon of 14 Oct (Devpost shows 15 Oct 12:15 AM IST).** Built since round 2: Hugging Face provider in src/llm.py (HF_TOKEN, router.huggingface.co/v1; vision ladder starts with CohereLabs/command-a-vision; 402 = credits used up, the provider rests 6 hours), "Test the vision models" button in the Model check tab, figures are now described AUTOMATICALLY after a PDF upload (12 biggest figure pages; a quick vision_ready check first), .streamlit/config.toml (silences watcher noise), .env.example, .gitignore, dashboard table warning fixed. Priorities agreed: vision first, then step B (quiz quality, tutor+coach team, solver, Settings tab, marks), then step A (document modes with "Practice questions", per-course intake and quiz numbering with accurate times, two reset buttons, run log, video title/length). Principle: models decide, code only validates; no subject-specific phrases in code. Then evaluation, documentation, demo video, Devpost.

Not built yet: evaluation (RAGAS, simulated students), docs, demo video, Devpost page.

## Architecture in one picture

See README.md ("How it works"). Code reads the PDF first, models assist (heading clean-up, tags, rerank, write, check). One file, `src/llm.py`,
is the only place that calls models: a ladder of models per job over NVIDIA, Groq and OpenRouter, with a SQLite usage counter, cache,
timeouts, cut-off detection. The checker always comes from a different model family than the writer.

## Decisions already made

- Units by headings (option B: learn the document's own style; models assist). Chunks ~180 words with page numbers.
- Embeddings run locally: bge-small-en-v1.5 first (BGE-M3 is an optional upgrade, ~2 GB). One shared chunk table is the search index.
- Retrieval is hybrid (FAISS + BM25, rank fusion) followed by a model reranker; decline when similarity is too low or the writer says NOT_IN_MATERIAL;
  a button offers a clearly labelled general-knowledge answer.
- Writer / checker verdicts: Verified, Corrected, Unverified badge. Follow-up questions are rewritten into standalone questions.
- Extraction output is free text in a simple template (Concepts: a; b / Prerequisites: x), not JSON.
- Measured speeds (4 Oct): fast = Groq qwen3.8-27b, gpt-oss-20b, gpt-oss-120b, NVIDIA Nemotron 3 Super, OpenRouter Nemotron 3 Ultra :free.
  Slow or unreliable = NVIDIA DeepSeek V4.1 Flash and Kimi K3 (about 85 s), Gemma 4 (timed out). They are last in the ladders.

## Next steps, in priority order (about 9 days left)

1. I run the latest fixes and report what I see (tutor answers, sources, tables, tags). Tune `REFUSE_BELOW` and `MIN_CHUNK_SIM`.
2. DONE, awaiting my first real run: quiz generation (MCQ, short answer, numerical) tagged by topic / source / difficulty, verified by a second model, no repeats. (Track D 3a, 3b, 3c). Tune `REPEAT_SIM`, `QUIZ_REFUSE_BELOW` in `src/uiz.py` after the first run.
3. Learner model (Bayesian knowledge tracing per topic), diagnostic quiz for new students, dashboard with weak topics. (4a, 4b)
4. Slides (.pptx) and YouTube captions / Whisper (Groq hosts Whisper) ingestion into the same chunk table. (1a)
5. Evaluation: RAGAS on my teammate's test set (CSV), simulated students for personalization results. (5a-5c)
6. Figures: render the figure region as an image and describe it with a vision-capable model (Gemma 4 on NVIDIA accepts images). (1d)
7. Docs, architecture diagram, demo video, Devpost page. Cut first if time runs out: figures, OCR, optional extras.

## Settings I can change myself

Listed in README.md under "Settings you can change without writing code".

## Teammate

One classmate (non-technical) has joined. Plan is in TEAMMATE_TASKS.md: fresh-install test, test-question set (CSV), demo material hunt, later quiz review, demo video and Devpost text.

## How I continue in the new chat

1. Open a new chat inside the same Project (the project notes carry over).
2. Upload the project zip (or the changed files) and this HANDOFF.md.
3. First message: "Continue from HANDOFF.md. I ran the fixes: <what I saw>. Start with step <n>."
