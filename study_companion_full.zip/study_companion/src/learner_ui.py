"""The Dashboard tab: the learner model made visible. Mastery per topic, what to study next, new-student intake."""
import datetime

import streamlit as st

from src import learner, library, store

LEVELS = {"I am new to this": "beginner", "I know some of it": "some", "I know it well": "advanced"}
GOALS = ["Prepare for an exam", "Understand the material", "Quick revision"]
ACTION_NAMES = {"learn": "Learn again", "review": "Review", "practice": "Practice", "assess": "Test yourself",
                "challenge": "Challenge"}


def _docs():
    return library.docs_in(st.session_state.get("course"))


def _intake_form(existing=None):
    """Level, goal and (only if wanted) an exam date. Plain widgets, so the date picker appears only when ticked."""
    level_names = list(LEVELS)
    current_level = next((k for k, v in LEVELS.items() if existing and v == existing["level"]), level_names[1])
    level = st.radio("How much do you already know about this material?", level_names,
                     index=level_names.index(current_level), horizontal=True, key="intake_level")
    goal = st.radio("What is your goal?", GOALS, index=(GOALS.index(existing["goal"]) if existing
                                                        and existing["goal"] in GOALS else 0),
                    horizontal=True, key="intake_goal")
    has_exam = st.checkbox("I have an exam date", value=bool(existing and existing["exam_date"]), key="intake_has_exam")
    exam = None
    if has_exam:
        default = datetime.date.today() + datetime.timedelta(days=14)
        if existing and existing["exam_date"]:
            try:
                default = datetime.date.fromisoformat(existing["exam_date"])
            except ValueError:
                pass
        exam = st.date_input("Exam date", value=default, key="intake_exam")
    if st.button("Save", type="primary", key="intake_save"):
        learner.set_profile(learner.current_student(), LEVELS[level], goal, exam.isoformat() if has_exam and exam else "")
        st.rerun()


def render_dashboard():
    if not _docs():
        st.info("Add material to this course first (Course tab). Your progress in the course will appear here as you take quizzes.")
        return

    imported_key = "history_imported::" + learner.current_student()
    if not st.session_state.get(imported_key):               # answers given before the learner model existed
        st.session_state[imported_key] = True
        try:
            learner.import_quiz_history(learner.current_student(), docs=_docs())
        except Exception:
            pass

    st.subheader("Your progress")
    profile = learner.get_profile(learner.current_student())
    answers = learner.event_count(learner.current_student())

    if learner.needs_intake(learner.current_student()):
        st.info("New here? Tell me where you are, then take the diagnostic quiz in the Quiz tab "
                "(one question per topic). That gives your first mastery estimates.")
        _intake_form()
    else:
        who = {"beginner": "new to this", "some": "knows some of it", "advanced": "knows it well"}
        line = (f"Level: {who[profile['level']]}.  Goal: {profile['goal'] or 'not set'}."
                + (f"  Exam: {profile['exam_date']}." if profile and profile["exam_date"] else "")) if profile else \
               "No intake saved. The estimates start from a neutral guess."
        st.caption(line + f"  Answers recorded: {answers}.")
        with st.expander("Change my intake" if profile else "Add my intake"):
            _intake_form(profile)

    docs = _docs()
    states = learner.all_states(learner.current_student(), docs=docs)
    if not states:
        st.warning("No topics found yet. Add material in the Course tab and wait until it has been sorted.")
        return

    st.markdown("**Mastery by topic**")
    CONF = {"none": "not tested", "low": "too early to tell", "medium": "fair", "high": "solid"}
    st.dataframe(
        [{"Topic": s["topic"], "Where": s["where"],
          "Mastery": round(100 * s["mastery"]) if s["assessed"] else None,
          "Likely range": f"{round(100 * s['low'])}-{round(100 * s['high'])}%" if s["assessed"] else "-",
          "Evidence": s["evidence"] if s["assessed"] else "-",
          "How sure": CONF[s["confidence"]],
          "Next review": learner.due_phrase(s["due_in_days"]),
          "Asked the tutor": str(s["n_tutor"]) if s["n_tutor"] else ""} for s in states],
        hide_index=True,
        column_config={"Mastery": st.column_config.ProgressColumn("Mastery", min_value=0, max_value=100,
                                                                  format="%d%%")})
    if not any(s["assessed"] for s in states):
        st.caption("Nothing is tested yet, so no mastery is shown. Take the diagnostic quiz to start.")
    else:
        st.caption("Mastery comes only from your quiz, mock exam and diagnostic answers (all of them, each question once). "
                   "With few answers the estimate stays close to your starting level and the likely range is wide; "
                   "'How sure' is about the amount of evidence, not about how good you are. Asking the tutor does not change the number.")

    st.markdown("**Study next**")
    for r in learner.recommend(learner.current_student(), 4, docs=docs):
        st.markdown(f"**{r['topic']}**  ·  {ACTION_NAMES[r['action']]}  ·  {r['doc']}, {r['where']}  \n{r['reason']}")

    with st.expander("How these numbers are made"):
        st.markdown(
            "Only your quiz, mock exam and diagnostic answers count (every quiz taken so far, each question once). "
            "Three methods work together for every topic.  \n"
            "**Bayesian knowledge tracing** (main): the chance you know the topic, updated after every answer, "
            "allowing for lucky guesses and careless slips.  \n"
            "**IRT-style ability** (supporting): a second opinion on mastery that also finds how hard your next "
            "questions should be, and how sure we are.  \n"
            "**Spaced repetition** (supporting): memory fades with time; mastery drops a little each day you do "
            "not practise, and the next review date is set from how well you remembered. A wrong answer brings the "
            "review forward (never sooner than about 12 hours): then revisit the questions you missed, no need to retake the whole topic.  \n"
            "**Few answers**: one answer never counts as certainty. The estimate starts from the level you gave and moves "
            "toward your results as answers add up; the likely range narrows the same way.")
        pick = st.selectbox("Show the numbers for one topic", [s["topic"] for s in states], key="dash_topic")
        s = next((x for x in states if x["topic"] == pick), states[0])
        if s["assessed"]:
            st.table([{"Mastery": f"{round(100 * s['mastery'])}%", "Evidence": s["evidence"],
                       "BKT knowledge": f"{round(100 * s['p_bkt'])}%",
                       "IRT ability (theta)": "needs 2+ answers" if s["theta"] is None else f"{s['theta']} ± {s['se']}",
                       "Memory strength": "-" if s["stability_days"] is None else f"{s['stability_days']} days",
                       "Recall now": f"{round(100 * s['retrievability'])}%", "Methods used": s["methods"]}])
        else:
            st.caption("Not tested yet." + (f" Asked the tutor about it {s['n_tutor']} time(s)." if s["n_tutor"] else ""))

    with st.expander("Reset my progress"):
        sure = st.checkbox("Yes, delete my intake and all recorded answers", key="dash_reset_ok")
        if st.button("Reset", disabled=not sure, key="dash_reset"):
            learner.reset(learner.current_student())
            st.session_state[imported_key] = True       # do not bring the old answers back
            st.rerun()
