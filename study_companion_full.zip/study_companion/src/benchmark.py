"""
Model benchmark: which model is really best for each job?

Every model gets the SAME small tasks, built from the app's own prompts, and each answer is scored by code:
  format   fixes broken math formatting, keeping the words
  outline  sorts a heading outline that contains debris headings (formula pieces)
  setter   writes two quiz questions that stand alone
  key      prepares the answer key for a multiple-choice question (must pick the right option and copy the proof)
  grade    grades one correct and one wrong short answer
  tutor    answers briefly with a citation
  vision   describes a drawn figure (vision models only)
Speed, cut-offs and errors are recorded too. rank() turns the results into a best-first order per job; the order
is saved in data/ladders.json and the app uses it from then on.
"""
import json
import os
import re
import statistics
import time

from src import fmt, llm, outline, tutor, quiz

PASSAGE = ("Coulomb's law states that the electrostatic force between two point charges is directly proportional "
           "to the product of the magnitudes of the charges and inversely proportional to the square of the distance "
           "between them. The force acts along the line joining the charges. It is attractive for unlike charges and "
           "repulsive for like charges.")

TASKS_TEXT = ("format", "outline", "setter", "key", "grade", "tutor")
TASKS_VISION = ("vision",)
SLOW_AFTER = 90.0            # a model whose typical call takes longer than this is not used for live jobs

OUTLINE_UNITS = [(1, "L1", "ELECTRIC CHARGES", "title"), (2, "L2", "1.1 Electric Charge", "section"),
                 (3, "L2", "2 1 2 q q F k", "fragment"), (4, "L2", "1.2 Coulomb's Law", "section"),
                 (5, "L3", "0 = 8.854 x 10-12 C2 N-1m-2", "fragment"), (6, "L2", "Example 1.1", "example"),
                 (7, "L1", "EXERCISES", "exercise")]


_last = {"first": None}          # how long the last call took to START answering (the 60-second rule)


def _ask(provider, model, job, messages, max_tokens):
    """One call to exactly one model. Returns (reply or None, seconds, truncated, error)."""
    started = time.time()
    _last["first"] = None
    try:
        r = llm.ask(job, messages, max_tokens=max_tokens, use_cache=False, ladder=[(provider, model)])
        _last["first"] = r.get("first_seconds")
        return r, time.time() - started, bool(r.get("truncated")), ""
    except llm.AllModelsBusy as e:
        return None, time.time() - started, False, str(e)[:120]


def _task_format(provider, model):
    bad = "Force is F = k q1 q2 / r^2 and the distance r_13 matters for the vector E."
    r, t, cut, err = _ask(provider, model, "format", [{"role": "system", "content": fmt.REPAIR_SYSTEM},
                                                       {"role": "user", "content": bad}], 400)
    if not r:
        return 0.0, t, cut, err
    out = fmt.clean(r["text"])
    kept = all(w in out for w in ("Force", "distance", "vector"))
    fixed = "$" in out and not fmt.broken(out)
    return (0.5 if kept else 0.0) + (0.5 if kept and fixed else 0.0), t, cut, err


def _task_outline(provider, model):
    lines = [f"{i} | {lv} | page {i} | 40w | {h}{' [suspect]' if role == 'fragment' else ''} | - | some words of the text"
             for i, lv, h, role in OUTLINE_UNITS]
    r, t, cut, err = _ask(provider, model, "outline", [
        {"role": "system", "content": outline.OUTLINE_SYSTEM},
        {"role": "user", "content": "Document: test.pdf\nTopics so far: (none yet)\n\nUnits:\n" + "\n".join(lines)}], 1500)
    if not r:
        return 0.0, t, cut, err
    topics, rows = outline.parse_outline(r["text"], {u[0] for u in OUTLINE_UNITS})
    right = sum(1 for i, _, _, role in OUTLINE_UNITS if rows.get(i, (None,))[0] == role)
    names_ok = all(not outline.looks_like_fragment(n) for n in topics.values()) and bool(topics)
    return 0.8 * right / len(OUTLINE_UNITS) + (0.2 if names_ok else 0.0), t, cut, err


def _task_setter(provider, model):
    system = quiz.SETTER_SYSTEM.format(n=2, per=2)
    r, t, cut, err = _ask(provider, model, "setter", [
        {"role": "system", "content": system},
        {"role": "user", "content": f"Topic: Coulomb's law\n\nPassages:\n[1] (test.pdf, page 1, section: Coulomb's Law)\n{PASSAGE}\n\nALREADY ASKED:\n(none)"}], 2500)
    if not r:
        return 0.0, t, cut, err
    return min(1.0, len(quiz.parse_setter_output(r["text"], 1)) / 2), t, cut, err


def _task_key(provider, model):
    draft = {"qtype": "mcq", "options": {"A": "It stays the same", "B": "It becomes one quarter",
                                         "C": "It doubles", "D": "It becomes half"}}
    user = (f"Passage (test.pdf, page 1):\n{PASSAGE}\n\nQuestion type: MCQ\nQuestion: What happens to the electrostatic "
            "force between two point charges when the distance between them is doubled?\n"
            + "".join(f"{L}: {t}\n" for L, t in draft["options"].items()))
    r, t, cut, err = _ask(provider, model, "key", [{"role": "system", "content": quiz.CHECKER_SYSTEM},
                                                    {"role": "user", "content": user}], 1500)
    if not r:
        return 0.0, t, cut, err
    res = quiz.parse_check_output(r["text"], draft, PASSAGE)
    return (1.0 if res.get("ok") and res["key"]["correct"] == "B" else 0.0), t, cut, err


def _task_grade(provider, model):
    base = ("Question: What does the electrostatic force between two point charges depend on?\n"
            "Reference answer: It is proportional to the product of the charges and inversely proportional to the square of the distance.\n"
            "Key points: product of the charges; inverse square of the distance\nStudent's answer: ")
    total, t_all, cut_any, err_any = 0.0, 0.0, False, ""
    for answer, want in (("It depends on the charges multiplied together and falls off with the square of the distance.", 1.0),
                         ("It depends only on the mass of the charges.", 0.0)):
        r, t, cut, err = _ask(provider, model, "grade", [{"role": "system", "content": quiz.GRADER_SYSTEM},
                                                         {"role": "user", "content": base + answer}], 1200)
        t_all += t
        cut_any, err_any = cut_any or cut, err or err_any
        if r and quiz._read_verdict(r["text"]) == want:
            total += 0.5
    return total, t_all / 2, cut_any, err_any


def _task_tutor(provider, model):
    r, t, cut, err = _ask(provider, model, "answer", [
        {"role": "system", "content": tutor.WRITER_SYSTEM},
        {"role": "user", "content": f"Passages:\n[1] (test.pdf, page 1, section: Coulomb's Law)\n{PASSAGE}\n\nQuestion: What is Coulomb's law?"}], 900)
    if not r:
        return 0.0, t, cut, err
    words = len(r["text"].split())
    return (0.5 if re.search(r"\[1\]", r["text"]) else 0.0) + (0.5 if 8 <= words <= 160 else 0.0), t, cut, err


def _figure_png():
    from io import BytesIO
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (420, 220), "white")
    d = ImageDraw.Draw(img)
    d.ellipse((60, 80, 120, 140), outline="black", width=3)
    d.ellipse((300, 80, 360, 140), outline="black", width=3)
    d.text((83, 102), "+q1", fill="black")
    d.text((323, 102), "-q2", fill="black")
    d.line((125, 110, 295, 110), fill="black", width=2)
    d.text((190, 90), "r", fill="black")
    d.text((150, 130), "F", fill="black")
    buf = BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def _task_vision(provider, model):
    started = time.time()
    try:
        r = llm.ask("vision", [llm.image_message("Describe the figure: every label and what it shows.", [_figure_png()])],
                    max_tokens=600, use_cache=False, ladder=[(provider, model)])
    except llm.AllModelsBusy as e:
        return 0.0, time.time() - started, False, str(e)[:120]
    text = r["text"].lower()
    hits = sum(1 for k in ("q1", "q2", "r", "force", "charge") if k in text)
    return min(1.0, hits / 4), time.time() - started, bool(r.get("truncated")), ""


TASK_FUNCS = {"format": _task_format, "outline": _task_outline, "setter": _task_setter, "key": _task_key,
              "grade": _task_grade, "tutor": _task_tutor, "vision": _task_vision}


def candidate_models():
    """Every (provider, model) with a usable id and a key, grouped as the Model check tab shows them."""
    out = []
    for provider, model in llm.all_models():
        if "paste-" in model or not llm._api_key(provider):
            continue
        if (provider, model) not in out:
            out.append((provider, model))
    return out


def is_vision(model):
    return any(model == m for _, m in llm.LADDERS["vision"])


def run(models, tasks=None, progress=None):
    """Run the tasks on each model. Returns [{provider, model, scores, seconds, cut_off, errors}]."""
    results = []
    total = sum(len([t for t in (tasks or (TASKS_TEXT + TASKS_VISION)) if t != "vision" or is_vision(m)]) for _, m in models)
    done = 0
    for provider, model in models:
        row = {"provider": provider, "model": model, "scores": {}, "seconds": {}, "firsts": {}, "cut_off": 0, "errors": []}
        for task in (tasks or (TASKS_TEXT + TASKS_VISION)):
            if task == "vision" and not is_vision(model):
                continue
            _last["first"] = None
            score, seconds, cut, err = TASK_FUNCS[task](provider, model)
            if _last["first"] is not None:
                row["firsts"][task] = round(_last["first"], 1)
            row["scores"][task] = round(score, 2)
            row["seconds"][task] = round(seconds, 1)
            row["cut_off"] += 1 if cut else 0
            if err:
                row["errors"].append(f"{task}: {err}")
            done += 1
            if progress:
                progress(done, total, f"{provider}/{model}: {task}")
        results.append(row)
    return results


def quality(row, tasks=TASKS_TEXT):
    got = [row["scores"][t] for t in tasks if t in row["scores"]]
    return sum(got) / len(got) if got else 0.0


def typical_seconds(row):
    return statistics.median(row["seconds"].values()) if row["seconds"] else 999.0


def starts_in(row):
    """Median seconds the model needed to START answering (None if it never did)."""
    firsts = row.get("firsts") or {}
    return statistics.median(firsts.values()) if firsts else None


def rank(results):
    """{job: [[provider, model], ...]} best first, for every job. Models with no score are left to the defaults."""
    usable = [r for r in results if r["scores"] and quality(r) > 0]
    by_quality = sorted(usable, key=lambda r: (-round(quality(r), 2), typical_seconds(r)))
    pair = lambda r: [r["provider"], r["model"]]
    live = [r for r in by_quality if typical_seconds(r) <= SLOW_AFTER]
    order = {}
    for job in ("answer", "check", "extract", "setter", "key", "grade", "report"):
        order[job] = [pair(r) for r in live] + [pair(r) for r in by_quality if r not in live]
    long_ctx = {tuple(p) for p in llm.LADDERS["outline"]}
    order["outline"] = [pair(r) for r in sorted((r for r in usable if (r["provider"], r["model"]) in long_ctx),
                                                 key=lambda r: (-r["scores"].get("outline", 0), -quality(r), typical_seconds(r)))]
    fast_pool = [r for r in usable if typical_seconds(r) <= 12.0 and (r["provider"], r["model"]) in
                 {tuple(p) for p in llm.LADDERS["rewrite"]}]
    for job in ("rewrite", "rerank", "format"):
        order[job] = [pair(r) for r in sorted(fast_pool, key=lambda r: (-round(quality(r), 2), typical_seconds(r)))]
    order["vision"] = [pair(r) for r in sorted((r for r in usable if "vision" in r["scores"]),
                                               key=lambda r: (-r["scores"]["vision"], typical_seconds(r)))]
    return {job: pairs for job, pairs in order.items() if pairs}


def save_order(order):
    os.makedirs(os.path.dirname(llm.LADDER_FILE) or ".", exist_ok=True)
    with open(llm.LADDER_FILE, "w", encoding="utf-8") as f:
        json.dump(order, f, indent=1)


def clear_order():
    if os.path.exists(llm.LADDER_FILE):
        os.remove(llm.LADDER_FILE)


def table(results):
    """Rows for the screen."""
    rows = []
    for r in sorted(results, key=lambda r: -quality(r)):
        rows.append({"Model": f"{r['provider']}/{r['model']}", "Quality": round(100 * quality(r)),
                     **{t: (None if t not in r["scores"] else round(100 * r["scores"][t])) for t in TASKS_TEXT + TASKS_VISION},
                     "Starts in (s)": starts_in(r),
                     "Total seconds": typical_seconds(r) if r["seconds"] else None, "Cut off": r["cut_off"],
                     "Problems": "; ".join(r["errors"])[:80]})
    return rows
