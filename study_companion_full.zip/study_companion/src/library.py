"""
The library: COURSES and the material inside them.

A course works like a project: you create it (a name, an optional description, optional instructions for the
tutor), then you add material into it (PDFs, slide decks, lecture videos). Everything the student does stays
inside the course: the tutor, the quizzes, the dashboard, the progress (every course has its own learner
record) and the chat. A course may hold material of one subject or of many: you decide its scope.

Material can be moved from one course to another (its progress moves with it). Saving is permanent;
deleting a material or a whole course is a separate, confirmed action that removes everything made from it.

Older versions named a course after its first file. Such courses are kept and are shown like any other
(they disappear again if you delete their last file; courses you create yourself stay).
"""
import os
import sqlite3
import time

from src import store

_SCHEMA = """
CREATE TABLE IF NOT EXISTS doc_course (doc TEXT PRIMARY KEY, course TEXT);
CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, description TEXT DEFAULT '',
    instructions TEXT DEFAULT '', created REAL, auto INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS course_legacy (course_id INTEGER PRIMARY KEY);
"""

MAX_INSTRUCTIONS = 800          # characters of tutor instructions that are used


def _conn():
    conn = store._db()
    conn.executescript(_SCHEMA)
    return conn


def default_course_name(doc):
    stem = os.path.splitext(os.path.basename(doc))[0]
    return stem.replace("_", " ").replace("-", " ").strip() or "My course"


def _clean(name):
    return " ".join((name or "").split())


def _sync_rows(conn):
    """Every course name used by a document has a row in `courses` (older data had none)."""
    names = {r[0] for r in conn.execute("SELECT DISTINCT course FROM doc_course")}
    have = {r[0] for r in conn.execute("SELECT name FROM courses")}
    for name in names - have:
        conn.execute("INSERT INTO courses (name, created, auto) VALUES (?,?,1)", (name, time.time()))
    conn.commit()


def ensure_assigned():
    """Documents saved before courses existed get a course named after the file."""
    conn = _conn()
    have = {r[0] for r in conn.execute("SELECT doc FROM doc_course")}
    for (doc,) in conn.execute("SELECT doc FROM documents").fetchall():
        if doc not in have:
            conn.execute("INSERT INTO doc_course VALUES (?,?)", (doc, default_course_name(doc)))
    conn.commit()
    _sync_rows(conn)
    conn.close()


# =====================================================================
# 1. Creating, reading and changing courses
# =====================================================================
def create_course(name, description="", instructions=""):
    """Create an empty course. Returns its row. Raises ValueError for an empty or a taken name."""
    name = _clean(name)
    if not name:
        raise ValueError("Give the course a name.")
    conn = _conn()
    try:
        if conn.execute("SELECT 1 FROM courses WHERE name=? COLLATE NOCASE", (name,)).fetchone():
            raise ValueError(f"A course called '{name}' already exists.")
        conn.execute("INSERT INTO courses (name, description, instructions, created, auto) VALUES (?,?,?,?,0)",
                     (name, (description or "").strip(), (instructions or "").strip()[:MAX_INSTRUCTIONS], time.time()))
        conn.commit()
    finally:
        conn.close()
    return get_course(name)


def courses():
    """
    [{'course', 'id', 'description', 'instructions', 'docs': [names]}], the most recently active first.
    Courses with no material are included (a new course starts empty).
    """
    ensure_assigned()
    conn = _conn()
    rows = conn.execute("SELECT c.id, c.name, c.description, c.instructions, c.created, c.auto FROM courses c").fetchall()
    docs = conn.execute("SELECT c.course, c.doc, d.added FROM doc_course c JOIN documents d ON d.doc = c.doc "
                        "ORDER BY d.added DESC").fetchall()
    conn.close()
    by_course, latest = {}, {}
    for course, doc, added in docs:
        by_course.setdefault(course, []).append(doc)
        latest[course] = max(latest.get(course, 0), added or 0)
    out = [{"course": name, "id": cid, "description": desc or "", "instructions": instr or "",
            "docs": by_course.get(name, []), "auto": bool(auto), "_t": max(latest.get(name, 0), created or 0)}
           for cid, name, desc, instr, created, auto in rows
           if by_course.get(name) or not auto]            # an implicit course with no material is not shown
    out.sort(key=lambda c: -c["_t"])
    for c in out:
        c.pop("_t")
    return out


def get_course(name):
    for c in courses():
        if c["course"] == name:
            return c
    return None


def update_course(name, description=None, instructions=None, new_name=None):
    """Change a course's description, tutor instructions or name (its material and progress follow the rename)."""
    course = get_course(name)
    if not course:
        raise ValueError("That course does not exist.")
    conn = _conn()
    try:
        if description is not None:
            conn.execute("UPDATE courses SET description=?, auto=0 WHERE id=?", (description.strip(), course["id"]))
        if instructions is not None:
            conn.execute("UPDATE courses SET instructions=?, auto=0 WHERE id=?",
                         (instructions.strip()[:MAX_INSTRUCTIONS], course["id"]))
        new_name = _clean(new_name) if new_name is not None else None
        if new_name and new_name != name:
            if conn.execute("SELECT 1 FROM courses WHERE name=? COLLATE NOCASE AND id != ?", (new_name, course["id"])).fetchone():
                raise ValueError(f"A course called '{new_name}' already exists.")
            conn.execute("UPDATE courses SET name=?, auto=0 WHERE id=?", (new_name, course["id"]))
            conn.execute("UPDATE doc_course SET course=? WHERE course=?", (new_name, name))
        conn.commit()
    finally:
        conn.close()
    return get_course(new_name or name)


def instructions_of(course):
    c = get_course(course) if course else None
    return c["instructions"] if c else ""


# =====================================================================
# 2. Material and courses
# =====================================================================
def assign(doc, course):
    """Put a document into a course (created on the spot if it does not exist yet)."""
    course = _clean(course) or default_course_name(doc)
    conn = _conn()
    if not conn.execute("SELECT 1 FROM courses WHERE name=?", (course,)).fetchone():
        conn.execute("INSERT INTO courses (name, created, auto) VALUES (?,?,1)", (course, time.time()))
    conn.execute("INSERT OR REPLACE INTO doc_course VALUES (?,?)", (doc, course))
    conn.commit()
    conn.close()


def course_of(doc):
    conn = _conn()
    row = conn.execute("SELECT course FROM doc_course WHERE doc=?", (doc,)).fetchone()
    conn.close()
    return row[0] if row else default_course_name(doc)


def docs_in(course):
    """The documents of a course, or None (= everything) if no course is chosen."""
    if not course:
        return None
    c = get_course(course)
    return c["docs"] if c else None


def _doc_quiz_ids(doc):
    conn = _conn()
    try:
        return [r[0] for r in conn.execute("SELECT id FROM quiz_questions WHERE doc=?", (doc,))]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


def move_material(doc, to_course):
    """Move a document to another course. Your progress on it moves too. Returns how many answers moved."""
    from src import learner, outline
    old = course_of(doc)
    to_course = _clean(to_course)
    if not get_course(to_course):
        raise ValueError("That course does not exist.")
    if old == to_course:
        return 0
    old_student, new_student = student_for(old), student_for(to_course)
    topics = [t["topic"] for t in outline.topics(docs=[doc])]
    lc = learner._conn()
    moved = 0
    for q in _doc_quiz_ids(doc):
        moved += lc.execute("UPDATE OR IGNORE learner_events SET student=? WHERE student=? AND question_id=?",
                            (new_student, old_student, q)).rowcount
    for t in topics:                                         # tutor questions about its topics
        lc.execute("UPDATE learner_events SET student=? WHERE student=? AND topic=? AND source='tutor'",
                   (new_student, old_student, t))
    lc.commit()
    lc.close()
    conn = _conn()
    conn.execute("UPDATE doc_course SET course=? WHERE doc=?", (to_course, doc))
    conn.execute("UPDATE courses SET auto=0 WHERE name=?", (to_course,))
    conn.commit()
    conn.close()
    return moved


# =====================================================================
# 3. Each course has its own learner record
# =====================================================================
def student_for(course):
    """The learner-model id of a course: progress, intake and answers are kept per course."""
    from src import learner
    if not course:
        return learner.DEFAULT_STUDENT
    c = get_course(course)
    return f"course-{c['id']}" if c else learner.DEFAULT_STUDENT


def adopt_legacy(course):
    """
    Before courses were separate, all progress was stored under one shared student. The first time a course is
    opened, the answers that belong to its material move to the course's own record (and the intake is copied).
    Safe to call every time. Returns the number of answers moved.
    """
    from src import learner, outline
    c = get_course(course) if course else None
    if not c or not c["docs"]:
        return 0
    conn = _conn()
    done = conn.execute("SELECT 1 FROM course_legacy WHERE course_id=?", (c["id"],)).fetchone()
    conn.close()
    if done:
        return 0
    new = f"course-{c['id']}"
    qids = [q for d in c["docs"] for q in _doc_quiz_ids(d)]
    topics = [t["topic"] for t in outline.topics(docs=c["docs"])]
    lc = learner._conn()
    moved = 0
    for q in qids:
        moved += lc.execute("UPDATE OR IGNORE learner_events SET student=? WHERE student=? AND question_id=?",
                            (new, learner.DEFAULT_STUDENT, q)).rowcount
    for t in topics:
        lc.execute("UPDATE learner_events SET student=? WHERE student=? AND topic=? AND source='tutor'",
                   (new, learner.DEFAULT_STUDENT, t))
    lc.execute("INSERT OR IGNORE INTO learner_profile SELECT ?, level, goal, exam_date, created FROM learner_profile "
               "WHERE student=?", (new, learner.DEFAULT_STUDENT))
    cut = lc.execute("SELECT ts FROM learner_reset WHERE student=?", (learner.DEFAULT_STUDENT,)).fetchone()
    if cut:
        lc.execute("INSERT OR IGNORE INTO learner_reset VALUES (?,?)", (new, cut[0]))
    lc.commit()
    lc.close()
    conn = _conn()
    conn.execute("INSERT OR IGNORE INTO course_legacy VALUES (?)", (c["id"],))
    conn.commit()
    conn.close()
    return moved


# =====================================================================
# 4. Deleting
# =====================================================================
def delete_material(doc):
    """
    Delete one saved document and everything that came from it: its pages or slides or transcript, sections,
    topics, tags, search entries, the stored file, the quizzes made from it and the progress on its topics.
    Returns a short count of what was removed.
    """
    from src import learner, outline          # imported here: they import this package's store
    topics = [t["topic"] for t in outline.topics(docs=[doc])]
    owner = student_for(course_of(doc))
    conn = _conn()
    removed = {"quizzes": 0, "answers": 0}
    try:
        sets = [r[0] for r in conn.execute("SELECT DISTINCT set_id FROM quiz_questions WHERE doc=?", (doc,))]
        for sid in sets:
            qids = [r[0] for r in conn.execute("SELECT id FROM quiz_questions WHERE set_id=?", (sid,))]
            for q in qids:
                removed["answers"] += conn.execute("DELETE FROM quiz_answers WHERE question_id=?", (q,)).rowcount
                conn.execute("DELETE FROM learner_events WHERE question_id=?", (q,))
            conn.execute("DELETE FROM quiz_questions WHERE set_id=?", (sid,))
            conn.execute("DELETE FROM quiz_sets WHERE id=?", (sid,))
        removed["quizzes"] = len(sets)
    except sqlite3.OperationalError:
        pass                                       # no quiz tables yet
    try:
        conn.execute("DELETE FROM doc_outline WHERE doc=?", (doc,))
    except sqlite3.OperationalError:
        pass
    conn.execute("DELETE FROM doc_course WHERE doc=?", (doc,))
    conn.execute("DELETE FROM doc_meta WHERE doc=?", (doc,))
    conn.commit()
    conn.close()
    try:                                           # progress on topics that only existed in this document (this course only)
        conn = learner._conn()
        for t in topics:
            conn.execute("DELETE FROM learner_events WHERE topic=? AND student IN (?,?)",
                         (t, owner, learner.DEFAULT_STUDENT))
        conn.commit()
        conn.close()
    except sqlite3.OperationalError:
        pass
    store.delete_doc(doc)
    path = store.file_path(doc)
    if os.path.exists(path):
        os.remove(path)
    return removed


def delete_course(name):
    """Delete a course with all its material, its progress and its settings. Returns the counts."""
    from src import learner
    course = get_course(name)
    if not course:
        return {"materials": 0, "quizzes": 0, "answers": 0}
    owner = student_for(name)
    total = {"materials": 0, "quizzes": 0, "answers": 0}
    for doc in list(course["docs"]):
        r = delete_material(doc)
        total["materials"] += 1
        total["quizzes"] += r["quizzes"]
        total["answers"] += r["answers"]
    try:
        lc = learner._conn()
        for table in ("learner_events", "learner_profile", "learner_reset"):
            lc.execute(f"DELETE FROM {table} WHERE student=?", (owner,))
        lc.commit()
        lc.close()
    except sqlite3.OperationalError:
        pass
    conn = _conn()
    conn.execute("DELETE FROM courses WHERE id=?", (course["id"],))
    conn.execute("DELETE FROM course_legacy WHERE course_id=?", (course["id"],))
    conn.commit()
    conn.close()
    return total
