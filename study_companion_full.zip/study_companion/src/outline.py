"""
Document outline: ONE helper model reads the structure of a whole uploaded document and sorts it.

Why: the tutor and the quiz must work for ANY document, not for one textbook style. So nothing here
depends on how a particular book numbers its headings.

HOW IT WORKS
  1. code   : the headings, levels, pages, word counts, tags (key concepts) and the first words of every
              unit are already saved by the upload step. They are turned into a compact outline.
  2. helper : a language model gets the outline (in windows of WINDOW units) and says, for every unit,
              its ROLE (title, section, subsection, example, exercise, summary, other) and the TOPIC it
              belongs to. Topics are groups of neighbouring sections a student can be quizzed on.
  3. code   : checks the answer (unknown ids ignored, exercises/summaries get no topic, topic names are
              reused across windows, missing units are filled by the rules below) and saves it in the
              table doc_outline, one row per unit.
  4. rules  : if no model answers, a style-agnostic rule set sorts the document instead (heading levels
              and a few common words such as Example, Exercises, Summary). The table says which was used.

The tutor reads the roles (to avoid examples and exercises for concept questions) and the quiz reads the
topics (to list sections and to tag every question). Nothing else in the app guesses roles any more.
"""
import re
import sqlite3
from collections import Counter

from src import llm, store

WINDOW = 250                   # units per helper call (the helper models read very long inputs)
HELPER_TOKENS = 6000
MIN_PARSED_SHARE = 0.6         # a helper reply that covers less than this share of a window is not trusted

ROLES = ("title", "section", "subsection", "example", "exercise", "summary", "fragment", "other")
ROLE_NAMES = {"title": "Title", "section": "Section", "subsection": "Subsection", "example": "Example",
              "exercise": "Exercise", "summary": "Summary", "fragment": "Fragment", "other": "Other"}
TOPIC_ROLES = ("section", "subsection", "example")     # only these can belong to a topic
MIN_TOPIC_WORDS = 30           # a "topic" with less teaching text than this (a title page, a greeting) is not a topic
_FRONT_MATTER = re.compile(
    r"bless|dedicat|welcome|greeting|acknowledg|thank|disclaimer|copyright|^dear\b|^gifted\b|\bgifted with\b|"
    r"^(a )?(message|note|word)s? (from|of|to)\b|^about (the|this) (book|author|course|material|document|pdf)\b|"
    r"^how to (use|read) (this|the)\b|^(instructions?|disclaimer|foreword|preface|contents)$", re.I)


def looks_like_front_matter(name):
    """True for names such as 'Gifted with Blessings ...', 'Dedication', 'Message from the author'."""
    return bool(_FRONT_MATTER.search((name or "").strip()))
_KIND_FROM_ROLE = {"example": "example", "exercise": "exercise", "summary": "summary", "other": "other",
                   "title": "other", "section": "text", "subsection": "text",
                   "fragment": "text"}        # a fragment is debris in the heading, but its text is real body text

OUTLINE_SYSTEM = """You sort the structure of a study document (a textbook, lecture slides, a video transcript). It was read from a PDF, slides or captions by software that makes mistakes, so some "headings" are really debris. You get the units in document order, one per line: id | heading level | location | words | heading | key concepts | how the text starts.
Give every unit a ROLE:
title = the title of the whole document, or of a chapter or part
section = a main section that teaches something
subsection = a deeper part of a section
example = a worked or solved example, a case study, or a solution
exercise = questions or problems for the student to try: exercises, review or in-text questions, points to ponder, practice sets, assignments
summary = a recap: summary, key points, takeaways, glossary of terms
fragment = debris mistaken for a heading: a piece of an equation or symbols, a figure or table label, a page number, a running header, a stray letter or number. Its text is real and belongs to the section above it. Lines marked [suspect] very probably are fragments
other = contents, preface, references, index, acknowledgements, appendix
Also group the teaching units into TOPICS. A topic is something a student could be quizzed on with 5 to 10 questions. Put neighbouring sections and subsections that explain the same idea into one topic. Do not make one topic per heading and do not make one huge topic: aim for about one topic per 2 to 6 sections. Topic names are short noun phrases made of real words, in the document's own words; never use a fragment, a number or a formula as a topic name. An example or fragment belongs to the topic of the unit just above it. Units with the role title, exercise, summary or other get no topic (write -). If a unit continues a topic listed under "Topics so far", reuse that exact name.
Reply in exactly this format and nothing else:
Topics:
T1 = name
T2 = name
Units:
id | role | T1
id | role | -
Write one Units line for every unit you were given, in the same order."""


# =====================================================================
# 1. Text helpers
# =====================================================================
def tidy(heading):
    """Show a heading nicely: one line, and Title Case if it was shouted in capitals."""
    h = " ".join((heading or "").split())
    return " ".join(w.capitalize() for w in h.split()) if h.isupper() else h


def _key(name):
    return re.sub(r"[^a-z0-9]+", " ", (name or "").lower()).strip()


_WORD_RULES = [
    ("example", r"^(solved |worked )?examples?\b|^solutions?\b|^case stud"),
    ("exercise", r"exercise|intext|in-text|^questions?\b|review questions|practice|ponder|assignment|worksheet|^problems?$"),
    ("summary", r"^summary\b|^chapter summary|recap|key (points|takeaways)|^glossary"),
    ("other", r"^contents?$|table of contents|preface|^references?$|^bibliography|^index$|acknowledg|^appendix|^foreword"),
]


def looks_like_fragment(heading):
    """True if a 'heading' has no real word in it: formula pieces, symbols, lone letters or numbers."""
    h = (heading or "").strip()
    if not h:
        return True
    if not re.search(r"[A-Za-z\u0900-\u097F]{3,}", h):                 # a real word of 3+ letters (English or Hindi)
        return True
    letters = len(re.findall(r"[A-Za-z\u0900-\u097F]", h))
    chars = len(re.sub(r"\s", "", h))
    return chars > 0 and letters / chars < 0.35


def word_role(heading):
    """Role from a few common words in the heading, or None. Only used when no model has sorted the document."""
    h = (heading or "").strip().lower()
    for role, pattern in _WORD_RULES:
        if re.search(pattern, h):
            return role
    return None


# =====================================================================
# 2. The rule-based outline (no model): heading levels and common words only
# =====================================================================
def rules_outline(units, doc=""):
    """{unit_id: (role, topic name or None)} for a document, with no model and no numbering assumptions."""
    special = {u["id"]: word_role(u["heading"]) for u in units}
    for u in units:
        if special[u["id"]] is None and looks_like_fragment(u["heading"]) and u["level"] >= 1:
            special[u["id"]] = "fragment"
    cand = [u for u in units if u["level"] >= 1 and special[u["id"]] is None]
    topic_level, title_level = None, None
    if cand:
        counts = Counter(u["level"] for u in cand)
        levels = sorted(counts)
        if len(levels) > 1 and counts[levels[0]] <= 2:       # one or two top headings = a title, not topics
            title_level, topic_level = levels[0], levels[1]
        else:
            topic_level = levels[0]
    stem = re.sub(r"\.[A-Za-z0-9]+$", "", doc) or "Document"

    out, current = {}, None
    for u in units:
        uid, lvl, role = u["id"], u["level"], special[u["id"]]
        if topic_level is None:                              # a document without any usable heading
            out[uid] = ("section", stem) if role is None else (role, None)
            continue
        if lvl == 0 and role is None:
            out[uid] = ("other", None)                       # text before the first heading
        elif role in ("exercise", "summary", "other"):
            out[uid] = (role, None)
            if lvl <= topic_level:
                current = None                               # these end the topic that was running
        elif role == "fragment":
            out[uid] = ("fragment", current)                 # part of the section above it
        elif role == "example":
            out[uid] = ("example", current)
        elif title_level is not None and lvl == title_level:
            out[uid] = ("title", None)
            current = None
        elif lvl <= topic_level:
            current = tidy(u["heading"])
            out[uid] = ("section", current)
        else:
            if current is None:
                current = tidy(u["heading"])
            out[uid] = ("subsection", current)
    return out


# =====================================================================
# 3. Reading the helper model's reply
# =====================================================================
_ROLE_WORDS = (("title", "title"), ("subsection", "subsection"), ("sub", "subsection"), ("section", "section"),
               ("example", "example"), ("solution", "example"), ("exercise", "exercise"),
               ("summary", "summary"), ("fragment", "fragment"), ("debris", "fragment"), ("other", "other"))


def _role_from_word(word):
    w = (word or "").strip().lower()
    return next((role for key, role in _ROLE_WORDS if w.startswith(key)), None)


def parse_outline(text, valid_ids):
    """Returns (topic names {number: name}, rows {unit_id: (role, topic number or None)})."""
    topics, rows = {}, {}
    for raw in (text or "").splitlines():
        line = raw.strip().strip("*`").strip()
        line = re.sub(r"^[-•*]\s+", "", line)
        m = re.match(r"^T\s*(\d+)\s*[=:]\s*(.+)$", line, re.I)
        if m:
            topics[int(m.group(1))] = tidy(m.group(2).strip(" *`"))
            continue
        m = re.match(r"^(\d+)\s*\|\s*([A-Za-z ]+?)\s*\|\s*(?:T\s*(\d+)\b)?", line, re.I)
        if m and int(m.group(1)) in valid_ids:
            role = _role_from_word(m.group(2))
            if role:
                rows[int(m.group(1))] = (role, int(m.group(3)) if m.group(3) else None)
    return topics, rows


# =====================================================================
# 4. Storage
# =====================================================================
_SCHEMA = """CREATE TABLE IF NOT EXISTS doc_outline (
    unit_id INTEGER PRIMARY KEY, doc TEXT, role TEXT, topic_no INTEGER, topic TEXT, source TEXT);"""


def _conn():
    conn = sqlite3.connect(store.DB_PATH)
    conn.executescript(_SCHEMA)
    return conn


def _save(doc, units, result, source_of):
    """result {unit_id: (role, topic or None)}; topics are numbered in order of first appearance."""
    numbers = {}
    conn = _conn()
    conn.execute("DELETE FROM doc_outline WHERE doc=?", (doc,))
    for u in units:
        role, topic = result[u["id"]]
        no = None
        if topic:
            no = numbers.setdefault(_key(topic), len(numbers) + 1)
        conn.execute("INSERT INTO doc_outline VALUES (?,?,?,?,?,?)",
                     (u["id"], doc, role, no, topic, source_of[u["id"]]))
    conn.commit()
    conn.close()


def has_outline(doc):
    units = store.units_for(doc)
    conn = _conn()
    n = conn.execute("SELECT COUNT(*) FROM doc_outline WHERE doc=? AND unit_id IN (SELECT id FROM pdf_units WHERE doc=?)",
                     (doc, doc)).fetchone()[0]
    conn.close()
    return bool(units) and n == len(units)


def ensure_rules(doc):
    """Make sure a document has an outline: if it has none yet, sort it by rules (instant, no model)."""
    if has_outline(doc):
        return
    units = store.units_for(doc)
    if units:
        _save(doc, units, rules_outline(units, doc), {u["id"]: "rules" for u in units})


def source_of(doc):
    """'rules', or the helper model name(s) that sorted this document ('' if not sorted yet)."""
    conn = _conn()
    rows = conn.execute("SELECT DISTINCT source FROM doc_outline WHERE doc=? AND unit_id IN "
                        "(SELECT id FROM pdf_units WHERE doc=?)", (doc, doc)).fetchall()
    conn.close()
    names = sorted(r[0] for r in rows)
    return ", ".join(names)


def load_roles():
    """{unit_id: role} for every unit that has been sorted."""
    conn = _conn()
    rows = conn.execute("SELECT unit_id, role FROM doc_outline").fetchall()
    conn.close()
    return {r[0]: r[1] for r in rows}


def kind_of(chunk, roles=None):
    """The tutor's old vocabulary (text / example / exercise / summary / other) from the saved role."""
    role = (roles or {}).get(chunk.get("unit_id")) or word_role(chunk.get("heading", "")) or "section"
    return _KIND_FROM_ROLE[role]


def _concepts(unit_ids, tags, limit=6):
    seen = []
    for uid in unit_ids:
        for c in (tags.get(uid) or "").split(";"):
            c = c.strip()
            if c and _key(c) not in [_key(x) for x in seen]:
                seen.append(c)
    return seen[:limit]


def topics(docs=None):
    """
    The topic list for the Quiz tab, in book order (docs = limit to these documents, None = all):
    [{'topic', 'doc', 'page_start', 'page_end', 'unit_ids', 'concepts'}]. Documents that were never sorted
    are sorted by rules on the spot.
    """
    for d in store.list_docs():
        ensure_rules(d["file"])
    only = set(docs) if docs is not None else None
    conn = _conn()
    try:
        rows = conn.execute(
            "SELECT o.unit_id, o.doc, o.topic_no, o.topic, u.page_start, u.page_end, "
            "LENGTH(u.text) - LENGTH(REPLACE(u.text, ' ', '')) + 1 "
            "FROM doc_outline o JOIN pdf_units u ON u.id = o.unit_id "
            "WHERE o.topic IS NOT NULL ORDER BY o.doc, o.unit_id").fetchall()
        tags = {r[0]: r[1] for r in conn.execute("SELECT unit_id, concepts FROM unit_tags")}
    except sqlite3.OperationalError:
        rows, tags = [], {}
    conn.close()
    found, index = [], {}
    for uid, doc, no, name, p0, p1, words in rows:
        if only is not None and doc not in only:
            continue
        key = (doc, no)
        if key not in index:
            index[key] = {"topic": name, "doc": doc, "page_start": p0, "page_end": p1, "unit_ids": [], "words": 0}
            found.append(index[key])
        sec = index[key]
        sec["unit_ids"].append(uid)
        sec["words"] += words or 0
        sec["page_start"], sec["page_end"] = min(sec["page_start"], p0), max(sec["page_end"], p1)
    # not a topic: front matter (blessings, greetings, dedications) or too little teaching text to ask questions about
    found = [sec for sec in found if sec["words"] >= MIN_TOPIC_WORDS and not looks_like_front_matter(sec["topic"])]
    names = Counter(s["topic"] for s in found)
    for sec in found:
        if names[sec["topic"]] > 1:                           # the same topic name in two documents
            sec["topic"] = f"{sec['topic']} ({sec['doc']})"
        sec["concepts"] = _concepts(sec["unit_ids"], tags)
    return found


def topic_rows(doc=None, docs=None):
    """The topic list as display rows, in book order: [{'topic', 'doc', 'pages', 'concepts'}]."""
    kinds = store.doc_types()
    rows = []
    for t in topics(docs):
        if doc is not None and t["doc"] != doc:
            continue
        where = store.loc_label(kinds.get(t["doc"], "pdf"), t["page_start"], t["page_end"])
        rows.append({"topic": t["topic"], "doc": t["doc"], "where": where,
                     "pages": where.split(" ", 1)[1] if " " in where else where,     # "3-7", "2", "5:00-10:00"
                     "concepts": "; ".join(t["concepts"])})
    return rows


def table(doc):
    """Rows for the Knowledge base tab: the sorted outline of one document, in document order."""
    ensure_rules(doc)
    conn = _conn()
    rows = conn.execute(
        "SELECT u.heading, u.level, u.page_start, u.page_end, o.role, o.topic, t.concepts, t.prerequisites "
        "FROM pdf_units u JOIN doc_outline o ON o.unit_id = u.id LEFT JOIN unit_tags t ON t.unit_id = u.id "
        "WHERE u.doc=? ORDER BY u.id", (doc,)).fetchall()
    conn.close()
    kind = store.doc_type(doc)
    return [{"Heading": "· " * max(r[1] - 1, 0) + tidy(r[0]), "Level": r[1],
             "Where": store.loc_label(kind, r[2], r[3]), "Role": ROLE_NAMES.get(r[4], r[4]),
             "Topic": r[5] or "", "Key concepts": r[6] or "", "Prerequisites": r[7] or ""} for r in rows]


# =====================================================================
# 5. Asking the helper model
# =====================================================================
def _outline_lines(window, tags, kind="pdf"):
    lines = []
    for u in window:
        words = u["text"].split()
        concepts = "; ".join([c.strip() for c in (tags.get(u["id"]) or "").split(";") if c.strip()][:6])
        where = store.loc_label(kind, u["page_start"], u["page_end"])
        mark = " [suspect]" if looks_like_fragment(u["heading"]) else ""
        lines.append(f"{u['id']} | L{u['level']} | {where} | {len(words)}w | {tidy(u['heading'])[:90]}{mark} | "
                     f"{concepts[:90] or '-'} | {' '.join(words[:12])}")
    return lines


def build(doc, progress=None, force=False):
    """
    Sort one saved document with the helper model and save the result. Returns a short note for the
    screen ('' when everything went well). With force=False a document that is already sorted is skipped;
    one that was only sorted by rules is sorted again by the model.
    """
    units = store.units_for(doc)
    if not units:
        return ""
    if not force and has_outline(doc) and source_of(doc) != "rules":
        return ""
    conn = _conn()
    tag_rows = {r[0]: r[1] for r in conn.execute(
        "SELECT unit_id, concepts FROM unit_tags WHERE unit_id IN (SELECT id FROM pdf_units WHERE doc=?)", (doc,))}
    conn.close()

    rules = rules_outline(units, doc)
    windows = [units[i:i + WINDOW] for i in range(0, len(units), WINDOW)]
    canonical = {}                    # topic key -> the name used everywhere
    result, source = {}, {}
    models, rule_units = [], 0
    last_topic = None

    for w_no, win in enumerate(windows, start=1):
        ids = {u["id"] for u in win}
        parsed_ok, topic_names, rows = False, {}, {}
        try:
            so_far = "; ".join(list(canonical.values())[-15:]) or "(none yet)"
            r = llm.ask("outline", [
                {"role": "system", "content": OUTLINE_SYSTEM},
                {"role": "user", "content": f"Document: {doc}\nTopics so far: {so_far}\n\nUnits:\n"
                                            + "\n".join(_outline_lines(win, tag_rows, store.doc_type(doc)))}],
                max_tokens=HELPER_TOKENS, use_cache=not force)
            topic_names, rows = parse_outline(r["text"], ids)
            parsed_ok = len(rows) >= MIN_PARSED_SHARE * len(win)
            if parsed_ok and r["model"] not in models:
                models.append(r["model"])
        except llm.AllModelsBusy:
            pass

        for u in win:
            uid = u["id"]
            if parsed_ok and uid in rows:
                role, no = rows[uid]
                if role in ("section", "subsection") and looks_like_fragment(u["heading"]):
                    role = "fragment"                         # a guard: debris is never a section, whatever the helper said
                topic = None
                if role in TOPIC_ROLES or role == "fragment":
                    topic = topic_names.get(no) if no else None
                    if topic and looks_like_fragment(topic):
                        topic = None                          # a topic name must be made of real words
                    if not topic and role in ("subsection", "example", "fragment"):
                        topic = last_topic                    # belongs to what is just above it
                    if not topic and role == "section":
                        topic = tidy(u["heading"]) if not looks_like_fragment(u["heading"]) else last_topic
                source[uid] = models[-1] if models else "rules"
            else:
                role, topic = rules[uid]
                source[uid] = "rules"
                rule_units += 1
            if topic:
                topic = canonical.setdefault(_key(topic), topic)
                last_topic = topic
            elif role in ("exercise", "summary", "other", "title"):
                last_topic = None
            result[uid] = (role, topic)
        if progress:
            progress(w_no, len(windows))

    if not any(t for _, t in result.values()):                # the helper produced no topic at all
        result, source = rules, {u["id"]: "rules" for u in units}
        rule_units = len(units)
    _save(doc, units, result, source)

    if rule_units == len(units):
        return "No helper model was available, so the document outline was sorted by simple rules instead."
    if rule_units:
        return f"{rule_units} of {len(units)} units could not be sorted by the helper model and were sorted by rules."
    return ""
