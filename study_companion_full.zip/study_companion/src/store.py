"""
SQLite storage for the knowledge base.

Tables
  documents  one row per uploaded file
  pdf_units  heading-based units of PDFs      (slides and videos get their own
                                               tables later: slide_units, video_units)
  chunks     the ONE shared search table: text pieces + their vectors, for every
             source type. This is the shared search index.
"""
import os
import sqlite3
import time
from collections import Counter

import numpy as np

DB_PATH = "data/app.db"
FILES_DIR = "data/files"


def _db():
    folder = os.path.dirname(DB_PATH)
    if folder:
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS documents (
        doc TEXT PRIMARY KEY, source_type TEXT, n_pages INTEGER, added REAL);
    CREATE TABLE IF NOT EXISTS pdf_units (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc TEXT, heading TEXT, level INTEGER,
        path TEXT, page_start INTEGER, page_end INTEGER, text TEXT);
    CREATE TABLE IF NOT EXISTS unit_tags (
        unit_id INTEGER PRIMARY KEY, topic TEXT, concepts TEXT, prerequisites TEXT);
    CREATE TABLE IF NOT EXISTS chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, source_type TEXT, unit_id INTEGER,
        doc TEXT, heading TEXT, path TEXT, page_start INTEGER, page_end INTEGER,
        text TEXT, embed_model TEXT, dim INTEGER, vector BLOB);
    CREATE TABLE IF NOT EXISTS doc_meta (doc TEXT PRIMARY KEY, url TEXT, extra TEXT);
    """)
    return conn


def delete_doc(doc):
    conn = _db()
    conn.execute("DELETE FROM unit_tags WHERE unit_id IN (SELECT id FROM pdf_units WHERE doc=?)", (doc,))
    for table in ("pdf_units", "chunks", "documents"):
        conn.execute(f"DELETE FROM {table} WHERE doc=?", (doc,))
    conn.commit()
    conn.close()


def save_pdf(doc, n_pages, units_with_chunks, vectors, model_name, source_type="pdf"):
    """
    units_with_chunks = [{'unit': unit_dict, 'chunks': [chunk_dict, ...]}, ...]
    vectors = array with one row per chunk, in the same order.
    Saving the same file name again replaces the old copy.
    source_type is 'pdf', 'slide' or 'video'. The two "page" numbers of a unit and chunk are then
    pages, slide numbers, or seconds from the start of the video (see loc_label).
    """
    delete_doc(doc)
    conn = _db()
    conn.execute("INSERT INTO documents VALUES (?,?,?,?)", (doc, source_type, n_pages, time.time()))
    row = 0
    n_chunks = 0
    for item in units_with_chunks:
        u = item["unit"]
        cur = conn.execute(
            "INSERT INTO pdf_units (doc, heading, level, path, page_start, page_end, text) "
            "VALUES (?,?,?,?,?,?,?)",
            (doc, u["heading"], u["level"], u["path"], u["page_start"], u["page_end"], u["text"]))
        unit_id = cur.lastrowid
        for c in item["chunks"]:
            vec = np.asarray(vectors[row], dtype="float32")
            conn.execute(
                "INSERT INTO chunks (source_type, unit_id, doc, heading, path, page_start, "
                "page_end, text, embed_model, dim, vector) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (source_type, unit_id, doc, u["heading"], u["path"], c["page_start"], c["page_end"],
                 c["text"], model_name, len(vec), vec.tobytes()))
            row += 1
            n_chunks += 1
    conn.commit()
    conn.close()
    return {"units": len(units_with_chunks), "chunks": n_chunks}


def fmt_time(seconds):
    seconds = int(max(0, seconds))
    h, rest = divmod(seconds, 3600)
    m, sec = divmod(rest, 60)
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m}:{sec:02d}"


def loc_label(source_type, start, end=None):
    """Where something comes from, in the words of its kind: 'page 5', 'slide 12', '12:34-13:10'."""
    end = start if end is None else end
    if source_type == "video":
        a, b = fmt_time(start), fmt_time(end)
        return a if a == b else f"{a}-{b}"
    word = "slide" if source_type == "slide" else "page"
    return f"{word} {start}" if start == end else f"{word}s {start}-{end}"


def doc_type(doc):
    conn = _db()
    row = conn.execute("SELECT source_type FROM documents WHERE doc=?", (doc,)).fetchone()
    conn.close()
    return row[0] if row else "pdf"


def doc_types():
    conn = _db()
    out = dict(conn.execute("SELECT doc, source_type FROM documents").fetchall())
    conn.close()
    return out


def set_meta(doc, url="", extra=""):
    conn = _db()
    conn.execute("INSERT OR REPLACE INTO doc_meta VALUES (?,?,?)", (doc, url, extra))
    conn.commit()
    conn.close()


def get_meta(doc):
    conn = _db()
    row = conn.execute("SELECT url, extra FROM doc_meta WHERE doc=?", (doc,)).fetchone()
    conn.close()
    return {"url": row[0], "extra": row[1]} if row else {"url": "", "extra": ""}


def list_docs():
    conn = _db()
    rows = conn.execute("""
        SELECT d.doc, d.source_type, d.n_pages,
               (SELECT COUNT(*) FROM pdf_units u WHERE u.doc = d.doc),
               (SELECT COUNT(*) FROM chunks c WHERE c.doc = d.doc),
               (SELECT MIN(embed_model) FROM chunks c WHERE c.doc = d.doc)
        FROM documents d ORDER BY d.added DESC""").fetchall()
    conn.close()
    return [{"file": r[0], "type": r[1], "pages": r[2], "units": r[3],
             "chunks": r[4], "embedding model": r[5]} for r in rows]


def load_chunks():
    """
    Return (rows, matrix, model_name, skipped).
    Only chunks made with the most common embedding model are used, because
    vectors from different models cannot be compared. `skipped` counts the rest.
    """
    conn = _db()
    models = Counter(m for (m,) in conn.execute("SELECT embed_model FROM chunks"))
    if not models:
        conn.close()
        return [], None, None, 0
    model = models.most_common(1)[0][0]
    cur = conn.execute(
        "SELECT id, source_type, unit_id, doc, heading, path, page_start, page_end, text, "
        "dim, vector FROM chunks WHERE embed_model=? ORDER BY id", (model,))
    rows, vecs = [], []
    for r in cur:
        rows.append({"id": r[0], "source_type": r[1], "unit_id": r[2], "doc": r[3],
                     "heading": r[4], "path": r[5], "page_start": r[6], "page_end": r[7],
                     "text": r[8]})
        vecs.append(np.frombuffer(r[10], dtype="float32"))
    conn.close()
    return rows, np.vstack(vecs), model, sum(models.values()) - len(rows)


# ---------- the uploaded files themselves (needed to show the exact cited page) ----------
def file_path(name):
    return os.path.join(FILES_DIR, os.path.basename(name))


def has_file(name):
    return os.path.exists(file_path(name))


def save_file(name, data):
    os.makedirs(FILES_DIR, exist_ok=True)
    with open(file_path(name), "wb") as fh:
        fh.write(data)


# ---------- units and their topic / concept tags ----------
def units_for(doc):
    conn = _db()
    rows = conn.execute("SELECT id, heading, level, path, page_start, page_end, text FROM pdf_units "
                        "WHERE doc=? ORDER BY id", (doc,)).fetchall()
    conn.close()
    return [{"id": r[0], "heading": r[1], "level": r[2], "path": r[3],
             "page_start": r[4], "page_end": r[5], "text": r[6]} for r in rows]


def untagged_units(doc):
    conn = _db()
    rows = conn.execute("SELECT u.id, u.heading, u.text FROM pdf_units u "
                        "LEFT JOIN unit_tags t ON t.unit_id = u.id "
                        "WHERE u.doc=? AND t.unit_id IS NULL ORDER BY u.id", (doc,)).fetchall()
    conn.close()
    return [{"id": r[0], "heading": r[1], "text": r[2]} for r in rows]


def save_tags(tags):
    """tags = {unit_id: {'topic', 'concepts': [...], 'prerequisites': [...]}}"""
    conn = _db()
    for unit_id, t in tags.items():
        conn.execute("INSERT OR REPLACE INTO unit_tags VALUES (?,?,?,?)",
                     (unit_id, t["topic"], "; ".join(t["concepts"]), "; ".join(t["prerequisites"])))
    conn.commit()
    conn.close()


def tag_table(doc):
    conn = _db()
    rows = conn.execute("SELECT u.heading, u.page_start, u.page_end, t.topic, t.concepts, t.prerequisites "
                        "FROM pdf_units u JOIN unit_tags t ON t.unit_id = u.id "
                        "WHERE u.doc=? ORDER BY u.id", (doc,)).fetchall()
    conn.close()
    return [{"section": r[0], "pages": f"{r[1]}-{r[2]}", "topic": r[3],
             "key concepts": r[4], "prerequisites": r[5]} for r in rows]
