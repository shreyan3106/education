"""
Showing where something comes from, in the words of its kind of material:
  PDF    "page 7"        -> the page drawn as a picture
  slide  "slide 12"      -> a card with the slide's title, text, notes and pictures
  video  "12:34-13:10"   -> the video player, starting at that second, with the transcript of that moment
"""
import streamlit as st

from src import slides, store
from src.pages import render_page


@st.cache_data(show_spinner=False)
def _pdf_png(doc, page, highlight):
    return render_page(doc, page, highlight)


def where(doc, start, end=None):
    return store.loc_label(store.doc_type(doc), start, end)


def show_source(doc, start, end=None, key="", highlight=None, heading=""):
    """A button 'Open <where>' that reveals the source below it."""
    kind = store.doc_type(doc)
    label = where(doc, start, end)
    flag = f"open-{key}"
    if st.button(f"Open {label}", key=f"btn-{flag}"):
        st.session_state[flag] = not st.session_state.get(flag, False)
    if not st.session_state.get(flag):
        return
    if kind == "slide":
        card = slides.card(doc, start)
        if not card:
            st.info("That slide is no longer available.")
            return
        st.markdown(f"**{card['title']}**")
        if card["text"]:
            st.markdown(card["text"])
        for path in card["images"]:
            st.image(path)
        if card["notes"]:
            st.caption("Speaker notes: " + card["notes"])
    elif kind == "video":
        url = store.get_meta(doc)["url"]
        if url:
            st.video(url, start_time=int(start))
        else:
            st.info("The link of this video was not saved.")
        text = _transcript(doc, start, end if end is not None else start)
        if text:
            st.caption(text)
    else:
        img = _pdf_png(doc, start, highlight)
        if img:
            st.image(img, caption=f"{doc}, {label}")
        else:
            st.info("The original file is not saved. Upload the PDF again to see its pages.")


def _transcript(doc, start, end, limit=900):
    conn = store._db()
    rows = conn.execute("SELECT text FROM chunks WHERE doc=? AND page_end>=? AND page_start<=? ORDER BY page_start LIMIT 3",
                        (doc, start, max(start, end))).fetchall()
    conn.close()
    return " ".join(r[0] for r in rows)[:limit]
