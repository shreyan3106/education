"""
Step 1 of the knowledge base: read a PDF and split it into units by headings.

Idea ("option B"): do not hard-code one book's style. Learn the document's own
body style, then treat short rows written in a clearly different style
(different font / colour / bigger size / bold / numbered) as headings.
"""
import re
from collections import Counter

# ---------- settings you can tune ----------
MAX_HEADING_WORDS = 15     # a heading is short
MIN_HEADING_CHARS = 3      # ignore single symbols such as a delta or an arrow
HEADING_MIN_SCORE = 2      # points needed to call a row a heading
REPEAT_MIN_PAGES = 3       # text seen on at least this many pages ...
REPEAT_MIN_SHARE = 0.3     # ... and on this share of all pages = header/footer
MARGIN_SHIFT = 8           # lets a heading in the side margin sort before the
                           # body text that sits beside it
SMALL_TEXT_RATIO = 0.8     # rows smaller than this x body size = sub/superscript

NUMBERING = re.compile(r"^\d+(\.\d+)*\.?\s")
NUMBER_PREFIX = re.compile(r"^(\d+(?:\.\d+)*)")
CAPTION = re.compile(r"^(fig(ure)?\.?|table)\s*\d", re.IGNORECASE)
BOLD_WORDS = ("bold", "demi", "black", "heavy")


# ---------- small helpers ----------
def _style(span):
    return (span["font"], round(span["size"], 1), span["color"])


def _line_text(line):
    return "".join(s["text"] for s in line["spans"]).strip()


def _plain_text(block):
    return " ".join(_line_text(l) for l in block["lines"]).strip()


def _block_styles(block):
    counts = Counter()
    for line in block["lines"]:
        for s in line["spans"]:
            counts[_style(s)] += len(s["text"].strip())
    return counts


def _read_blocks(page):
    """Raw PyMuPDF page data -> simple list of text blocks (repeats removed)."""
    seen = set()
    blocks = []
    for raw in page["blocks"]:
        if raw.get("type") != 0:          # 0 = text, 1 = image
            continue
        lines = []
        for line in raw["lines"]:
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in spans)
            # some PDFs draw the same text 5 times to fake bold: keep one copy
            key = (int(line["bbox"][0] // 3), int(line["bbox"][1] // 3), text)
            if key in seen:
                continue
            seen.add(key)
            lines.append({"spans": spans, "bbox": line["bbox"]})
        if lines:
            blocks.append({"page": page["number"], "height": page["height"],
                           "lines": lines, "bbox": raw["bbox"]})
    return blocks


def _drop_repeated(blocks, n_pages):
    """Remove running headers, footers and page numbers."""
    pages_seen = {}
    for b in blocks:
        text = _plain_text(b)
        key = (re.sub(r"\d+", "", text).strip().lower(), int(b["bbox"][1] // 10))
        pages_seen.setdefault(key, set()).add(b["page"])

    kept, dropped = [], []
    for b in blocks:
        text = _plain_text(b)
        key = (re.sub(r"\d+", "", text).strip().lower(), int(b["bbox"][1] // 10))
        y = b["bbox"][1]
        in_margin = y > 0.88 * b["height"] or y < 0.06 * b["height"]
        repeated = (
            len(text.split()) <= 8
            and len(pages_seen[key]) >= REPEAT_MIN_PAGES
            and len(pages_seen[key]) >= REPEAT_MIN_SHARE * n_pages
        )
        page_number = text.isdigit() and in_margin
        if repeated or page_number:
            dropped.append(f"p.{b['page']}: {text}")
        else:
            kept.append(b)
    return kept, dropped


def _body_style(blocks):
    counts = Counter()
    for b in blocks:
        counts.update(_block_styles(b))
    return counts.most_common(1)[0][0] if counts else ("", 0, 0)


def _heading_score(block, body):
    """Return 0 if the block cannot be a heading, else points for the clues."""
    styles = _block_styles(block)
    if body in styles:                 # contains normal body text -> a paragraph
        return 0
    text = _plain_text(block)
    if (len(text) < MIN_HEADING_CHARS
            or len(text.split()) > MAX_HEADING_WORDS
            or text.endswith(".")
            or text.isdigit()
            or CAPTION.match(text)):
        return 0

    font, size, color = styles.most_common(1)[0][0]
    body_font, body_size, body_color = body
    bold_flag = any(s["flags"] & 16 for l in block["lines"] for s in l["spans"])

    score = 0
    if font != body_font:
        score += 1                                    # different font
    if color != body_color:
        score += 1                                    # different colour
    if size > body_size + 0.4:
        score += 1                                    # larger
    if size >= body_size * 1.15:
        score += 1                                    # clearly larger
    if bold_flag or any(w in font.lower() for w in BOLD_WORDS):
        score += 1                                    # bold
    if NUMBERING.match(text):
        score += 1                                    # 1.2  /  1.2.3
    return score


def _block_text(block, body_size):
    """Join the rows of a block into one paragraph (sub/superscripts stick)."""
    text = ""
    prev_small = False
    for line in block["lines"]:
        t = _line_text(line)
        size = max(s["size"] for s in line["spans"])
        small = body_size and size < body_size * SMALL_TEXT_RATIO
        if text:
            glue = small or (prev_small and (t[:1].isupper() or t[:1] in ")]},.;:"))
            if not glue:
                text += " "
        text += t
        prev_small = small
    return text


def _merge_paragraphs(paragraphs):
    """paragraphs = [(page, text)]. If a PDF stores one sentence in several
    blocks, glue them back together (the merged text keeps the first page)."""
    merged = []
    for page, para in paragraphs:
        if (merged and not re.search(r"[.?!:)\]]$", merged[-1][1])
                and para[:1].islower()):
            merged[-1] = (merged[-1][0], merged[-1][1] + " " + para)
        else:
            merged.append((page, para))
    return merged


def _level(text, last_numbered_level):
    m = NUMBER_PREFIX.match(text)
    if m:
        return m.group(1).count(".") + 1
    return last_numbered_level + 1 if last_numbered_level else 1


# ---------- main steps ----------
def analyze(pages):
    """pages = [{'number', 'height', 'blocks': PyMuPDF dict blocks}, ...]"""
    blocks = []
    for page in pages:
        blocks.extend(_read_blocks(page))
    n_pages = len({b["page"] for b in blocks}) or 1

    blocks, dropped = _drop_repeated(blocks, n_pages)
    body = _body_style(blocks)

    for b in blocks:
        b["score"] = _heading_score(b, body)
        b["is_heading"] = b["score"] >= HEADING_MIN_SCORE
    blocks.sort(key=lambda b: (
        b["page"],
        b["bbox"][1] - (MARGIN_SHIFT if b["is_heading"] else 0),
        b["bbox"][0],
    ))

    headings, units = [], []
    stack, current, last_numbered = [], None, 0
    for b in blocks:
        if b["is_heading"]:
            text = " ".join(_plain_text(b).split())
            level = _level(text, last_numbered)
            if NUMBER_PREFIX.match(text):
                last_numbered = level
            stack = [h for h in stack if h[0] < level] + [(level, text)]
            heading_id = len(headings)
            headings.append({"id": heading_id, "text": text, "level": level,
                             "page": b["page"], "score": b["score"]})
            if current and current["paragraphs"]:
                units.append(current)
            current = {"heading": text, "level": level, "heading_id": heading_id,
                       "path": " > ".join(t for _, t in stack),
                       "page_start": b["page"], "page_end": b["page"],
                       "paragraphs": []}
        else:
            if current is None:
                current = {"heading": "(before first heading)", "level": 0,
                           "heading_id": None, "path": "", "page_start": b["page"],
                           "page_end": b["page"], "paragraphs": []}
            current["paragraphs"].append((b["page"], _block_text(b, body[1])))
            current["page_end"] = b["page"]
    if current and current["paragraphs"]:
        units.append(current)

    for u in units:
        paras = _merge_paragraphs(u.pop("paragraphs"))
        u["paragraphs"] = [{"page": pg, "text": t} for pg, t in paras]
        u["text"] = "\n\n".join(t for _, t in paras)

    return {"n_pages": n_pages, "body_style": body, "headings": headings,
            "units": units, "dropped": dropped}


MAX_PAGES = 450                 # a textbook up to this many pages; longer files must be split


def extract_units(pdf_bytes):
    """Open a PDF (given as bytes) and return its heading-based units. Raises ValueError over MAX_PAGES pages."""
    import time
    import pymupdf
    started = time.time()
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as probe:
        if len(probe) > MAX_PAGES:
            raise ValueError(f"This PDF has {len(probe)} pages; the limit is {MAX_PAGES}. Split it into parts "
                             "(for example by chapter) and upload them to the same course.")
    # We only need text, so skip the raw picture data (it makes picture-heavy
    # books very slow). Falls back to the default if this PyMuPDF is different.
    try:
        flags = pymupdf.TEXTFLAGS_DICT & ~pymupdf.TEXT_PRESERVE_IMAGES
    except AttributeError:
        flags = None
    pages, errors = [], []
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        for i, page in enumerate(doc, start=1):
            try:
                data = page.get_text("dict", flags=flags) if flags is not None else page.get_text("dict")
            except Exception as e:                    # damaged page
                errors.append(f"page {i}: {e}")
                continue
            pages.append({"number": i, "height": page.rect.height,
                          "blocks": data["blocks"]})
    result = analyze(pages)
    result["errors"] = errors
    result["seconds"] = round(time.time() - started, 1)
    return result
