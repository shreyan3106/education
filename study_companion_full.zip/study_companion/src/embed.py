"""
Turns text into numbers (vectors) so we can search by meaning. Runs on your
laptop: no API key, and judges need no key for search either.

The models are tried in order. The first one that loads and runs is used.
IMPORTANT: vectors from different models cannot be compared, so the model name
is saved with every chunk, and a search always uses the model of the saved chunks.
"""
import numpy as np

EMBED_MODELS = [
    "BAAI/bge-small-en-v1.5",                    # small (~130 MB), fast on a CPU, English
    "sentence-transformers/all-MiniLM-L6-v2",    # tiny fallback (~90 MB)
]
# Optional upgrade: best quality and multilingual (Hindi + English), but a ~2 GB
# download and slow on a CPU. To use it, put "BAAI/bge-m3" first in the list above
# and add your files again (vectors from different models cannot be mixed).
BEST_QUALITY = "BAAI/bge-m3"

# Some models want a short instruction in front of the *question* (not the passages)
QUERY_PREFIX = {
    "BAAI/bge-small-en-v1.5": "Represent this sentence for searching relevant passages: ",
}

MAX_SEQ_LENGTH = 512        # keeps CPU time reasonable; chunks are ~300 tokens
BATCH = 16

_loaded = {}


def _load(name):
    if name not in _loaded:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(name, device="cpu")
        model.max_seq_length = min(MAX_SEQ_LENGTH, model.max_seq_length)
        _loaded[name] = model
    return _loaded[name]


def embed_texts(texts, kind="passage", model_name=None, progress=None):
    """
    Return (vectors, model_name): a float32 array [n, dim], rows normalised.
    kind = "passage" for stored text, "query" for a question.
    model_name = force one model (needed when searching saved chunks).
    progress(done, total) is called after each batch.
    """
    candidates = [model_name] if model_name else EMBED_MODELS
    last_error = None
    for name in candidates:
        try:
            model = _load(name)
            prefix = QUERY_PREFIX.get(name, "") if kind == "query" else ""
            out = []
            for i in range(0, len(texts), BATCH):
                batch = [prefix + t for t in texts[i:i + BATCH]]
                out.append(model.encode(batch, normalize_embeddings=True,
                                        show_progress_bar=False))
                if progress:
                    progress(min(i + BATCH, len(texts)), len(texts))
            return np.vstack(out).astype("float32"), name
        except Exception as e:                       # not installed, out of memory, ...
            last_error = e
            _loaded.pop(name, None)
    raise RuntimeError(f"No embedding model could run. Last error: {last_error}")
