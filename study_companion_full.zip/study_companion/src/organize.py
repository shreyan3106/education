"""
LLM help for organising a PDF (the "hybrid" part).

The code reads headings first (fast, free). Then a language model does what code
cannot:
  1. clean_headings: look at the detected heading list and say which entries are
     NOT real section headings (figure labels, running titles, stray words) and
     which levels look wrong. Removed headings are merged into the section above.
  2. tag_units: for every unit, name its topic, key concepts and prerequisites.
Both steps fail softly: with no model available, the code-only result is kept.
"""
import copy
import re

from src import llm

HEADINGS_PER_CALL = 120
UNITS_PER_CALL = 10          # bigger batches: a 450-page textbook has over a thousand units
WORDS_PER_UNIT = 90
MIN_TAG_WORDS = 25           # shorter units (debris, one-line slides) get an empty tag instead of a model call
TAG_WORKERS = 3              # model calls running at the same time
MAX_REMOVE_SHARE = 0.5       # if the model wants to remove more than this share, distrust it

HEADING_SYSTEM = """You clean up automatically detected headings of a textbook PDF.
You get a numbered list: id | level | page | words below it | heading text.
Some entries are NOT real section headings: figure or table labels, running page titles, stray words or symbols. Some levels may be wrong (1 = chapter title, 2 = section, 3 = subsection). Keep section headings and keep labels such as Example, Solution and Exercises.
Reply in exactly this format and nothing else:
Remove: ids to remove, separated by commas, or none
Levels: id=new level pairs separated by commas, or none"""

TAG_SYSTEM = """You tag sections of a textbook for a study app. For each numbered unit, give its topic, its key concepts and the prerequisite concepts a student should know first. Use short noun phrases. Reply with one block per unit, exactly like this:
Unit 1
Topic: one short phrase
Concepts: a; b; c
Prerequisites: x; y (or none)"""


# ---------- 1. heading clean-up ----------
def _parse_cleanup(text, valid_ids):
    remove, levels = set(), {}
    m = re.search(r"remove:\s*([^\n]*)", text, re.I)
    if m:
        part = m.group(1).split("(")[0]
        if not part.strip().lower().startswith("none"):
            remove = {int(x) for x in re.findall(r"\d+", part)} & valid_ids
    m = re.search(r"levels:\s*([^\n]*)", text, re.I)
    if m:
        for a, b in re.findall(r"(\d+)\s*=\s*(\d+)", m.group(1)):
            if int(a) in valid_ids and 1 <= int(b) <= 5:
                levels[int(a)] = int(b)
    return remove, levels


def apply_edits(result, remove_ids, new_levels):
    """Return a copy of `result` without the removed headings; their text joins the section above."""
    res = copy.deepcopy(result)
    kept_headings = []
    for h in res["headings"]:
        if h["id"] in remove_ids:
            continue
        h["level"] = new_levels.get(h["id"], h["level"])
        kept_headings.append(h)
    res["headings"] = kept_headings
    level_of = {h["id"]: h["level"] for h in kept_headings}

    units = []
    for u in res["units"]:
        if u["heading_id"] in remove_ids and units:
            prev = units[-1]                       # merge into the section above
            prev["paragraphs"].extend(u["paragraphs"])
            prev["page_end"] = max(prev["page_end"], u["page_end"])
        else:
            if u["heading_id"] in remove_ids:       # nothing above to merge into
                u["heading"], u["heading_id"], u["level"] = "(before first heading)", None, 0
            elif u["heading_id"] is not None:
                u["level"] = level_of[u["heading_id"]]
            units.append(u)

    stack = []                                      # rebuild the "chapter > section" paths
    for u in units:
        if u["heading_id"] is None:
            u["path"] = ""
            continue
        stack = [x for x in stack if x[0] < u["level"]] + [(u["level"], u["heading"])]
        u["path"] = " > ".join(t for _, t in stack)
        u["text"] = "\n\n".join(p["text"] for p in u["paragraphs"])
    for u in units:
        u["text"] = "\n\n".join(p["text"] for p in u["paragraphs"])
    res["units"] = units
    return res


def clean_headings(result):
    """Return (new_result, note). Never raises: on any problem the original result is returned."""
    headings = result["headings"]
    if len(headings) < 3:
        return result, "Too few headings to clean."
    words_under = {u["heading_id"]: len(u["text"].split()) for u in result["units"]}
    remove, levels, calls = set(), {}, 0
    try:
        for i in range(0, len(headings), HEADINGS_PER_CALL):
            batch = headings[i:i + HEADINGS_PER_CALL]
            lines = "\n".join(
                f"{h['id']} | {h['level']} | p{h['page']} | {words_under.get(h['id'], 0)} words | {h['text']}"
                for h in batch)
            r = llm.ask("extract", [{"role": "system", "content": HEADING_SYSTEM},
                                    {"role": "user", "content": lines}], max_tokens=1500)
            calls += 1
            rm, lv = _parse_cleanup(r["text"], {h["id"] for h in batch})
            remove |= rm
            levels.update(lv)
    except llm.AllModelsBusy:
        return result, "Heading clean-up skipped: no language model was available."
    except Exception as e:
        return result, f"Heading clean-up skipped: {e}"

    if len(remove) > MAX_REMOVE_SHARE * len(headings):
        return result, f"Heading clean-up ignored: the model wanted to remove {len(remove)} of {len(headings)} headings."
    cleaned = apply_edits(result, remove, levels)
    return cleaned, f"Heading clean-up: removed {len(remove)}, re-levelled {len(levels)} (from {calls} model call(s))."


# ---------- 2. topics, concepts, prerequisites ----------
def _block_to_tag(block):
    lab = llm.parse_labeled_lines(block)
    concepts = lab.get("concepts", [])
    prereq = [p for p in lab.get("prerequisites", []) if p.lower() not in ("none", "n/a")]
    topic = (lab.get("topic") or [""])[0]
    if concepts or topic:
        return {"topic": topic, "concepts": concepts, "prerequisites": prereq}
    return None


def _parse_tags(text, n_units):
    """Return {k: tags} for k = 1..n_units. Accepts 'Unit 2', '**Unit 2**', 'Unit 2: title', ..."""
    tags = {}
    parts = re.split(r"(?im)^\W*unit\s+(\d+)\b[^\n]*$", text)
    for k_str, block in zip(parts[1::2], parts[2::2]):
        k = int(k_str)
        tag = _block_to_tag(block) if 1 <= k <= n_units else None
        if tag:
            tags[k] = tag
    if not tags:                              # no "Unit n" lines: try the Topic: lines in order
        blocks = re.split(r"(?im)^(?=\W*topic:)", text)
        blocks = [b for b in blocks if re.match(r"(?i)\W*topic:", b)]
        if len(blocks) == n_units:
            for k, b in enumerate(blocks, start=1):
                tag = _block_to_tag(b)
                if tag:
                    tags[k] = tag
    return tags


def _tag_batch(batch):
    body = "\n\n".join(
        f"Unit {k + 1}: {r['heading']}\n" + " ".join(r["text"].split()[:WORDS_PER_UNIT])
        for k, r in enumerate(batch))
    r = llm.ask("extract", [{"role": "system", "content": TAG_SYSTEM},
                            {"role": "user", "content": body}], max_tokens=4000)
    if r.get("truncated"):
        return {}
    return {batch[k - 1]["id"]: t for k, t in _parse_tags(r["text"], len(batch)).items()}


def tag_units(rows, progress=None):
    """
    rows = [{'id', 'heading', 'text'}]. Returns ({unit_id: tags}, note).
    Batches run TAG_WORKERS at a time; units the model skipped are asked again in small batches. Very short
    units get an empty tag (nothing to tag). Stops quietly if no model is available; what was tagged is kept,
    and the rest can be continued later because untagged units are found again.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    done, note = {}, ""
    real = []
    for r in rows:
        if len(r["text"].split()) < MIN_TAG_WORDS:
            done[r["id"]] = {"topic": "", "concepts": [], "prerequisites": []}
        else:
            real.append(r)
    total = len(real)
    batches = [real[i:i + UNITS_PER_CALL] for i in range(0, total, UNITS_PER_CALL)]
    finished = 0
    try:
        with ThreadPoolExecutor(max_workers=TAG_WORKERS) as pool:
            futures = [pool.submit(_tag_batch, b) for b in batches]
            for fut in as_completed(futures):
                try:
                    done.update(fut.result())
                except llm.AllModelsBusy:
                    note = "Stopped early: no language model was available."
                finished += 1
                if progress:
                    progress(min(finished * UNITS_PER_CALL, total), max(total, 1))
        missing = [r for r in real if r["id"] not in done]
        for i in range(0, len(missing) if not note else 0, 2):      # second pass: two units at a time
            done.update(_tag_batch(missing[i:i + 2]))
    except llm.AllModelsBusy:
        note = "Stopped early: no language model was available."
    except Exception as e:
        note = f"Stopped early: {e}"
    return done, note
