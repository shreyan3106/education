"""
PowerPoint decks (.pptx) as study material. Every slide is one unit:
  heading     = the slide title (or "Slide 7" if it has none)
  location    = the slide NUMBER (page_start = page_end = slide number; the document type is 'slide')
  text        = the text on the slide, tables as rows, then the speaker notes, then descriptions of its pictures

Opening a citation shows the slide as a card (title, text, notes, pictures), because drawing a slide as an
image needs PowerPoint or LibreOffice on the computer.
"""
import os

from src import figures, store

MAX_SLIDES = 300
MAX_PICTURES_DESCRIBED = 30
MIN_PICTURE_BYTES = 6000          # smaller pictures are icons and bullets, not figures


def _shape_text(shape, out, pictures):
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        for sub in shape.shapes:
            _shape_text(sub, out, pictures)
        return
    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
        try:
            blob, ext = shape.image.blob, shape.image.ext
            if len(blob) >= MIN_PICTURE_BYTES:
                pictures.append((blob, ext))
        except Exception:
            pass
        return
    if getattr(shape, "has_table", False) and shape.has_table:
        for row in shape.table.rows:
            cells = [" ".join(c.text.split()) for c in row.cells]
            if any(cells):
                out.append(" | ".join(cells))
        return
    if getattr(shape, "has_text_frame", False) and shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = "".join(run.text for run in para.runs).strip()
            if text:
                out.append(text)


def read_pptx(data):
    """
    Read a .pptx given as bytes. Returns {'units': [...], 'n_slides': n, 'pictures': {slide: [(bytes, ext)]}}.
    Raises ValueError for a deck with more than MAX_SLIDES slides.
    """
    import io
    from pptx import Presentation
    deck = Presentation(io.BytesIO(data))
    if len(deck.slides) > MAX_SLIDES:
        raise ValueError(f"This deck has {len(deck.slides)} slides; the limit is {MAX_SLIDES}.")
    units, pictures = [], {}
    for number, slide in enumerate(deck.slides, start=1):
        title = ""
        try:
            if slide.shapes.title is not None:
                title = " ".join(slide.shapes.title.text.split())
        except Exception:
            pass
        lines, pics = [], []
        for shape in slide.shapes:
            _shape_text(shape, lines, pics)
        if title and lines and lines[0] == title:
            lines = lines[1:]
        notes = ""
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame is not None:
            notes = slide.notes_slide.notes_text_frame.text.strip()
        paragraphs = [{"page": number, "text": t} for t in lines]
        if notes:
            paragraphs.append({"page": number, "text": "Speaker notes: " + notes})
        if not paragraphs and title:
            paragraphs.append({"page": number, "text": title})
        if not paragraphs and not pics:
            continue                                      # an empty slide
        heading = title or (lines[0][:60] if lines else f"Slide {number}")
        unit = {"heading": heading, "level": 1 if number == 1 else 2, "path": heading,
                "page_start": number, "page_end": number, "paragraphs": paragraphs}
        unit["text"] = "\n\n".join(p["text"] for p in paragraphs)
        units.append(unit)
        if pics:
            pictures[number] = pics
    return {"units": units, "n_slides": len(deck.slides), "pictures": pictures}


def save_pictures(doc, pictures):
    """Keep the slides' pictures on disk so a cited slide can show them."""
    folder = os.path.join(store.FILES_DIR, os.path.basename(doc) + ".slides")
    os.makedirs(folder, exist_ok=True)
    for number, pics in pictures.items():
        for k, (blob, ext) in enumerate(pics, start=1):
            with open(os.path.join(folder, f"{number}_{k}.{ext}"), "wb") as fh:
                fh.write(blob)


def describe_pictures(units, pictures, progress=None):
    """
    A vision model describes the pictures; each description is added to its slide's text so it can be
    searched and quoted. Returns a note ('' if all went well).
    """
    by_number = {u["page_start"]: u for u in units}
    work = [(n, blob) for n, pics in sorted(pictures.items()) for blob, ext in pics if ext in ("png", "jpg", "jpeg")]
    work = work[:MAX_PICTURES_DESCRIBED]
    done = 0
    for i, (number, blob) in enumerate(work, start=1):
        unit = by_number.get(number)
        text = figures.describe_image(blob, f"slide {number}: {unit['heading'] if unit else ''}") if unit else None
        if text:
            unit["paragraphs"].append({"page": number, "text": f"Figure on this slide: {text}"})
            unit["text"] += f"\n\nFigure on this slide: {text}"
            done += 1
        if progress:
            progress(i, len(work))
    if work and not done:
        return "The pictures on the slides could not be described (no vision model was available)."
    return ""


def card(doc, number):
    """What to show for a cited slide: {'title', 'text', 'notes', 'images': [paths]} or None."""
    conn = store._db()
    row = conn.execute("SELECT heading, text FROM pdf_units WHERE doc=? AND page_start<=? AND page_end>=? "
                       "ORDER BY id LIMIT 1", (doc, number, number)).fetchone()
    conn.close()
    if row is None:
        return None
    body, _, figs = row[1].partition("\n\nFigure on this slide:")
    text, notes = body, ""
    if "Speaker notes:" in body:
        text, notes = body.split("Speaker notes:", 1)
    text = text.strip() + (("\n\nFigure: " + figs.strip().replace("\n\nFigure on this slide:", "\nFigure:")) if figs.strip() else "")
    notes = notes.strip()
    folder = os.path.join(store.FILES_DIR, os.path.basename(doc) + ".slides")
    images = []
    if os.path.isdir(folder):
        images = sorted(os.path.join(folder, f) for f in os.listdir(folder) if f.startswith(f"{number}_"))
    return {"title": row[0], "text": text, "notes": notes, "images": images}
