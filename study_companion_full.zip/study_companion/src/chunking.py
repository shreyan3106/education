"""Split long units into search-sized chunks, remembering the page of each."""
import re

TARGET_WORDS = 180      # aim for chunks about this long
HARD_WORDS = 260        # never longer than this


def _split_long(text):
    """Cut one very long paragraph at sentence ends into pieces <= TARGET_WORDS."""
    sentences = re.split(r"(?<=[.?!])\s+", text)
    pieces, cur = [], []
    for sentence in sentences:
        words = sentence.split()
        while len(words) > HARD_WORDS:               # a single huge "sentence"
            if cur:
                pieces.append(" ".join(cur)); cur = []
            pieces.append(" ".join(words[:TARGET_WORDS]))
            words = words[TARGET_WORDS:]
        if cur and len(cur) + len(words) > TARGET_WORDS:
            pieces.append(" ".join(cur)); cur = []
        cur.extend(words)
    if cur:
        pieces.append(" ".join(cur))
    return pieces


def chunk_unit(unit):
    """unit['paragraphs'] = [{'page', 'text'}]  ->  [{'text', 'page_start', 'page_end'}]"""
    chunks, cur_text, cur_pages = [], [], []

    def flush():
        if cur_text:
            chunks.append({"text": "\n\n".join(cur_text),
                           "page_start": min(cur_pages), "page_end": max(cur_pages)})
        cur_text.clear(); cur_pages.clear()

    for para in unit["paragraphs"]:
        n_words = len(para["text"].split())
        parts = _split_long(para["text"]) if n_words > HARD_WORDS else [para["text"]]
        for part in parts:
            words_now = sum(len(t.split()) for t in cur_text)
            if cur_text and words_now + len(part.split()) > TARGET_WORDS:
                flush()
            cur_text.append(part)
            cur_pages.append(para["page"])
    flush()
    return chunks
