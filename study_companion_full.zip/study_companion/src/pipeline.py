"""
One way to put material into the knowledge base, whatever it is (PDF, PowerPoint deck, YouTube video):

   units -> passages (chunks) -> embeddings -> saved -> topics and concepts (model) -> outline sorted (model)
         -> assigned to a course

Every step reports progress through report(fraction, text), so the screen shows what is happening.
A textbook of up to MAX_PDF_PAGES pages goes through the same path: the model steps work in batches, run
several calls at a time, and the tagging step can be continued if it was interrupted.
"""
from src import library, outline, store
from src.chunking import chunk_unit
from src.embed import embed_texts
from src.organize import tag_units

MAX_PDF_PAGES = 450


def tag_saved(name, report=None, start=0.6):
    """Ask a model for topic, concepts and prerequisites of every untagged unit. Returns a note."""
    rows = store.untagged_units(name)
    if not rows:
        return ""

    def progress(done, total):
        if report:
            report(start + (0.3 * done / max(total, 1)), f"Finding topics and concepts: {done} of {total} units")

    tags, note = tag_units(rows, progress)
    store.save_tags(tags)
    left = len(rows) - len(tags)
    return note or (f"{left} short units were left untagged." if left else "")


def sort_saved(name, report=None, force=False):
    """A model reads the whole outline of the saved document and sorts it: roles and topics. Returns a note."""
    def progress(done, total):
        if report:
            report(0.95, f"Sorting the outline with a helper model: part {done} of {total}")

    if report:
        report(0.92, "Sorting the outline with a helper model...")
    return outline.build(name, progress=progress, force=force)


def save_material(name, n_pages, units, source_type="pdf", course=None, url="", file_bytes=None,
                  report=None, notes=None):
    """
    Save a document and make it ready to use. units = [{'heading','level','path','page_start','page_end',
    'paragraphs': [{'page','text'}], 'text'}]. Returns ({'units', 'chunks'}, embedding model, [notes]).
    Raises ValueError if there is no readable text.
    """
    notes = list(notes or [])
    report = report or (lambda frac, text: None)
    if file_bytes is not None:
        store.save_file(name, file_bytes)              # lets a citation open the exact page later
    items = [{"unit": u, "chunks": chunk_unit(u)} for u in units]
    texts = [i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]]
    if not texts:
        raise ValueError("This material has no readable text to add.")
    report(0.1, "Starting the embedding model...")

    def progress(done, total):
        report(0.1 + 0.5 * done / total, f"Embedding passage {done} of {total}")

    vectors, model = embed_texts(texts, progress=progress)
    counts = store.save_pdf(name, n_pages, items, vectors, model, source_type=source_type)
    if url:
        store.set_meta(name, url)
    library.assign(name, course or library.default_course_name(name))
    for step in (lambda: tag_saved(name, report), lambda: sort_saved(name, report)):
        try:
            note = step()
        except Exception as e:                           # a failed model step never loses the saved material
            note = f"A step was skipped: {e}"
        if note:
            notes.append(note)
    report(1.0, "Done")
    return counts, model, notes
