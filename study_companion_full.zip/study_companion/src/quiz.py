"""
Quizzes and mock exams.

topic quiz  : the student types a topic -> 7 questions
mock exam   : the student picks exactly 5 topics -> 30 questions (6 per topic)

HOW A QUESTION IS MADE (two different model families, no model checks its own work)
  1. passages   : search finds passages for the topic (typed topic), or the chunks tagged
                  with the chosen topic (mock exam). Passages already used in earlier
                  quizzes come last, so repeated quizzes explore new parts of the material.
  2. SETTER     : one model writes the QUESTIONS ONLY (type, difficulty, concept, options for
                  an MCQ). It never writes or sees an answer.
  3. repeats    : a question too similar to any earlier question (saved history) or to one
                  already in this quiz is thrown away BEFORE the checker is paid for.
  4. CHECKER    : a model from a DIFFERENT family prepares the answer key from the passage:
                  correct option / reference answer and key points / numerical working.
                  It must copy the sentence of the passage that proves the answer, and it
                  may reject the question (UNANSWERABLE or FLAWED).
  5. CODE       : the copied sentence must really be in the passage; a numerical answer
                  must equal the result of the calculation the checker wrote down (the
                  calculation is run by our own safe calculator, not trusted from the model);
                  MCQ options are shuffled so the right answer is not always the same letter.
  6. saved      : question, key, tags (topic, concept, difficulty, source page), both model
                  names and the question's vector go into SQLite (the history).

HOW AN ANSWER IS GRADED
  MCQ        : code compares the letter.
  numerical  : code reads the number (3 x 10^8, 3e8, ...) and compares within NUMERIC_TOLERANCE.
  short      : a model of a different family from the setter grades against the key points
               (with a simple keyword fallback if no model is available).
"""
import ast
import json
import math
import operator
import random
import re
import sqlite3
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np

from src import embed, fmt, learner, library, llm, outline, store
from src.search import search
from src.tutor import fix_math

# ---- settings you can tune ----
TOPIC_QUIZ_SIZE = 7
MOCK_SIZE = 30                 # mock exam length (to offer more sizes, make this a list in quiz_ui.py)
MOCK_TOPICS = 5                # a mock exam needs exactly this many topics
DIAGNOSTIC_TOPICS = 6          # a diagnostic quiz asks one question on each of up to this many topics
MAX_ROUNDS = 3                 # how many times to ask the setter again if questions were dropped
CHECK_WORKERS = 4              # checker calls running at the same time
WRITER_TOKENS = 5000           # reasoning models think a lot before they write
CHECKER_TOKENS = 3000
WRITER_TIMEOUT = 150           # seconds
CHECKER_TIMEOUT = 90
GRADER_TIMEOUT = 60
REPEAT_SIM = 0.85              # a new question this similar to an old one is a repeat
QUIZ_REFUSE_BELOW = 0.40       # typed topic: best similarity under this = "not in your material"
MIN_CHUNK_SIM = 0.35           # typed topic: a passage must be at least this similar
NUMERIC_TOLERANCE = 0.03       # 3 percent: textbook answers are often rounded
WEAK_BELOW = 0.6               # a topic scored under this is called weak in the report
MIN_USABLE_WORDS = 25          # passages shorter than this are not worth a question

SETTER_SYSTEM = """You are an exam setter for a study app. You get numbered passages from a student's course material. Write exam questions that can be answered ONLY from those passages.
Rules:
- Write exactly {n} questions. Spread them over the passages and use no passage more than {per} time(s).
- Do NOT write answers. Another person prepares the answer key.
- Each question tests ONE idea and is fully self-contained: a student who has never seen the passages must be able to read it. NEVER write "according to the passage", "the text", "the figure", "as given", "above" or "the chapter". Keep it short (one or two sentences) and never need a picture.
- Types: MCQ (exactly four options A to D, one clearly correct, wrong options based on real student mistakes; never use "all of the above", "none of the above" or "both A and B"), SHORT (answerable in 1 to 3 sentences) and NUMERICAL (only when the passage gives a formula or law; give every number the student needs inside the question). Use a sensible mix and choose the type that suits each passage.
- Difficulty: easy (recall), medium (understand or apply once), hard (combine two ideas or a multi-step calculation).
- Write EVERY formula, symbol, subscript and superscript in LaTeX between single dollar signs, like $F = k\\frac{{q_1 q_2}}{{r^2}}$ or $r_{{13}}$. Never write a formula as plain text and never use \\( \\).
- Do not repeat or reword any of the questions listed under ALREADY ASKED.
Reply in exactly this format, one block per question, and nothing else:
Q1
Source: passage number
Type: MCQ or SHORT or NUMERICAL
Difficulty: easy or medium or hard
Concept: two to four words
Question: the question text
A: option   (only for MCQ)
B: option
C: option
D: option
Q2
..."""

CHECKER_SYSTEM = """You are an exam moderator for a study app. You get ONE passage from a student's course material and ONE exam question that someone else wrote from it. You did not write the question. Prepare the official answer key using ONLY the passage (ordinary arithmetic and the formulas stated in the passage are allowed).
Reply in exactly this format and nothing else:
Verdict: OK or UNANSWERABLE or FLAWED
Evidence: copy, word for word, the sentence(s) of the passage that prove the answer (for a numerical question: the sentence with the law or formula, or none)
Then, depending on the question type:
MCQ ->
Correct: one letter, A to D
Explanation: two or three short sentences: why it is right and why the most tempting wrong option is wrong. Refer to options by what they SAY, never by their letter
Mistake: one short sentence naming the misconception behind the most tempting wrong option
SHORT ->
Reference answer: one to three sentences
Key points: two to four short points a correct answer must contain, separated by semicolons; each point a complete short phrase
Explanation: two or three sentences
Mistake: one short sentence naming the most common wrong idea
NUMERICAL ->
Calculation: ONE arithmetic expression that gives the answer, using only numbers, + - * / ** ( ) , sqrt( ) and pi. No units, no variables, no equals sign. Example: 9e9 * 2e-6 * 3e-6 / 0.5**2
Answer: the result as a plain number, for example 0.216 or 9e9
Unit: the unit, or none
Explanation: the working in short steps
Mistake: one short sentence naming the most common wrong approach
Use UNANSWERABLE if the passage does not contain what is needed. Use FLAWED if the question is ambiguous, two options could be correct, none is correct, or a needed number is missing. Write EVERY formula, symbol, subscript and superscript in LaTeX between single dollar signs, like $r_{13}$ or $\\mathbf{E}$; never as plain text and never with \\( \\). Be concise."""

GRADER_SYSTEM = """You grade a student's short answer for a study app. Compare it with the reference answer and the key points. Be fair: different wording is fine, wrong or missing ideas are not.
Reply in exactly this format and nothing else:
Verdict: CORRECT or PARTLY or INCORRECT
Feedback: one or two short sentences to the student: what is right, what is missing or wrong. Write formulas in LaTeX between single dollar signs"""

REPORT_SYSTEM = """You help a student understand their mistakes in a quiz. You get the questions they got wrong or only partly right, with their answer, the correct answer and a note about the common mistake.
Name the 2 to 4 most likely misconceptions behind the mistakes, each in one plain sentence addressed to the student, and say which topic it belongs to.
Reply in exactly this format and nothing else, one line per misconception:
Misconception: topic | the misconception"""


# =====================================================================
# 1. Small pure helpers (calculator, number reader, text templates)
# =====================================================================
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow}
_UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"sqrt": math.sqrt}
_CONSTS = {"pi": math.pi}


def safe_eval(expression):
    """Evaluate a plain arithmetic expression (numbers, + - * / **, sqrt, pi). Raises ValueError otherwise."""
    expr = (expression or "").strip().split("=")[0]
    expr = (expr.replace("^", "**").replace("×", "*").replace("−", "-")
            .replace("÷", "/").replace("\\times", "*").replace("\\cdot", "*"))
    if not expr or len(expr) > 300:
        raise ValueError("empty or too long")

    def ev(node):
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) \
                and not isinstance(node.value, bool):
            return float(node.value)
        if isinstance(node, ast.Name) and node.id in _CONSTS:
            return _CONSTS[node.id]
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
            return _UNARY[type(node.op)](ev(node.operand))
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            a, b = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(b) > 400:
                raise ValueError("exponent too large")
            return _OPS[type(node.op)](a, b)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) \
                and node.func.id in _FUNCS and len(node.args) == 1 and not node.keywords:
            return _FUNCS[node.func.id](ev(node.args[0]))
        raise ValueError("not allowed in a calculation")

    try:
        value = ev(ast.parse(expr, mode="eval"))
    except (SyntaxError, ZeroDivisionError, OverflowError) as e:
        raise ValueError(str(e))
    if isinstance(value, complex) or math.isnan(value) or math.isinf(value):
        raise ValueError("not a finite real number")
    return value


def parse_number(text):
    """Read a number from what a student typed: 12, 0.5, 3e8, 3 x 10^8, 3×10^-5, 10^9. None if there is none."""
    t = (text or "").lower().strip()
    t = t.replace("×", "x").replace("−", "-").replace("–", "-")
    sup = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
    t = re.sub(r"[⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+", lambda m: "^" + m.group(0).translate(sup), t)   # 10⁻³ -> 10^-3
    t = re.sub(r"(?<=\d),(?=\d{3}\b)", "", t)            # 1,000 -> 1000
    m = re.search(r"([-+]?\d*\.?\d+(?:e[-+]?\d+)?)\s*(?:x|\*|·)\s*10\s*\^?\s*\(?\s*\{?([-+]?\d+)", t)
    if m:
        mantissa, power = m.group(1), int(m.group(2))
        return float(f"{mantissa}e{power}") if "e" not in mantissa else float(mantissa) * 10.0 ** power
    m = re.match(r"\s*10\s*\^\s*\(?\{?([-+]?\d+)", t)
    if m:
        return 10.0 ** int(m.group(1))
    m = re.match(r"\s*([-+]?\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)(?![\d.])", t)       # 1/4 or 3/4 N
    if m and float(m.group(2)) != 0:
        return float(m.group(1)) / float(m.group(2))
    m = re.search(r"[-+]?\d*\.?\d+(?:e[-+]?\d+)?", t)
    return float(m.group(0)) if m else None


def numbers_match(student, key, tol=None):
    tol = NUMERIC_TOLERANCE if tol is None else tol
    if abs(key) < 1e-300:
        return abs(student) < 1e-12
    return abs(student - key) <= tol * abs(key)


def format_number(x):
    return f"{x:.4g}" if 1e-3 <= abs(x) < 1e6 or x == 0 else f"{x:.3e}"


def _words(text):
    return re.findall(r"[a-z0-9]+", (text or "").lower())


def grounded(evidence, passage):
    """True if the sentence the checker copied is really (nearly word for word) in the passage."""
    ev, ps = _words(evidence), _words(passage)
    if len(ev) < 5:
        return False
    grams = {tuple(ps[i:i + 3]) for i in range(len(ps) - 2)}
    ev_grams = [tuple(ev[i:i + 3]) for i in range(len(ev) - 2)]
    return sum(g in grams for g in ev_grams) / len(ev_grams) >= 0.6


def read_fields(text, labels):
    """
    Read 'Label: value' lines (values may continue on following lines) into {label: value}.
    Accepts '**Label:** value' and '**Label**: value'. Labels are matched in lower case.
    """
    pattern = re.compile(r"^[\s*#>_\-]*(" + "|".join(re.escape(l) for l in labels)
                         + r")\**\s*[:：]\s*\**\s*(.*)$", re.I)
    out, current = {}, None
    for line in (text or "").splitlines():
        m = pattern.match(line)
        if m:
            current = m.group(1).lower()
            out[current] = m.group(2).strip()
        elif current is not None:
            out[current] = (out[current] + "\n" + line.strip()).strip()
    return {k: v.strip().strip("*").strip() for k, v in out.items()}


# ---------- reading the setter's output ----------
_Q_HEADER = re.compile(r"^[\s*#>_\-]*(?:Q|Question)\s*(\d+)\s*[:.)]?\s*\**\s*$", re.I)
_WRITER_LABELS = ("source", "type", "difficulty", "concept", "question")
_OPTION = re.compile(r"^[\s*#>_\-(]*([A-D])\s*[:.)]\**\s+(.*)$")
_REFERS = re.compile(r"\b(according to|as per|based on|as (?:given|stated|described|shown|mentioned) in|from|in|per)\s+(?:the|this|that|given|above|following)\s+"
                     r"(?:passage|text|excerpt|paragraph|figure|chapter|section|reading|extract|material)\b"
                     r"|\b(?:the|this) (?:passage|excerpt|paragraph|extract)\b", re.I)
_BAD_OPTIONS = re.compile(r"all of the above|none of the above|both [a-d]\b|[a-d] and [a-d]\b", re.I)


def parse_setter_output(text, n_passages):
    """Return a list of draft dicts: source (1-based), qtype, difficulty, concept, question, options."""
    blocks, current = [], None
    for line in (text or "").splitlines():
        if _Q_HEADER.match(line):
            current = []
            blocks.append(current)
        elif current is not None:
            current.append(line)
    drafts = []
    for lines in blocks:
        body = "\n".join(lines)
        options, rest = {}, []
        for line in lines:
            m = _OPTION.match(line)
            if m and not re.match(r"^[\s*#>_\-]*(source|type|difficulty|concept|question)\b", line, re.I):
                options[m.group(1)] = m.group(2).strip().strip("*").strip()
            else:
                rest.append(line)
        f = read_fields("\n".join(rest), _WRITER_LABELS)
        kind = f.get("type", "").lower()
        qtype = ("mcq" if ("mcq" in kind or "multiple" in kind) else
                 "numerical" if "num" in kind else "short" if "short" in kind else None)
        src = re.search(r"\d+", f.get("source", ""))
        source = int(src.group(0)) if src else 0
        diff = f.get("difficulty", "medium").lower()
        difficulty = next((d for d in ("easy", "medium", "hard") if d in diff), "medium")
        question = f.get("question", "").strip()
        if not qtype or not question or not 1 <= source <= n_passages:
            continue
        if _REFERS.search(question) or any(_REFERS.search(v) for v in options.values()):
            continue                                  # a question must stand alone
        if qtype == "mcq":
            if sorted(options) != ["A", "B", "C", "D"] or any(not v for v in options.values()):
                continue
            if any(_BAD_OPTIONS.search(v) for v in options.values()):
                continue
        else:
            options = {}
        drafts.append({"source": source, "qtype": qtype, "difficulty": difficulty,
                       "concept": f.get("concept", "").strip(" .") or "", "question": question,
                       "options": options})
    return drafts


# ---------- reading the checker's output ----------
_CHECK_LABELS = ("verdict", "evidence", "correct answer", "correct", "explanation", "mistake", "reference answer",
                 "key points", "calculation", "answer", "unit")


def parse_check_output(text, draft, passage_text):
    """
    Turn the checker's reply into an answer key. Returns {'ok': True, 'key': {...},
    'explanation', 'mistake', 'evidence'} or {'ok': False, 'reason': '...'}.
    """
    f = read_fields(text, _CHECK_LABELS)
    verdict = f.get("verdict", "").upper()
    if "UNANSWERABLE" in verdict:
        return {"ok": False, "reason": "the passage does not answer it"}
    if "FLAWED" in verdict:
        return {"ok": False, "reason": "the checker found the question flawed"}
    if "OK" not in verdict:
        return {"ok": False, "reason": "the checker's reply could not be read"}

    evidence = f.get("evidence", "").strip()
    qtype = draft["qtype"]
    if qtype != "numerical":
        if evidence.lower().startswith("none") or not grounded(evidence, passage_text):
            return {"ok": False, "reason": "the checker's evidence is not in the passage"}
    explanation = f.get("explanation", "").strip()
    mistake = f.get("mistake", "").strip()
    if not explanation:
        return {"ok": False, "reason": "no explanation"}
    base = {"ok": True, "explanation": explanation, "mistake": mistake, "evidence": evidence}

    if qtype == "mcq":
        letter = re.match(r"\s*\(?([A-D])\b", (f.get("correct") or f.get("correct answer", "")).upper())
        if not letter:
            return {"ok": False, "reason": "no correct option given"}
        return {**base, "key": {"correct": letter.group(1)}}

    if qtype == "short":
        reference = f.get("reference answer", "").strip()
        points = [p.strip(" .-*") for p in re.split(r"[;\n]", f.get("key points", "")) if p.strip(" .-*")]
        if not reference or not points:
            return {"ok": False, "reason": "no reference answer or key points"}
        return {**base, "key": {"reference": reference, "points": points[:5]}}

    # numerical: the model's number must equal what OUR calculator gets from its calculation
    try:
        computed = safe_eval(f.get("calculation", ""))
    except ValueError:
        return {"ok": False, "reason": "the calculation could not be run"}
    stated = parse_number(f.get("answer", ""))
    if stated is None or not numbers_match(stated, computed, tol=0.01):
        return {"ok": False, "reason": "the stated answer differs from the calculation"}
    unit = f.get("unit", "").strip()
    unit = "" if unit.lower() in ("none", "n/a", "-") else unit
    return {**base, "key": {"value": computed, "unit": unit, "calc": f.get("calculation", "").split("=")[0].strip()}}


def _shuffled(options, rng=random):
    """The same options in a random order, relabelled A to D."""
    texts = list(options.values())
    rng.shuffle(texts)
    return {chr(65 + i): t for i, t in enumerate(texts)}


def shuffle_options(draft, correct_letter, rng=random):
    """Shuffle MCQ options; return (new options dict, new correct letter)."""
    items = list(draft["options"].items())
    right_text = draft["options"][correct_letter]
    rng.shuffle(items)
    options = {chr(65 + i): text for i, (_, text) in enumerate(items)}
    new_letter = next(L for L, t in options.items() if t == right_text)
    return options, new_letter


# =====================================================================
# 2. Storage (own tables in the same SQLite file)
# =====================================================================
_SCHEMA = """
CREATE TABLE IF NOT EXISTS quiz_sets (
    id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, scope TEXT, wanted INTEGER,
    created REAL, submitted REAL, report TEXT);
CREATE TABLE IF NOT EXISTS quiz_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, set_id INTEGER, pos INTEGER, doc TEXT, chunk_id INTEGER,
    topic TEXT, concept TEXT, qtype TEXT, difficulty TEXT, question TEXT, options TEXT, key TEXT,
    explanation TEXT, mistake TEXT, evidence TEXT, heading TEXT, page_start INTEGER, page_end INTEGER,
    writer_model TEXT, checker_model TEXT, embed_model TEXT, vector BLOB, created REAL);
CREATE TABLE IF NOT EXISTS quiz_answers (
    question_id INTEGER PRIMARY KEY, set_id INTEGER, answer TEXT, score REAL,
    feedback TEXT, graded_by TEXT, ts REAL);
"""


def _conn():
    conn = sqlite3.connect(store.DB_PATH)
    conn.executescript(_SCHEMA)
    return conn


def sections():
    """
    The topics a student can choose: [{'topic', 'doc', 'page_start', 'page_end', 'unit_ids', 'concepts'}]
    in book order. They come from the document outline (src/outline.py), where a helper model has sorted
    every uploaded document, so nothing here depends on one book's heading style.
    """
    return outline.topics()


def available_topics(docs=None):
    """Rows for the Quiz tab, in book order: [{'topic', 'doc', 'pages', 'where', 'concepts'}].
    docs = the documents of the chosen course (None = everything)."""
    return outline.topic_rows(docs=docs)


def _chunks_for_topic(topic):
    """All chunks of the units inside one section."""
    ids = next((s["unit_ids"] for s in sections() if s["topic"] == topic), [])
    if not ids:
        return []
    conn = _conn()
    marks = ",".join("?" * len(ids))
    rows = conn.execute(
        "SELECT id, doc, heading, path, page_start, page_end, text, unit_id FROM chunks "
        f"WHERE unit_id IN ({marks}) ORDER BY id", ids).fetchall()
    conn.close()
    return [{"id": r[0], "doc": r[1], "heading": r[2], "path": r[3], "page_start": r[4],
             "page_end": r[5], "text": r[6], "unit_id": r[7]} for r in rows]


def _unit_to_topic():
    """{unit_id: section name}: the clean topic tag every question gets."""
    return {uid: s["topic"] for s in sections() for uid in s["unit_ids"]}


def _chunk_use_counts():
    conn = _conn()
    rows = conn.execute("SELECT chunk_id, COUNT(*) FROM quiz_questions GROUP BY chunk_id").fetchall()
    conn.close()
    return {r[0]: r[1] for r in rows}


def _history(embed_model):
    """(vectors of every earlier question made with this embedding model, all question texts)."""
    conn = _conn()
    rows = conn.execute("SELECT question, vector, embed_model FROM quiz_questions").fetchall()
    conn.close()
    vecs = [np.frombuffer(v, dtype="float32") for _, v, m in rows if v and m == embed_model]
    return (np.vstack(vecs) if vecs else np.zeros((0, 0), dtype="float32")), [r[0] for r in rows]


def _norm(text):
    return " ".join(_words(text))


# =====================================================================
# 3. Making the questions
# =====================================================================
_SOURCE_KINDS = ("text", "example", "summary")      # exercises, contents, titles are never a source


def _kind_ok(chunk, roles):
    return outline.kind_of(chunk, roles) in _SOURCE_KINDS and len(chunk["text"].split()) >= MIN_USABLE_WORDS


def _pool_from_search(topic, size, docs=None):
    """Passages for a typed topic, inside the chosen course. Returns (pool, best_similarity)."""
    out = search(topic, k=max(40, 3 * size), per_method=60, docs=docs)
    roles = outline.load_roles()
    pool = [r for r in out["results"] if r["dense"] >= MIN_CHUNK_SIM and _kind_ok(r, roles)]
    return pool[:max(2 * size, 12)], out["best_dense"]


def _order_by_novelty(pool):
    """Passages used in fewer earlier questions first; ties keep the search order."""
    used = _chunk_use_counts()
    return sorted(pool, key=lambda c: used.get(c["id"], 0))


def _write_questions(label, passages, n_ask, avoid, plan=None):
    per = max(1, math.ceil(n_ask / len(passages)))
    kinds = store.doc_types()
    body = []
    for i, p in enumerate(passages, start=1):
        where = store.loc_label(kinds.get(p["doc"], "pdf"), p["page_start"], p["page_end"])
        body.append(f"[{i}] ({p['doc']}, {where}, section: {p['heading']})\n{p['text']}")
    asked = "\n".join(f"- {q}" for q in avoid[-25:]) or "(none)"
    mix = (f"\n\nDIFFICULTY MIX to aim for across the {n_ask} questions: {plan['easy']} easy, "
           f"{plan['medium']} medium, {plan['hard']} hard." if plan else "")
    user = (f"Topic: {label}\n\nPassages:\n" + "\n\n".join(body) + mix
            + f"\n\nALREADY ASKED:\n{asked}")
    r = llm.ask("setter", [{"role": "system", "content": SETTER_SYSTEM.format(n=n_ask, per=per)},
                           {"role": "user", "content": user}],
                max_tokens=WRITER_TOKENS, use_cache=False, timeout=WRITER_TIMEOUT)
    # a cut-off reply may still hold complete questions: the parser keeps only complete ones
    return parse_setter_output(r["text"], len(passages)), r["model"]


def _check_one(draft, passage, writer_model):
    """Runs in a worker thread: the checker (other family) prepares and tests the answer key."""
    options = "".join(f"\n{L}: {t}" for L, t in draft["options"].items())
    where = store.loc_label(store.doc_type(passage["doc"]), passage["page_start"], passage["page_end"])
    user = (f"Passage ({passage['doc']}, {where}):\n{passage['text']}\n\n"
            f"Question type: {draft['qtype'].upper()}\nQuestion: {draft['question']}{options}")
    try:
        r = llm.ask("key", [{"role": "system", "content": CHECKER_SYSTEM},
                            {"role": "user", "content": user}],
                    max_tokens=CHECKER_TOKENS, avoid_family=llm.family(writer_model),
                    timeout=CHECKER_TIMEOUT)
    except llm.AllModelsBusy:
        return {"ok": False, "reason": "no checker model was available", "busy": True}
    if r.get("truncated"):
        return {"ok": False, "reason": "the checker ran out of length"}
    res = parse_check_output(r["text"], draft, passage["text"])
    res["checker_model"] = r["model"]
    return res


def _make_questions(label, pool, want, vec_state, progress, plan_fn=None, slack=True):
    """
    Produce up to `want` verified questions for one topic.
    vec_state = {'vecs': array of earlier question vectors, 'texts': set of normalised texts,
                 'asked': list of earlier question texts, 'embed_model': str | None,
                 'topic_of': {unit_id: section name}}
    progress(n_new_questions) is called each time a question is accepted.
    plan_fn(n) gives the difficulty mix for n questions (from the learner model) or None.
    slack=False asks for exactly the number needed, one per passage (diagnostic quiz).
    Returns (questions, notes, dropped_counter).
    """
    accepted, notes, dropped = [], [], Counter()
    ordered = _order_by_novelty(pool)
    offset = 0
    for round_no in range(MAX_ROUNDS):
        need = want - len(accepted)
        if need <= 0:
            break
        n_ask = need + (max(1, need // 3) if slack else 0)
        take = min(len(ordered), n_ask)
        passages = [ordered[(offset + i) % len(ordered)] for i in range(take)]
        offset += take
        try:
            drafts, writer_model = _write_questions(
                label, passages, n_ask, vec_state["asked"] + [a["question"] for a in accepted],
                plan_fn(n_ask) if plan_fn else None)
        except llm.AllModelsBusy as e:
            notes.append(f"No language model was available to write questions for '{label}'.")
            break
        if not drafts:
            dropped["setter reply had no usable questions"] += 1
            continue

        # ---- repeats (history + this quiz), before the checker is paid for ----
        vecs, model = embed.embed_texts([d["question"] for d in drafts], kind="passage",
                                        model_name=vec_state["embed_model"])
        vec_state["embed_model"] = model
        keep = []
        for d, v in zip(drafts, vecs):
            d["vector"] = v
            hist = vec_state["vecs"]
            if _norm(d["question"]) in vec_state["texts"] or (
                    hist.shape[0] and float(np.max(hist @ v)) >= REPEAT_SIM):
                dropped["repeat of an earlier question"] += 1
                continue
            if d["qtype"] == "mcq":                       # shuffled now, so letters in the key are the final letters
                d["options"] = _shuffled(d["options"])
            keep.append(d)
            vec_state["vecs"] = np.vstack([hist, v[None, :]]) if hist.shape[0] else v[None, :]
            vec_state["texts"].add(_norm(d["question"]))

        # ---- checker, several at a time ----
        results = {}
        with ThreadPoolExecutor(max_workers=CHECK_WORKERS) as pool_exec:
            futures = {pool_exec.submit(_check_one, d, passages[d["source"] - 1], writer_model): i
                       for i, d in enumerate(keep)}
            for fut in as_completed(futures):
                results[futures[fut]] = fut.result()
        busy = 0
        for i, d in enumerate(keep):
            res = results[i]
            if not res["ok"]:
                dropped[res["reason"]] += 1
                busy += 1 if res.get("busy") else 0
                continue
            if len(accepted) >= want:
                break
            passage = passages[d["source"] - 1]
            options, key = d["options"], res["key"]
            if d["qtype"] == "mcq":
                options = {L: fmt.tidy(t, use_model=False) for L, t in options.items()}
            elif d["qtype"] == "short":
                key = {"reference": fmt.tidy(key["reference"]), "points": [fmt.tidy(x, use_model=False) for x in key["points"]]}
            accepted.append({
                "doc": passage["doc"], "chunk_id": passage["id"], "heading": passage["heading"],
                "page_start": passage["page_start"], "page_end": passage["page_end"],
                "topic": vec_state["topic_of"].get(passage.get("unit_id")) or label, "concept": d["concept"],
                "qtype": d["qtype"], "difficulty": d["difficulty"], "question": fmt.tidy(d["question"]),
                "options": options, "key": key, "explanation": fmt.tidy(res["explanation"]),
                "mistake": fmt.tidy(res["mistake"], use_model=False), "evidence": res["evidence"],
                "writer_model": writer_model, "checker_model": res["checker_model"],
                "vector": d["vector"]})
            progress(1)
        if keep and busy == len(keep):
            notes.append("No checker model was available, so no question could be verified.")
            break
    return accepted, notes, dropped


def _save_set(kind, scope_label, wanted, questions, embed_model):
    conn = _conn()
    cur = conn.execute("INSERT INTO quiz_sets (kind, scope, wanted, created) VALUES (?,?,?,?)",
                       (kind, scope_label, wanted, time.time()))
    set_id = cur.lastrowid
    for pos, q in enumerate(questions, start=1):
        conn.execute(
            "INSERT INTO quiz_questions (set_id, pos, doc, chunk_id, topic, concept, qtype, difficulty, "
            "question, options, key, explanation, mistake, evidence, heading, page_start, page_end, "
            "writer_model, checker_model, embed_model, vector, created) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (set_id, pos, q["doc"], q["chunk_id"], q["topic"], q["concept"], q["qtype"], q["difficulty"],
             q["question"], json.dumps(q["options"]), json.dumps(q["key"]), q["explanation"],
             q["mistake"], q["evidence"], q["heading"], q["page_start"], q["page_end"],
             q["writer_model"], q["checker_model"], embed_model,
             np.asarray(q["vector"], dtype="float32").tobytes(), time.time()))
    conn.commit()
    conn.close()
    return set_id


def _result(ok, message, set_id=None, n=0, wanted=0, dropped=None, notes=None):
    return {"ok": ok, "message": message, "set_id": set_id, "n": n, "wanted": wanted,
            "dropped": dict(dropped or {}), "notes": notes or []}


def _build(kind, scope_label, jobs, wanted, progress):
    """jobs = [(topic label, pool, how many questions, plan_fn, slack)]. Shared by every kind of quiz."""
    conn = _conn()
    row = conn.execute("SELECT embed_model FROM quiz_questions ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    embed_model = row[0] if row and row[0] else None     # vectors of different models cannot be compared
    vecs0, asked = _history(embed_model)
    state = {"vecs": vecs0, "texts": {_norm(q) for q in asked}, "asked": asked,
             "embed_model": embed_model, "topic_of": _unit_to_topic()}

    done = {"n": 0}

    def tick(k):
        done["n"] += k
        if progress:
            progress(min(done["n"], wanted), wanted)

    all_q, notes, dropped = [], [], Counter()
    for label, pool, n, plan_fn, slack in jobs:
        qs, nts, dr = _make_questions(label, pool, n, state, tick, plan_fn, slack)
        all_q.extend(qs)
        notes.extend(nts)
        dropped.update(dr)
    minimum = max(3, wanted // 2)
    if len(all_q) < minimum:
        why = "; ".join(f"{k} ({v})" for k, v in dropped.most_common(3))
        return _result(False, f"Only {len(all_q)} usable question(s) could be made, which is too few."
                              + (f" Main reasons: {why}." if why else ""),
                       n=len(all_q), wanted=wanted, dropped=dropped, notes=notes)
    if kind == "mock":
        random.shuffle(all_q)          # topics mixed, like a real paper
    set_id = _save_set(kind, scope_label, wanted, all_q, state["embed_model"])
    msg = "" if len(all_q) == wanted else (
        f"Only {len(all_q)} of {wanted} questions could be made and verified (the material on this "
        "topic may be limited, or some questions failed the checks).")
    return _result(True, msg, set_id=set_id, n=len(all_q), wanted=wanted, dropped=dropped, notes=notes)


def create_topic_quiz(topic, progress=None, docs=None):
    """A quiz of TOPIC_QUIZ_SIZE questions on a topic the student typed, inside the chosen course
    (docs = its documents). progress(done, total)."""
    topic = (topic or "").strip()
    if len(topic) < 2:
        return _result(False, "Type a topic first.")
    if not store.list_docs():
        return _result(False, "Upload material first.")
    pool, best = _pool_from_search(topic, TOPIC_QUIZ_SIZE, docs)
    if best < QUIZ_REFUSE_BELOW or not pool:
        return _result(False, f"I couldn't find “{topic}” in your uploaded material, so I won't write "
                              "questions about it. Try one of the topics listed below.")
    return _build("topic", topic, [(topic, pool, TOPIC_QUIZ_SIZE, _plan_for(pool), True)], TOPIC_QUIZ_SIZE, progress)


def create_mock_exam(topics, progress=None):
    """A mock exam of MOCK_SIZE questions on exactly MOCK_TOPICS tagged topics."""
    topics = list(dict.fromkeys(topics))
    if len(topics) != MOCK_TOPICS:
        return _result(False, f"Choose exactly {MOCK_TOPICS} topics.")
    per = MOCK_SIZE // MOCK_TOPICS
    roles = outline.load_roles()
    jobs = []
    for t in topics:
        pool = [c for c in _chunks_for_topic(t) if _kind_ok(c, roles)]
        if not pool:
            return _result(False, f"The topic “{t}” has no usable passages.")
        jobs.append((t, pool, per, _plan_for(pool), True))
    return _build("mock", " | ".join(topics), jobs, per * MOCK_TOPICS, progress)


def _plan_for(pool, student=None):
    """A function n -> difficulty mix, aimed at this student's ability on the topics the passages belong to."""
    try:
        topics = learner.topics_for_units([c.get("unit_id") for c in pool])
    except Exception:
        return None
    who = student or learner.current_student()
    return lambda n: learner.difficulty_plan(who, topics, n)


def create_diagnostic(progress=None, docs=None):
    """
    A diagnostic quiz for a new student: ONE question on each of up to DIAGNOSTIC_TOPICS topics of the CHOSEN
    COURSE (docs), spread over it in book order, with a mix of difficulties. Its answers start the learner
    model for those topics.
    """
    all_topics = outline.topics(docs)
    if not all_topics:
        return _result(False, "Upload material first.")
    if len(all_topics) > DIAGNOSTIC_TOPICS:
        step = (len(all_topics) - 1) / (DIAGNOSTIC_TOPICS - 1)
        all_topics = [all_topics[round(i * step)] for i in range(DIAGNOSTIC_TOPICS)]
    roles = outline.load_roles()
    pool = []
    for t in all_topics:
        chunks = [c for c in _chunks_for_topic(t["topic"]) if _kind_ok(c, roles)]
        if chunks:
            pool.append(_order_by_novelty(chunks)[0])
    if len(pool) < 3:
        return _result(False, "Not enough sorted topics in the material for a diagnostic quiz yet.")

    def mix(n):
        easy = n // 3
        hard = n // 6
        return {"easy": easy, "medium": n - easy - hard, "hard": hard}

    return _build("diagnostic", "one question per topic", [("Diagnostic", pool, len(pool), mix, False)],
                  len(pool), progress)


# =====================================================================
# 4. Reading a quiz back, answering, grading
# =====================================================================
def _question_row(r, a):
    q = {"id": r[0], "set_id": r[1], "pos": r[2], "doc": r[3], "topic": r[4], "concept": r[5],
         "qtype": r[6], "difficulty": r[7], "question": r[8], "options": json.loads(r[9] or "{}"),
         "key": json.loads(r[10] or "{}"), "explanation": r[11], "mistake": r[12], "heading": r[13],
         "page_start": r[14], "page_end": r[15], "writer_model": r[16], "checker_model": r[17],
         "answer": None}
    if a:
        q["answer"] = {"answer": a[0], "score": a[1], "feedback": a[2], "graded_by": a[3]}
    return q


def load_set(set_id):
    conn = _conn()
    s = conn.execute("SELECT id, kind, scope, wanted, created, submitted, report FROM quiz_sets WHERE id=?",
                     (set_id,)).fetchone()
    if not s:
        conn.close()
        return None
    rows = conn.execute(
        "SELECT q.id, q.set_id, q.pos, q.doc, q.topic, q.concept, q.qtype, q.difficulty, q.question, "
        "q.options, q.key, q.explanation, q.mistake, q.heading, q.page_start, q.page_end, "
        "q.writer_model, q.checker_model, a.answer, a.score, a.feedback, a.graded_by "
        "FROM quiz_questions q LEFT JOIN quiz_answers a ON a.question_id = q.id "
        "WHERE q.set_id=? ORDER BY q.pos", (set_id,)).fetchall()
    conn.close()
    questions = [_question_row(r[:18], r[18:22] if r[18] is not None else None) for r in rows]
    return {"id": s[0], "kind": s[1], "scope": s[2], "wanted": s[3], "created": s[4],
            "submitted": s[5], "report": json.loads(s[6]) if s[6] else None, "questions": questions}


def list_sets():
    conn = _conn()
    rows = conn.execute(
        "SELECT s.id, s.kind, s.scope, s.created, s.submitted, "
        "(SELECT COUNT(*) FROM quiz_questions q WHERE q.set_id = s.id), "
        "(SELECT COUNT(*) FROM quiz_answers a WHERE a.set_id = s.id), "
        "(SELECT COALESCE(SUM(score), 0) FROM quiz_answers a WHERE a.set_id = s.id) "
        "FROM quiz_sets s ORDER BY s.id DESC").fetchall()
    conn.close()
    return [{"id": r[0], "kind": r[1], "scope": r[2], "created": r[3], "submitted": bool(r[4]),
             "questions": r[5], "answered": r[6], "score": r[7]} for r in rows]


def _read_verdict(text):
    """0 / 0.5 / 1 from the grader's reply, or None. The verdict comes first, so a cut-off reply is still usable."""
    t = (text or "").upper()
    m = re.search(r"VERDICT\W*(INCORRECT|PARTLY|PARTIAL|CORRECT)", t)
    word = m.group(1) if m else next((w for w in ("INCORRECT", "PARTLY", "CORRECT")
                                      if re.search(rf"\b{w}\b", t)), None)
    return {"CORRECT": 1.0, "PARTLY": 0.5, "PARTIAL": 0.5, "INCORRECT": 0.0}.get(word)


def _grade_short(q, answer):
    """
    Grade a short answer. Returns (score 0/0.5/1, feedback, grader model name).
    The grader is a model from a family that is neither the question setter's nor the answer-key maker's.
    If no such model answers, it relaxes: first only the key maker's family is avoided, then nobody.
    """
    key = q["key"]
    user = (f"Question: {q['question']}\nReference answer: {key['reference']}\n"
            f"Key points: {'; '.join(key['points'])}\nStudent's answer: {answer}")
    messages = [{"role": "system", "content": GRADER_SYSTEM}, {"role": "user", "content": user}]
    setter_f, key_f = llm.family(q["writer_model"]), llm.family(q["checker_model"])
    for attempt, avoid in enumerate(({setter_f, key_f}, {key_f}, set())):
        try:
            r = llm.ask("grade", messages, max_tokens=CHECKER_TOKENS, avoid_family=avoid,
                        timeout=GRADER_TIMEOUT, use_cache=(attempt == 0))
        except llm.AllModelsBusy:
            continue
        score = _read_verdict(r["text"])
        if score is None:
            continue
        feedback = read_fields(r["text"], ("verdict", "feedback")).get("feedback", "").strip()
        if not feedback:
            feedback = {1.0: "Your answer covers the key points.",
                        0.5: "Your answer is partly right but misses some key points. See the reference answer.",
                        0.0: "Your answer does not match the key points. See the reference answer."}[score]
        return score, fmt.clean(feedback), r["model"]
    # no model could grade it: how many key points have their main words in the answer?
    have = set(_words(answer))
    covered = 0
    for p in key["points"]:
        words = [w for w in _words(p) if len(w) >= 4]
        if words and sum(w in have for w in words) / len(words) >= 0.6:
            covered += 1
    share = covered / max(len(key["points"]), 1)
    score = 1.0 if share >= 0.7 else 0.5 if share >= 0.4 else 0.0
    return score, (f"No grading model answered in time, so this was checked by keyword match "
                   f"({covered} of {len(key['points'])} key points found). Compare with the reference answer."), "keyword match"


def answer_question(question_id, answer):
    """
    Grade and save one answer. Returns {'ok', 'score', 'feedback', 'message'}.
    ok=False means nothing was saved (for example, a numerical answer with no number in it).
    """
    conn = _conn()
    row = conn.execute("SELECT set_id FROM quiz_questions WHERE id=?", (question_id,)).fetchone()
    if not row:
        conn.close()
        return {"ok": False, "message": "Unknown question."}
    s = load_set(row[0])
    q = next(x for x in s["questions"] if x["id"] == question_id)
    if s["submitted"] or q["answer"]:
        conn.close()
        return {"ok": False, "message": "This question is already answered."}
    answer = (answer or "").strip()
    if not answer:
        conn.close()
        return {"ok": False, "message": "Type an answer first."}

    feedback, graded_by = "", "code"
    if q["qtype"] == "mcq":
        score = 1.0 if answer.upper() == q["key"]["correct"] else 0.0
    elif q["qtype"] == "numerical":
        number = parse_number(answer)
        if number is None:
            conn.close()
            return {"ok": False, "message": "I could not find a number in your answer. "
                                            "Write it like 0.25, 3e8 or 3 x 10^8."}
        score = 1.0 if numbers_match(number, q["key"]["value"]) else 0.0
    else:
        try:
            score, feedback, graded_by = _grade_short(q, answer)
        except Exception as e:                       # nothing is saved, so the student can press the button again
            conn.close()
            return {"ok": False, "message": f"Grading did not work this time ({e}). Press the button again."}
    conn.execute("INSERT OR REPLACE INTO quiz_answers VALUES (?,?,?,?,?,?,?)",
                 (question_id, q["set_id"], answer, score, feedback, graded_by, time.time()))
    conn.commit()
    conn.close()
    try:                                             # the learner model must never break answering
        learner.record_answer(learner.current_student(), q["topic"], score, q["difficulty"], q["qtype"], question_id,
                              "diagnostic" if s["kind"] == "diagnostic" else "quiz")
    except Exception:
        pass
    return {"ok": True, "score": score, "feedback": feedback, "message": ""}


# =====================================================================
# 5. The report after Submit
# =====================================================================
def _correct_answer_text(q):
    k = q["key"]
    if q["qtype"] == "mcq":
        return f"{k['correct']}. {q['options'].get(k['correct'], '')}"
    if q["qtype"] == "numerical":
        return f"{format_number(k['value'])} {k['unit']}".strip()
    return k["reference"]


def correct_answer_text(q):
    return _correct_answer_text(q)


def _misconceptions(wrong):
    if not wrong:
        return []
    lines = []
    for q in wrong:
        lines.append(f"- Topic: {q['topic']} | Question: {q['question']} | Student answered: "
                     f"{q['answer']['answer']} | Correct: {_correct_answer_text(q)} | "
                     f"Common mistake: {q['mistake'] or 'unknown'}")
    try:
        r = llm.ask("report", [{"role": "system", "content": REPORT_SYSTEM},
                               {"role": "user", "content": "\n".join(lines)}],
                    max_tokens=2500, timeout=60)
        out = []
        for line in r["text"].splitlines():
            m = re.match(r"^[\s*\-]*misconception\s*:\s*(.+?)\s*\|\s*(.+)$", line, re.I)
            if m:
                out.append({"topic": m.group(1).strip(" *"), "text": fix_math(m.group(2).strip(" *"))})
        if out and not r.get("truncated"):
            return out[:4]
    except llm.AllModelsBusy:
        pass
    return [{"topic": q["topic"], "text": fix_math(q["mistake"])} for q in wrong if q["mistake"]][:4]


def build_report(s):
    qs = s["questions"]
    answered = [q for q in qs if q["answer"]]
    total = sum(q["answer"]["score"] for q in answered)
    by_topic, by_diff = {}, {}
    kinds = store.doc_types()
    for q in qs:
        t = by_topic.setdefault(q["topic"], {"topic": q["topic"], "asked": 0, "answered": 0, "score": 0.0,
                                             "pages": set(), "doc": q["doc"], "kind": kinds.get(q["doc"], "pdf")})
        t["asked"] += 1
        d = by_diff.setdefault(q["difficulty"], {"difficulty": q["difficulty"], "answered": 0, "score": 0.0})
        if q["answer"]:
            t["answered"] += 1
            t["score"] += q["answer"]["score"]
            d["answered"] += 1
            d["score"] += q["answer"]["score"]
        if not q["answer"] or q["answer"]["score"] < 1:
            t["pages"].add(q["page_start"])
    topics = []
    for t in by_topic.values():
        pct = t["score"] / t["answered"] if t["answered"] else 0.0
        topics.append({"topic": t["topic"], "asked": t["asked"], "answered": t["answered"],
                       "score": t["score"], "percent": round(100 * pct),
                       "weak": pct < WEAK_BELOW, "revise": (f"{t['doc']}, " + ", ".join(
                           store.loc_label(t["kind"], p) for p in sorted(t["pages"]))) if t["pages"] else ""})
    topics.sort(key=lambda t: t["percent"])
    wrong = [q for q in answered if q["answer"]["score"] < 1]
    return {"score": total, "asked": len(qs), "answered": len(answered),
            "percent": round(100 * total / len(qs)) if qs else 0,
            "topics": topics,
            "difficulty": [{"difficulty": d["difficulty"], "answered": d["answered"],
                            "percent": round(100 * d["score"] / d["answered"]) if d["answered"] else 0}
                           for d in sorted(by_diff.values(), key=lambda x: ["easy", "medium", "hard"].index(x["difficulty"])
                                           if x["difficulty"] in ("easy", "medium", "hard") else 3)],
            "misconceptions": _misconceptions(wrong)}


def submit_set(set_id):
    """Lock the quiz, build the report, save it, return it."""
    s = load_set(set_id)
    if not s:
        return None
    if s["submitted"]:
        return s["report"]
    report = build_report(s)
    conn = _conn()
    conn.execute("UPDATE quiz_sets SET submitted=?, report=? WHERE id=?",
                 (time.time(), json.dumps(report), set_id))
    conn.commit()
    conn.close()
    return report
