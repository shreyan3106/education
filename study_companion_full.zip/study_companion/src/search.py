"""
Hybrid search over the shared chunk table:
  1. meaning search      (embedding vectors; FAISS, or NumPy if FAISS is missing)
  2. keyword search      (BM25; rank-bm25 library, or a built-in copy if missing)
  3. the two rankings are merged with reciprocal rank fusion (RRF)
"""
import math
import re

import numpy as np

from src import embed, store

RRF_K = 60


def _tokens(text):
    return re.findall(r"\w+", text.lower())


# ---------- meaning search ----------
def _dense_top(matrix, qvec, k):
    k = min(k, len(matrix))
    try:
        import faiss
        index = faiss.IndexFlatIP(matrix.shape[1])      # inner product = cosine (normalised)
        index.add(matrix)
        _, idx = index.search(qvec[None, :], k)
        return [int(i) for i in idx[0] if i >= 0], "faiss"
    except Exception:                                   # FAISS missing or failed
        scores = matrix @ qvec
        return [int(i) for i in np.argsort(-scores)[:k]], "numpy"


# ---------- keyword search ----------
class _SimpleBM25:
    """Small built-in BM25, used only if the rank-bm25 library is missing."""
    def __init__(self, docs, k1=1.5, b=0.75):
        self.docs, self.k1, self.b = docs, k1, b
        self.avg = sum(len(d) for d in docs) / max(len(docs), 1)
        self.df = {}
        for d in docs:
            for t in set(d):
                self.df[t] = self.df.get(t, 0) + 1

    def get_scores(self, query):
        n, scores = len(self.docs), []
        for d in self.docs:
            s, length = 0.0, len(d)
            for t in query:
                f = d.count(t)
                if f:
                    idf = math.log(1 + (n - self.df[t] + 0.5) / (self.df[t] + 0.5))
                    s += idf * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * length / self.avg))
            scores.append(s)
        return scores


def _keyword_top(rows, query, k):
    docs = [_tokens(r["heading"] + " " + r["text"]) for r in rows]
    q = _tokens(query)
    try:
        from rank_bm25 import BM25Okapi
        scores, engine = BM25Okapi(docs).get_scores(q), "rank-bm25"
    except Exception:
        scores, engine = _SimpleBM25(docs).get_scores(q), "built-in"
    order = [int(i) for i in np.argsort(-np.asarray(scores))[:k] if scores[i] > 0]
    return order, engine


# ---------- search ----------
def search(query, k=5, per_method=20, docs=None):
    """
    Return {'results': [...], 'best_dense': float, 'model', 'skipped',
            'dense_engine', 'keyword_engine'}.
    docs = a list of document names to search in (None = all of them: a course is a set of documents).
    Each result is a chunk (doc, heading, path, pages, text) plus
    'score' (merged rank score) and 'dense' (cosine similarity, 0-1 scale).
    """
    rows, matrix, model, skipped = store.load_chunks()
    if rows and docs is not None:
        keep = [i for i, r in enumerate(rows) if r["doc"] in set(docs)]
        rows, matrix = [rows[i] for i in keep], (matrix[keep] if keep else None)
    if not rows:
        return {"results": [], "best_dense": 0.0, "model": None, "skipped": 0,
                "dense_engine": None, "keyword_engine": None}

    qvec, _ = embed.embed_texts([query], kind="query", model_name=model)
    qvec = qvec[0]
    dense_ids, dense_engine = _dense_top(matrix, qvec, per_method)
    keyword_ids, keyword_engine = _keyword_top(rows, query, per_method)

    fused = {}
    for ranking in (dense_ids, keyword_ids):
        for rank, i in enumerate(ranking):
            fused[i] = fused.get(i, 0.0) + 1.0 / (RRF_K + rank + 1)

    results = []
    for i, score in sorted(fused.items(), key=lambda x: -x[1])[:k]:
        r = dict(rows[i])
        r["score"] = round(score, 4)
        r["dense"] = round(float(matrix[i] @ qvec), 3)
        r["found_by"] = ", ".join(n for n, ids in (("meaning", dense_ids), ("keywords", keyword_ids)) if i in ids)
        results.append(r)

    best_dense = float(np.max(matrix @ qvec))
    return {"results": results, "best_dense": round(best_dense, 3), "model": model,
            "skipped": skipped, "dense_engine": dense_engine, "keyword_engine": keyword_engine}
