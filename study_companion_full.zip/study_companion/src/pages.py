"""Show the exact page a citation points to (as a picture), with the passage highlighted."""
import os

from src import store


def render_page(doc_name, page_number, highlight_text=None, dpi=110):
    """Return PNG bytes of one page, or None if the file or page is not available."""
    path = store.file_path(doc_name)
    if not os.path.exists(path):
        return None
    import pymupdf
    with pymupdf.open(path) as doc:
        if not 1 <= page_number <= len(doc):
            return None
        page = doc[page_number - 1]
        if highlight_text:
            try:                                   # best effort: failing just means no highlight
                for rect in page.search_for(" ".join(highlight_text.split()[:6])):
                    page.add_highlight_annot(rect)
            except Exception:
                pass
        return page.get_pixmap(dpi=dpi).tobytes("png")
