"""
Pictures in study material: a vision model reads them.

  describe_image(png)               one figure -> a short searchable description
  describe_pdf_figures(doc, ...)    finds the PDF pages that carry figures, has a vision model describe them, and
                                    saves each description as an extra searchable passage in the same section
  ocr_units(pdf_bytes, pages, ...)  pages with no text layer (scans) are transcribed by a vision model and
                                    returned as units, so a scanned textbook is searchable too

The vision models are tried best first (see LADDERS["vision"] in llm.py). When none is available the
functions return a note and the rest of the app carries on without figures.
"""
import numpy as np

from src import embed, llm, store

FIGURE_PAGES_PER_RUN = 30         # vision calls are slow and limited: this many figure pages at a time
OCR_PAGES_PER_RUN = 60
MIN_TEXT_WORDS = 15               # a page with fewer words than this (and a picture) is treated as a scan
DPI = 100

FIGURE_SYSTEM = """You describe figures from a student's course material so that they can be found by search and used to answer questions.
Describe every figure, diagram, graph or table on the page: what it shows, every label, symbol and value you can read, and how the parts relate. Write formulas in LaTeX between single dollar signs. Be factual and complete but short (at most 120 words per figure). If there is no real figure, only decoration, reply with exactly: NONE"""

OCR_SYSTEM = """You transcribe a scanned page of a textbook. Write ALL the text on the page in reading order, exactly as printed. Put headings on their own line. Write formulas in LaTeX between single dollar signs. Write tables as rows with | between cells. Describe a figure in one line starting with "Figure:". Reply with only the transcription."""


def describe_image(png, context=""):
    """A description of one picture, or None if there is nothing to describe or no model answered."""
    prompt = "Describe the figure." + (f" It comes from: {context}." if context else "")
    try:
        r = llm.ask_vision(prompt, [png], system=FIGURE_SYSTEM, max_tokens=700)
    except llm.AllModelsBusy:
        return None
    text = r["text"].strip()
    return None if not text or text.upper().startswith("NONE") else text


# ---------- PDF figures ----------
def pdf_figure_pages(pdf_path, skip=()):
    """Page numbers that carry figures, biggest first: [(page, score)]. Uses PyMuPDF."""
    import pymupdf
    found = []
    with pymupdf.open(pdf_path) as pdf:
        for number, page in enumerate(pdf, start=1):
            if number in skip:
                continue
            area = page.rect.width * page.rect.height or 1
            image_area = 0.0
            try:
                for info in page.get_image_info():
                    x0, y0, x1, y1 = info["bbox"]
                    image_area += max(0.0, x1 - x0) * max(0.0, y1 - y0)
                drawings = len(page.get_drawings())
            except Exception:
                continue
            score = image_area / area + min(drawings, 200) / 400
            if image_area / area >= 0.03 or drawings >= 12:
                found.append((number, score))
    return sorted(found, key=lambda x: -x[1])


def _figures_done(doc):
    import json
    try:
        return set(json.loads(store.get_meta(doc)["extra"] or "{}").get("figures_done", []))
    except ValueError:
        return set()


def _mark_done(doc, pages):
    import json
    meta = store.get_meta(doc)
    try:
        extra = json.loads(meta["extra"] or "{}")
    except ValueError:
        extra = {}
    extra["figures_done"] = sorted(set(extra.get("figures_done", [])) | set(pages))
    store.set_meta(doc, meta["url"], json.dumps(extra))


def add_passage(doc, page, heading, text):
    """Save an extra searchable passage (for example a figure description) in the section that covers a page."""
    conn = store._db()
    unit = conn.execute("SELECT id, path FROM pdf_units WHERE doc=? AND page_start<=? AND page_end>=? "
                        "ORDER BY level DESC, id DESC LIMIT 1", (doc, page, page)).fetchone()
    if unit is None:
        unit = conn.execute("SELECT id, path FROM pdf_units WHERE doc=? ORDER BY ABS(page_start-?) LIMIT 1",
                            (doc, page)).fetchone()
    row = conn.execute("SELECT embed_model, source_type FROM chunks WHERE doc=? LIMIT 1", (doc,)).fetchone()
    if unit is None or row is None:
        conn.close()
        return False
    vec, _ = embed.embed_texts([f"{unit[1]}\n{text}"], model_name=row[0])
    v = np.asarray(vec[0], dtype="float32")
    conn.execute("INSERT INTO chunks (source_type, unit_id, doc, heading, path, page_start, page_end, text, "
                 "embed_model, dim, vector) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                 (row[1], unit[0], doc, heading, unit[1], page, page, text, row[0], len(v), v.tobytes()))
    conn.commit()
    conn.close()
    return True


def describe_pdf_figures(doc, limit=FIGURE_PAGES_PER_RUN, progress=None):
    """
    Describe the figures on up to `limit` more pages of a saved PDF. Returns (pages_described, note).
    Pages already done are skipped, so pressing the button again continues where it stopped.
    """
    from src.pages import render_page
    path = store.file_path(doc)
    try:
        candidates = pdf_figure_pages(path, skip=_figures_done(doc))
    except Exception as e:
        return 0, f"Figures could not be read from this file: {e}"
    if not candidates:
        return 0, "No more pages with figures."
    batch = [p for p, _ in candidates[:limit]]
    done, empty = [], []
    for i, page in enumerate(sorted(batch), start=1):
        png = render_page(doc, page, None, dpi=DPI)
        text = describe_image(png, f"{doc}, page {page}") if png else None
        if text:
            add_passage(doc, page, f"Figure (page {page})", f"Figure on page {page}: {text}")
            done.append(page)
        else:
            empty.append(page)
        if progress:
            progress(i, len(batch))
        if text is None and not llm_available():
            return len(done), f"Stopped: no vision model was available. {len(done)} pages described."
    _mark_done(doc, done + empty)
    left = len(candidates) - len(batch)
    return len(done), (f"{len(done)} pages with figures described." + (f" {left} more pages have figures: press the button again to continue." if left > 0 else ""))


AUTO_FIGURE_PAGES = 12            # pages with figures described automatically after an upload (the biggest figures first)


def vision_ready(wait=75.0):
    """
    A quick check, before reading figures, that some vision model answers: True or False within `wait` seconds.
    Without it an upload could sit for minutes while dead models time out one after the other (each rests after
    its 60 seconds, so the next check is instant).
    """
    import threading
    result = {}

    def check():
        result["ok"] = llm_available()
    t = threading.Thread(target=check, daemon=True)
    t.start()
    t.join(wait)
    return bool(result.get("ok"))


def llm_available():
    try:
        llm.ask("vision", [{"role": "user", "content": "ok"}], max_tokens=5, use_cache=False)
        return True
    except llm.AllModelsBusy:
        return False
    except Exception:
        return True


# ---------- scanned pages ----------
def scanned_pages(pdf_bytes):
    """Pages with a picture but almost no text: probably a scan."""
    import pymupdf
    out = []
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as pdf:
        for number, page in enumerate(pdf, start=1):
            if len(page.get_text().split()) < MIN_TEXT_WORDS and page.get_image_info():
                out.append(number)
    return out


def ocr_units(pdf_bytes, pages, progress=None, limit=OCR_PAGES_PER_RUN):
    """Transcribe scanned pages with a vision model. Returns (units, note); each unit is one page."""
    import pymupdf
    units, skipped = [], max(0, len(pages) - limit)
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as pdf:
        for i, number in enumerate(pages[:limit], start=1):
            png = pdf[number - 1].get_pixmap(dpi=130).tobytes("png")
            try:
                r = llm.ask_vision("Transcribe this page.", [png], system=OCR_SYSTEM, max_tokens=2500)
            except llm.AllModelsBusy:
                return units, f"Stopped reading scanned pages at page {number}: no vision model was available."
            text = r["text"].strip()
            if text:
                units.append({"heading": f"Scanned page {number}", "level": 2, "path": f"Scanned page {number}",
                              "page_start": number, "page_end": number,
                              "paragraphs": [{"page": number, "text": text}], "text": text})
            if progress:
                progress(i, min(limit, len(pages)))
    note = f"{len(units)} scanned pages were read by a vision model."
    if skipped:
        note += f" {skipped} more scanned pages were not read (limit {limit} per upload)."
    return units, note
