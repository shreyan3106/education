"""
One place for every LLM call.

HOW IT WORKS
  ask(job, messages) tries a LADDER of models for that job, BEST FIRST, top to bottom:
    - skips a model if its API key is missing (so ONE key is enough to run the app), or our own
      SQLite counter says a free limit would be exceeded, or it is resting after a failure;
    - THE 60-SECOND RULE: every model has 60 seconds to START answering (the first piece of the reply;
      a "thinking" piece counts). If nothing has started by then it rests for 10 minutes (the rest is
      saved, so a restart does not forget it) and the next model is tried. Once a model IS answering
      there is NO total time limit: a long answer may take as long as it takes;
    - THE SILENCE RULE: if a model that was answering goes silent for 60 seconds, or its connection
      breaks, the task is HANDED OVER at once (no waiting) to the next model. The next model gets the
      same conversation plus what was already written (for free-text jobs such as tutor answers it
      continues that text; for strict-format jobs it starts the same task again). On a hand-over the
      remaining models are tried FASTEST FIRST (measured speed, kept in SQLite);
    - NEVER hands back a cut-off answer if it can help it: when a reply stops at the token limit it asks
      the same model again with a larger limit, then moves on to the next model; a cut-off reply is
      returned (truncated=True) only if every model failed;
    - answers instantly from the cache if the same question was asked before;
    - raises AllModelsBusy (the app shows a message) if every model is used up.
  avoid_family may be one family or several: the quiz uses it so the question setter, the answer-key
  maker and the grader are always three different model families.
  ask_vision() does the same for questions about images (figures, scanned pages, slides).
  rerank_api() ranks passages with a real rerank model (a fallback for the language-model reranker).

HOW THE ORDER IS CHOSEN
  The lists below are best first. The Model check tab can measure every model on small test
  tasks and save a new order for each job in data/ladders.json; that file wins over the lists.

HOW TO EDIT
  Each provider has its own list of model ids below (a list, not a comma-separated
  string). Ids that still start with "paste-" are skipped until you replace them.
"""
import base64
import hashlib
import json
import os
import queue
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.request


try:
    from dotenv import load_dotenv
    load_dotenv()                       # reads the keys from your .env file
except ImportError:
    pass

DB_PATH = "data/app.db"

# =====================================================================
# 1. PROVIDERS  (each speaks the same "OpenAI" language, one library for all)
#    One key per provider; the keys are NOT interchangeable between providers.
# =====================================================================
PROVIDERS = {
    "nvidia":     {"base_url": "https://integrate.api.nvidia.com/v1",
                   "key_env": "NVIDIA_API_KEY"},
    "groq":       {"base_url": "https://api.groq.com/openai/v1",
                   "key_env": "GROQ_API_KEY"},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1",
                   "key_env": "OPENROUTER_API_KEY"},
    # Hugging Face Inference Providers: one OpenAI-compatible address for many hosted models, the same
    # token (HF_TOKEN) as for downloading models. The free tier is small (monthly credits): a backup, mainly
    # for models that read images. When the credits run out the service answers 402 and we rest it.
    "huggingface": {"base_url": "https://router.huggingface.co/v1",
                    "key_env": "HF_TOKEN"},

    # ---- ideas to research (verify the address in each provider's docs) ----
    # "cerebras":   {"base_url": "https://api.cerebras.ai/v1",  "key_env": "CEREBRAS_API_KEY"},
    # "perplexity": {"base_url": "https://api.perplexity.ai",   "key_env": "PERPLEXITY_API_KEY"},
}

# =====================================================================
# 2. MODEL LISTS, one section per provider
# =====================================================================
# --- NVIDIA NIM (build.nvidia.com). Copy each id from the model page
# ("model": "..." in the code sample) and check it still says "Free Endpoint".
# Measured on your laptop on 4 Oct 2026 (a tiny "ready" test; speeds change by
# time of day, so re-test now and then):
#   nemotron-3-super 1.5 s | deepseek-v4.1-flash 89 s | kimi-k3 83 s | gemma-4 timed out
NVIDIA_MODELS = [
    "z-ai/glm-5.3",                                   # 753B text, 1M context, reasoning
    "moonshotai/kimi-k3",                             # slow (about 85 s) but strong
    "nvidia/nemotron-3-super-120b-a12b",
    "z-ai/glm-5.3-flash",                             # 320B (18B active) multimodal, 1M context
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",  # image, video, audio, text; 262K context
    "meta/llama-3.2-90b-vision-instruct",             # vision, 131K context
    "google/gemma-4-31b-it",                          # parked: kept as it was
    "deepseek-ai/deepseek-v4.1-flash",                # parked: kept as it was
]

# --- Groq (measured: qwen3.8-27b 0.3 s | gpt-oss-20b 0.6 s | gpt-oss-120b 0.8 s).
# These are the free models in your Groq console. The 4th slot is empty because
# the only other free model there is "gpt-oss-safeguard-20b", which is built
# for safety classification, not for answering questions.
GROQ_MODELS = [
    "openai/gpt-oss-120b",
    "qwen/qwen3.8-27b",
    "openai/gpt-oss-20b",
    "paste-another-groq-model-id-here",
]

# --- OpenRouter: ids ending in ":free". This list rotates often, so check
# openrouter.ai/models (filter Price: Free, Output: Text) and refresh it.
# "openrouter/free" is OpenRouter's own router that picks any free model.
# Free OpenRouter models share ONE small daily budget (see PROVIDER_LIMITS), so they are
# used for the quality jobs only.
OPENROUTER_MODELS = [
    "nvidia/nemotron-3-ultra-550b-a55b:free",
    "inclusionai/ling-3.1-flash",                     # 25B active of 560B, 262K context, reasoning (host: NovitaAI)
    "nvidia/nemotron-3-super-120b-a12b:free",         # the same model as on NVIDIA directly: a second route to it
    "apodex/apodex-1.1-mini:free",                    # reasoning-first, 262K context
    "thinkingmachines/inkling-small:free",            # 12B active of 276B; free endpoint may refuse plain API calls
    "nvidia/nemotron-3.5-lightning:free",             # 3B active of 30B, 1M context, fast
    "openrouter/free",
]

# Hugging Face hosted models (a backup, mostly for reading pictures). An id may end with ":provider" or
# ":fastest" to choose the backend. Only the first one is confirmed in Hugging Face's own documentation;
# the others may or may not be served right now: a model that does not answer is skipped after 60 s and
# rests, and the Model check tab shows which ones work. Replace or add ids from a model's Hugging Face page.
HF_MODELS = [
    "CohereLabs/command-a-vision-07-2025:cohere",
    "Qwen/Qwen2.5-VL-7B-Instruct",
    "google/gemma-3-27b-it",
    "meta-llama/Llama-3.2-11B-Vision-Instruct",
]

# Rerank model (a real cross-encoder, not a chat model). Used only as a fallback when no language
# model could rerank the passages. Called through OpenRouter's rerank endpoint.
RERANK_MODEL = "nvidia/llama-nemotron-rerank-vl-1b-v2:free"
RERANK_URL = "https://openrouter.ai/api/v1/rerank"


def _pairs(provider, models):
    return [(provider, m) for m in models]


def family(model):
    """Model family, used to keep the checker different from the writer."""
    name = model.lower()
    if name.startswith("google/"):
        return "google"
    if "/" in name:
        return name.split("/")[0]
    return name


# =====================================================================
# 3. LADDERS: which models each job tries, in order
# =====================================================================
# Best first. Order = what your Model check measured on 10 Oct 2026 (quality, then speed); models that
# timed out there are last. The Model check tab can measure again and save a new order (data/ladders.json).
_QUALITY = [("groq", "openai/gpt-oss-120b"),
            ("nvidia", "nvidia/nemotron-3-super-120b-a12b"),
            ("groq", "qwen/qwen3.8-27b"),
            ("nvidia", "z-ai/glm-5.3"),
            ("groq", "openai/gpt-oss-20b"),
            ("openrouter", "nvidia/nemotron-3-ultra-550b-a55b:free"),
            ("openrouter", "inclusionai/ling-3.1-flash"),
            ("openrouter", "nvidia/nemotron-3-super-120b-a12b:free"),
            ("openrouter", "apodex/apodex-1.1-mini:free"),
            ("nvidia", "moonshotai/kimi-k3"),
            ("nvidia", "z-ai/glm-5.3-flash"),
            ("openrouter", "thinkingmachines/inkling-small:free"),
            ("openrouter", "nvidia/nemotron-3.5-lightning:free"),
            ("nvidia", "google/gemma-4-31b-it"),
            ("nvidia", "deepseek-ai/deepseek-v4.1-flash"),
            ("openrouter", "openrouter/free")]

# Reads a whole document at once: only models with a very long context, best first.
_LONG_CONTEXT = [("nvidia", "nvidia/nemotron-3-super-120b-a12b"),
                 ("nvidia", "z-ai/glm-5.3"),
                 ("nvidia", "z-ai/glm-5.3-flash"),
                 ("openrouter", "nvidia/nemotron-3-ultra-550b-a55b:free"),
                 ("openrouter", "inclusionai/ling-3.1-flash"),
                 ("openrouter", "nvidia/nemotron-3-super-120b-a12b:free"),
                 ("openrouter", "apodex/apodex-1.1-mini:free"),
                 ("openrouter", "thinkingmachines/inkling-small:free"),
                 ("openrouter", "nvidia/nemotron-3.5-lightning:free"),
                 ("nvidia", "moonshotai/kimi-k3"),
                 ("nvidia", "deepseek-ai/deepseek-v4.1-flash")]

# Two tiny jobs that run on EVERY question: best among the fast models (free OpenRouter models
# are kept out: their small daily budget is for the quality jobs).
_FAST = [("groq", "openai/gpt-oss-120b"),
         ("groq", "qwen/qwen3.8-27b"),
         ("nvidia", "nvidia/nemotron-3-super-120b-a12b"),
         ("groq", "openai/gpt-oss-20b"),
         ("nvidia", "z-ai/glm-5.3-flash")]

# Reads images: best first (the first two also read audio/video text in their own way).
# On 10 Oct none of these answered in the benchmark (time-outs); the 60-second rule skips them quickly.
_VISION = [("huggingface", "CohereLabs/command-a-vision-07-2025:cohere"),
           ("nvidia", "z-ai/glm-5.3-flash"),
           ("nvidia", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning"),
           ("nvidia", "meta/llama-3.2-90b-vision-instruct"),
           ("huggingface", "Qwen/Qwen2.5-VL-7B-Instruct"),
           ("huggingface", "google/gemma-3-27b-it"),
           ("huggingface", "meta-llama/Llama-3.2-11B-Vision-Instruct"),
           ("openrouter", "thinkingmachines/inkling-small:free")]

LADDERS = {
    "answer": _QUALITY,       # tutor answers (kept short by the prompt)
    "check": _QUALITY,        # supervisor of tutor answers: call with avoid_family=<writer's family>
    "extract": _QUALITY,      # heading clean-up, concepts, prerequisites
    "outline": _LONG_CONTEXT, # reads a whole document: headings, topics, concepts
    "setter": _QUALITY,       # writes quiz questions
    "key": _QUALITY,          # prepares the answer key: avoid the setter's family
    "grade": _QUALITY,        # grades short answers: avoid the setter's AND the key maker's family
    "report": _QUALITY,       # quiz report, coach answers
    "format": _FAST,          # repairs broken math formatting
    "rewrite": _FAST,         # turns "explain that again" into a standalone question
    "rerank": _FAST,          # picks the best passages out of a candidate list
    "vision": _VISION,
}

# =====================================================================
# 4. FREE-TIER LIMITS (edit if your console shows different numbers)
# =====================================================================
# Per model. From your Groq console: requests/minute, requests/day,
# tokens/minute, tokens/day.
_GROQ_TEXT = dict(rpm=30, rpd=1000, tpm=8000, tpd=200000)
LIMITS = {("groq", m): _GROQ_TEXT for m in GROQ_MODELS}

# Per provider, counted across all its models. NVIDIA reports about 40 requests
# a minute (check the number on your dashboard; no daily cap was reported).
# OpenRouter free models were reported at 20/minute and 50/day in total.
PROVIDER_LIMITS = {
    "nvidia": dict(rpm=30),
    "openrouter": dict(rpm=20, rpd=50),
    "huggingface": dict(rpm=20, rpd=150),          # conservative: the real limit is the monthly credit
}

# THE TIME RULES (the same for every model and every job)
START_WAIT = 60.0          # seconds a model has to START answering (first piece, thinking counts)
SILENCE_LIMIT = 60.0       # once started there is no total limit; this much silence mid-reply = broken
SLOW_REST = 600            # a model that was too slow or broke rests this long (seconds); saved in SQLite
QUOTA_REST = 6 * 3600      # a provider whose free credits are used up (error 402) rests this long
HTTP_SAFETY = 600.0        # the network library's own last-resort limit (only frees a stuck background thread)
MAX_TOKENS_CAP = 8000      # the most we ever ask for when a reply was cut off
RESUME_JOBS = {"answer", "report"}   # free-text jobs: after a break the next model CONTINUES the partial text
MIN_RESUME_CHARS = 120     # a partial reply shorter than this is not worth continuing: start again instead
CONTINUE_PROMPT = ("Your reply was interrupted. Continue it from exactly where it stopped. Do not repeat "
                   "anything already written, do not start over, and finish with a complete sentence.")

# What a model is assumed to be like before we have measured it: (seconds to start, tokens per second).
SPEED_PRIOR = {"groq": (1.0, 300.0), "nvidia": (5.0, 50.0), "openrouter": (3.0, 60.0)}

_cooldown_until = {}        # (provider, model) -> time until which we skip it (also saved in SQLite)
_rest_loaded_for = None     # which database file the saved rests were read from


class AllModelsBusy(Exception):
    """Every model in the ladder was skipped or failed."""


# ---------- SQLite: usage counter + cache ----------
def _db():
    global _rest_loaded_for
    folder = os.path.dirname(DB_PATH)
    if folder:
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS llm_usage "
                 "(ts REAL, provider TEXT, model TEXT, tokens INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS llm_cache "
                 "(key TEXT PRIMARY KEY, response TEXT, provider TEXT, model TEXT, created REAL)")
    conn.execute("CREATE TABLE IF NOT EXISTS llm_rest "
                 "(provider TEXT, model TEXT, until REAL, PRIMARY KEY (provider, model))")
    conn.execute("CREATE TABLE IF NOT EXISTS llm_speed "
                 "(ts REAL, provider TEXT, model TEXT, first_s REAL, total_s REAL, out_tokens INTEGER)")
    if _rest_loaded_for != DB_PATH:                    # first use in this run: remember earlier rests
        now = time.time()
        for provider, model, until in conn.execute("SELECT provider, model, until FROM llm_rest").fetchall():
            if until > now:
                _cooldown_until[(provider, model)] = max(until, _cooldown_until.get((provider, model), 0))
        _rest_loaded_for = DB_PATH
    return conn


def _rest(conn, provider, model, seconds):
    """Skip this model for `seconds`; saved so that restarting the app does not forget it."""
    until = time.time() + seconds
    _cooldown_until[(provider, model)] = until
    try:
        conn.execute("INSERT OR REPLACE INTO llm_rest VALUES (?,?,?)", (provider, model, until))
        conn.commit()
    except sqlite3.Error:
        pass


def _record_speed(conn, provider, model, first_s, total_s, text):
    try:
        conn.execute("INSERT INTO llm_speed VALUES (?,?,?,?,?,?)",
                     (time.time(), provider, model, first_s, total_s, max(1, len(text) // 4)))
        conn.commit()
    except sqlite3.Error:
        pass


def _speed_of(conn, provider, model):
    """(seconds to start, tokens per second): measured medians of the last 15 replies, else a prior."""
    rows = conn.execute("SELECT first_s, total_s, out_tokens FROM llm_speed WHERE provider=? AND model=? "
                        "ORDER BY ts DESC LIMIT 15", (provider, model)).fetchall()
    if len(rows) >= 2:
        firsts = sorted(r[0] for r in rows)
        rates = sorted(r[2] / max(0.2, r[1] - r[0]) for r in rows)
        return firsts[len(firsts) // 2], rates[len(rates) // 2]
    return SPEED_PRIOR.get(provider, (5.0, 50.0))


def _expected_seconds(conn, pair, out_tokens=500):
    first, rate = _speed_of(conn, *pair)
    return first + out_tokens / max(rate, 1.0)


def _fastest_first(conn, pairs, out_tokens=500):
    """Used after a break in the middle of a reply: the quickest models go first (stable for ties)."""
    return sorted(pairs, key=lambda pair: _expected_seconds(conn, pair, out_tokens))


def _used(conn, provider, model, seconds):
    """(tokens, requests) used in the last `seconds`. model=None = whole provider."""
    since = time.time() - seconds
    if model is None:
        row = conn.execute("SELECT COALESCE(SUM(tokens), 0), COUNT(*) FROM llm_usage "
                           "WHERE provider=? AND ts>?", (provider, since)).fetchone()
    else:
        row = conn.execute("SELECT COALESCE(SUM(tokens), 0), COUNT(*) FROM llm_usage "
                           "WHERE provider=? AND model=? AND ts>?",
                           (provider, model, since)).fetchone()
    return row[0], row[1]


def _room(conn, provider, model, est_tokens):
    """Return (True, '') if the call fits our limits, else (False, reason)."""
    lim = LIMITS.get((provider, model))
    if lim:
        if est_tokens > lim["tpm"]:
            return False, f"request too large for one minute's budget (~{est_tokens} tokens)"
        t_min, r_min = _used(conn, provider, model, 60)
        t_day, r_day = _used(conn, provider, model, 86400)
        if r_min + 1 > lim["rpm"] or t_min + est_tokens > lim["tpm"]:
            return False, "per-minute limit would be exceeded"
        if r_day + 1 > lim["rpd"] or t_day + est_tokens > lim["tpd"]:
            return False, "daily limit would be exceeded"
    plim = PROVIDER_LIMITS.get(provider)
    if plim:
        _, r_min = _used(conn, provider, None, 60)
        _, r_day = _used(conn, provider, None, 86400)
        if "rpm" in plim and r_min + 1 > plim["rpm"]:
            return False, f"{provider} per-minute request limit would be exceeded"
        if "rpd" in plim and r_day + 1 > plim["rpd"]:
            return False, f"{provider} daily request limit would be exceeded"
    return True, ""


def all_models():
    """Every (provider, model) pair, once, grouped by provider (for the app)."""
    seen, out = set(), []
    for pairs in (_pairs("nvidia", NVIDIA_MODELS), _pairs("groq", GROQ_MODELS),
                  _pairs("openrouter", OPENROUTER_MODELS), _pairs("huggingface", HF_MODELS)):
        for pair in pairs:
            if pair not in seen:
                seen.add(pair)
                out.append(pair)
    return out


def usage_summary():
    """Rows for the app: what has been used in the last minute and 24 hours."""
    conn = _db()
    rows = []
    for provider, model in all_models():
        if "paste-" in model:
            continue
        lim, plim = LIMITS.get((provider, model)), PROVIDER_LIMITS.get(provider)
        t_min, r_min = _used(conn, provider, model, 60)
        t_day, r_day = _used(conn, provider, model, 86400)
        note = ""
        if plim:
            note = "  (provider caps: " + ", ".join(f"{k} {v}" for k, v in plim.items()) + ")"
        rows.append({
            "provider": provider, "model": model,
            "tokens last minute": f"{t_min} / {lim['tpm']}" if lim else str(t_min),
            "tokens last 24h": f"{t_day} / {lim['tpd']}" if lim else str(t_day),
            "requests last 24h": (f"{r_day} / {lim['rpd']}" if lim else str(r_day)) + note,
        })
    conn.close()
    return rows


# ---------- calling a model ----------
def _api_key(provider):
    cfg = PROVIDERS[provider]
    key = cfg.get("key") or os.getenv(cfg.get("key_env", ""), "")
    if not key and provider == "huggingface":
        key = os.getenv("HUGGINGFACE_HUB_TOKEN", "")        # the other name Hugging Face tools use
    return key


def _get_client(provider, timeout=None):
    from openai import OpenAI
    cfg = PROVIDERS[provider]
    # max_retries=0: if a model is rate-limited we move on instead of silently retrying and wasting the
    # free budget. The 60-second rules are enforced by ask() itself (see _stream_reply); the library's
    # own limit is only a last-resort safety net that frees a stuck background thread.
    return OpenAI(base_url=cfg["base_url"], api_key=_api_key(provider),
                  timeout=timeout or HTTP_SAFETY, max_retries=0)


LADDER_FILE = os.path.join("data", "ladders.json")


def ladder_for(job):
    """The ladder for a job: the order saved by the Model check tab if there is one, else the lists above."""
    try:
        with open(LADDER_FILE, encoding="utf-8") as f:
            saved = json.load(f).get(job)
        if saved:
            known = {pair for pairs in LADDERS.values() for pair in pairs}
            order = [tuple(x) for x in saved if tuple(x) in known]
            order += [pair for pair in LADDERS[job] if pair not in order]      # models added since
            return order
    except (OSError, ValueError, AttributeError):
        pass
    return LADDERS[job]


def _avoid_set(avoid_family):
    if not avoid_family:
        return set()
    if isinstance(avoid_family, str):
        return {avoid_family}
    return {f for f in avoid_family if f}


def image_message(prompt, images):
    """A user message with text and pictures. images = list of PNG/JPEG bytes."""
    parts = [{"type": "text", "text": prompt}]
    for raw in images:
        kind = "jpeg" if raw[:3] == b"\xff\xd8\xff" else "png"
        parts.append({"type": "image_url",
                      "image_url": {"url": f"data:image/{kind};base64," + base64.b64encode(raw).decode()}})
    return {"role": "user", "content": parts}


def _estimate(messages, max_tokens):
    total = 0
    for m in messages:
        c = m["content"]
        if isinstance(c, str):
            total += len(c) // 4
        else:
            for part in c:
                total += len(part.get("text", "")) // 4 if part.get("type") == "text" else 1500
    return total + max_tokens


class StartTimeout(Exception):
    """The model did not start answering within START_WAIT seconds."""


class SilenceTimeout(Exception):
    """The model started answering, then went silent for SILENCE_LIMIT seconds."""


class _Broke(Exception):
    """A model failed AFTER it had started replying. Keeps what it had written so far."""
    def __init__(self, cause, partial, first_s):
        super().__init__(type(cause).__name__)
        self.cause, self.partial, self.first_s = cause, partial, first_s


def _close(resp):
    for target in (resp, getattr(resp, "response", None)):
        try:
            target.close()
            return
        except Exception:
            continue


def _stream_reply(client, kwargs):
    """
    Ask for a reply in pieces and watch the clock: START_WAIT seconds to begin, then SILENCE_LIMIT
    seconds of silence at most between pieces; the whole reply has no time limit.
    Returns {'text', 'finish', 'used', 'first_s', 'seconds'}.
    Raises StartTimeout, or another error, if nothing had started; _Broke (with the partial text) if
    the model failed after starting.
    """
    pieces = queue.Queue()
    stop = threading.Event()
    holder = {}

    def pump():
        try:
            resp = client.chat.completions.create(stream=True, **kwargs)
            holder["resp"] = resp
            if hasattr(resp, "choices"):                       # a whole reply object, not a stream
                choice = resp.choices[0]
                pieces.put(("text", choice.message.content or ""))
                pieces.put(("end", getattr(choice, "finish_reason", None),
                            getattr(getattr(resp, "usage", None), "total_tokens", None)))
                return
            finish, used = None, None
            for chunk in resp:
                if stop.is_set():
                    return
                usage = getattr(chunk, "usage", None)
                if usage is not None and getattr(usage, "total_tokens", None):
                    used = usage.total_tokens
                choices = getattr(chunk, "choices", None) or []
                if not choices:
                    pieces.put(("beat", ""))                   # alive, nothing to show
                    continue
                choice = choices[0]
                if getattr(choice, "finish_reason", None):
                    finish = choice.finish_reason
                text = getattr(getattr(choice, "delta", None), "content", None) or ""
                pieces.put(("text", text) if text else ("beat", ""))    # thinking pieces count as alive
            pieces.put(("end", finish, used))
        except BaseException as e:                              # reported to the waiting side
            pieces.put(("error", e))

    began = time.time()
    threading.Thread(target=pump, daemon=True).start()
    parts, first_s = [], None
    while True:
        try:
            item = pieces.get(timeout=START_WAIT if first_s is None else SILENCE_LIMIT)
        except queue.Empty:
            stop.set()
            _close(holder.get("resp"))
            if first_s is None:
                raise StartTimeout(f"nothing started within {int(START_WAIT)}s")
            raise _Broke(SilenceTimeout(f"silent for {int(SILENCE_LIMIT)}s"), "".join(parts), first_s)
        if item[0] == "error":
            if first_s is None:
                raise item[1]
            raise _Broke(item[1], "".join(parts), first_s)
        if first_s is None:
            first_s = time.time() - began
        if item[0] == "text":
            parts.append(item[1])
        elif item[0] == "end":
            return {"text": "".join(parts), "finish": item[1], "used": item[2],
                    "first_s": first_s, "seconds": time.time() - began}


def _call(client, kwargs):
    """One streamed call; a model without JSON mode (error 400) is asked again without it."""
    try:
        return _stream_reply(client, kwargs)
    except Exception as e:
        if "response_format" in kwargs and getattr(e, "status_code", None) == 400:
            return _stream_reply(client, {k: v for k, v in kwargs.items() if k != "response_format"})
        raise


def _trim_tail(text):
    """Drop a half-written last word, so that a continuation starts cleanly."""
    if text and text[-1].isalnum():
        cut = max(text.rfind(" "), text.rfind("\n"))
        if cut > 0:
            return text[:cut + 1]
    return text


def _join(first, second):
    """first + second, without repeating words the second model wrote again at its start."""
    if not first:
        return second.strip()
    second = second.strip()
    if not second:
        return first
    tail = first[-200:]
    for n in range(min(len(tail), len(second)), 14, -1):
        if tail.endswith(second[:n]):
            second = second[n:].lstrip()
            break
    glue = "" if first.endswith((" ", "\n")) or second[:1] in ".,;:!?)" else " "
    return first + glue + second


def ask(job, messages, max_tokens=1500, use_cache=True, ladder=None,
        json_mode=False, avoid_family=None, timeout=None, resume=None, _client=None):
    """
    Return {'text', 'provider', 'model', 'tokens', 'seconds', 'first_seconds', 'cached', 'truncated',
            'handovers', 'attempts'}.
    Models are tried best first. The time rules are the same for all (see the top of this file);
    `timeout` is still accepted so older callers keep working, but it is ignored.
    resume=True: after a break, the next model continues the partial text (default for free-text jobs).
    """
    ladder = list(ladder or ladder_for(job))
    resume = (job in RESUME_JOBS) if resume is None else resume
    avoid = _avoid_set(avoid_family)
    key = hashlib.sha256(json.dumps([job, messages, json_mode, max_tokens, sorted(avoid)],
                                    sort_keys=True).encode()).hexdigest()
    conn = _db()
    try:
        if use_cache:
            hit = conn.execute("SELECT response, provider, model FROM llm_cache WHERE key=?",
                               (key,)).fetchone()
            if hit:
                return {"text": hit[0], "provider": hit[1], "model": hit[2], "tokens": 0,
                        "seconds": 0.0, "first_seconds": 0.0, "cached": True, "truncated": False,
                        "handovers": 0, "attempts": ["cache hit"]}

        attempts, truncated_best = [], None
        partial = ""                       # what a model wrote before it broke (free-text jobs)
        handovers = 0
        pending = list(ladder)
        while pending:
            provider, model = pending.pop(0)
            label = f"{provider}/{model}"
            if "paste-" in model:
                attempts.append(f"{label}: skipped (model id not set)")
                continue
            if family(model) in avoid:
                attempts.append(f"{label}: skipped (same family as another role)")
                continue
            if _client is None and not _api_key(provider):
                attempts.append(f"{label}: skipped (no API key in .env)")
                continue
            wait = _cooldown_until.get((provider, model), 0) - time.time()
            if wait > 0:
                attempts.append(f"{label}: skipped (resting {int(wait)}s)")
                continue

            continuing = bool(partial) and resume          # same conversation + what is already written
            send = (messages + [{"role": "assistant", "content": partial},
                                {"role": "user", "content": CONTINUE_PROMPT}]) if continuing else messages
            limit_now = max_tokens
            for round_no in range(2):                      # second round only if the first was cut off
                est = _estimate(send, limit_now)
                ok, why = _room(conn, provider, model, est)
                if not ok:
                    attempts.append(f"{label}: skipped ({why})")
                    break
                try:
                    client = _client(provider) if _client else _get_client(provider)
                    kwargs = dict(model=model, messages=send, max_tokens=limit_now, temperature=0.2)
                    if json_mode:
                        kwargs["response_format"] = {"type": "json_object"}
                    res = _call(client, kwargs)
                    text = res["text"].strip()
                    used = res["used"] or (est - limit_now + max(1, len(text) // 4))
                    conn.execute("INSERT INTO llm_usage VALUES (?,?,?,?)", (time.time(), provider, model, used))
                    conn.commit()
                    full = _join(partial, text) if continuing else text
                    cut = res["finish"] == "length"
                    if not text:
                        attempts.append(f"{label}: empty reply (thinking may have used all tokens)")
                        cut = True                          # same remedy: more room
                    if cut:
                        attempts.append(f"{label}: cut off at {limit_now} tokens")
                        if text and truncated_best is None:
                            truncated_best = {"text": full, "provider": provider, "model": model,
                                              "tokens": used, "seconds": round(res["seconds"], 2),
                                              "first_seconds": round(res["first_s"], 2)}
                        bigger = min(MAX_TOKENS_CAP, int(limit_now * 1.8))
                        if round_no == 0 and bigger > limit_now:
                            limit_now = bigger              # same model again, with more room
                            continue
                        break                               # next model
                    _record_speed(conn, provider, model, res["first_s"], res["seconds"], text)
                    conn.execute("INSERT OR REPLACE INTO llm_cache VALUES (?,?,?,?,?)",
                                 (key, full, provider, model, time.time()))
                    conn.commit()
                    attempts.append(f"{label}: ok" + (" (continued the earlier text)" if continuing else ""))
                    return {"text": full, "provider": provider, "model": model, "tokens": used,
                            "seconds": round(res["seconds"], 2), "first_seconds": round(res["first_s"], 2),
                            "cached": False, "truncated": False, "handovers": handovers,
                            "attempts": attempts}
                except _Broke as b:                         # it had started, then failed: HAND OVER at once
                    _rest(conn, provider, model, SLOW_REST)
                    code = getattr(b.cause, "status_code", None)
                    attempts.append(f"{label}: broke mid-reply after {b.first_s:.1f}s to start "
                                    f"({'silent' if isinstance(b.cause, SilenceTimeout) else code or type(b.cause).__name__})"
                                    f", handed over")
                    handovers += 1
                    got = _trim_tail(_join(partial, b.partial)) if continuing else _trim_tail(b.partial)
                    if resume and len(got) >= MIN_RESUME_CHARS:
                        partial = got                       # the next model continues from here
                    elif not resume:
                        partial = ""                        # strict format: start the same task again
                    if len(got) >= MIN_RESUME_CHARS and truncated_best is None:
                        truncated_best = {"text": got, "provider": provider, "model": model, "tokens": 0,
                                          "seconds": 0.0, "first_seconds": round(b.first_s, 2)}
                    pending = _fastest_first(conn, pending)  # quickest models take over first
                    break
                except Exception as e:
                    code = getattr(e, "status_code", None)
                    if code == 429:
                        _rest(conn, provider, model, 60)
                    elif code == 402:                       # the provider's free credits are used up: rest all its models
                        for p, m in all_models():
                            if p == provider:
                                _rest(conn, p, m, QUOTA_REST)
                    elif code in (401, 403, 404):           # wrong id or bad key: stop retrying
                        _rest(conn, provider, model, 3600)
                    elif isinstance(e, StartTimeout) or (code is None and "Timeout" in type(e).__name__):
                        _rest(conn, provider, model, SLOW_REST)         # too slow to start
                    label_why = ("no reply within %ds" % START_WAIT if isinstance(e, StartTimeout)
                                 else "rate limit" if code == 429 else "credits used up (402)" if code == 402
                                 else code or type(e).__name__)
                    attempts.append(f"{label}: failed ({label_why})")
                    break
        if truncated_best:                       # only when every model failed to give a complete reply
            return {**truncated_best, "cached": False, "truncated": True, "handovers": handovers,
                    "attempts": attempts}
        raise AllModelsBusy("No model could answer right now. " + " | ".join(attempts))
    finally:
        conn.close()


def rerank_api(query, documents, top_n=None, model=None, _post=None):
    """
    Rank passages with a real rerank model through OpenRouter's rerank endpoint (a cross-encoder: it
    reads the question and each passage together). Returns [(index, score), ...] best first.
    Raises AllModelsBusy if it cannot be used right now (no key, resting, over the free budget, error).
    The same 60-second start rule applies (a rerank reply comes in one piece).
    """
    model = model or RERANK_MODEL
    provider = "openrouter"
    if _post is None and not _api_key(provider):
        raise AllModelsBusy("rerank: no OpenRouter key in .env")
    if not documents:
        return []
    conn = _db()
    try:
        wait = _cooldown_until.get((provider, model), 0) - time.time()
        if wait > 0:
            raise AllModelsBusy(f"rerank: resting {int(wait)}s")
        ok, why = _room(conn, provider, model, 1500)
        if not ok:
            raise AllModelsBusy(f"rerank: {why}")
        body = {"model": model, "query": query, "documents": list(documents)}
        if top_n:
            body["top_n"] = int(top_n)
        try:
            data = (_post or _http_post)(RERANK_URL, {"Authorization": "Bearer " + _api_key(provider),
                                                      "Content-Type": "application/json"}, body, START_WAIT)
            conn.execute("INSERT INTO llm_usage VALUES (?,?,?,?)", (time.time(), provider, model, 1500))
            conn.commit()
            ranked = []
            for r in data.get("results", []):
                idx = r.get("index")
                score = r.get("relevance_score", r.get("score"))
                if isinstance(idx, int) and 0 <= idx < len(documents) and score is not None:
                    ranked.append((idx, float(score)))
            if not ranked:
                raise ValueError("no usable results")
            ranked.sort(key=lambda t: -t[1])
            return ranked
        except AllModelsBusy:
            raise
        except Exception as e:
            code = getattr(e, "status_code", None) or getattr(e, "code", None)
            if code in (429, 402):
                _rest(conn, provider, model, 60)
            elif code in (401, 403, 404):
                _rest(conn, provider, model, 3600)
            else:
                _rest(conn, provider, model, SLOW_REST if "imeout" in type(e).__name__ else 120)
            raise AllModelsBusy(f"rerank failed ({code or type(e).__name__})")
    finally:
        conn.close()


def _http_post(url, headers, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def ask_vision(prompt, images, system=None, max_tokens=1200, avoid_family=None, use_cache=True):
    """Ask a vision model about one or more pictures (bytes). Same return value as ask()."""
    messages = ([{"role": "system", "content": system}] if system else []) + [image_message(prompt, images)]
    return ask("vision", messages, max_tokens=max_tokens, avoid_family=avoid_family, use_cache=use_cache)


def parse_labeled_lines(text):
    """
    Read free text written in a simple template, for example:
        Concepts: molality; molarity; solute
        Prerequisites: mole concept; concentration
    and return {'concepts': [...], 'prerequisites': [...]}.
    """
    result = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        label, _, rest = line.partition(":")
        label = re.sub(r"[^a-z ]", "", label.lower()).strip()
        items = [i.strip(" -*.") for i in re.split(r"[;\n]", rest) if i.strip(" -*.")]
        if label and items:
            result[label] = items
    return result
