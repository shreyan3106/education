"""
Formatting of model text: one place that makes math show up properly.

  clean(text)    code only: turns \\( .. \\) and \\[ .. \\] into $ .. $ and $$ .. $$, removes stray
                 \\text{} wrappers around plain words, fixes spacing inside dollar signs.
  broken(text)   True when the text still looks wrong: math commands or ^ and _ outside dollar signs,
                 or an odd number of dollar signs.
  repair(text)   a model rewrites ONLY the formatting (never the content) when broken() says so.
  tidy(text)     clean(), then repair() if still broken. Returns the text to show or save.
  bullets(items) a list of points as a Markdown bullet list, each one tidied.
"""
import re

from src import llm

REPAIR_SYSTEM = """You fix the FORMATTING of study text. Do not change, add or remove any meaning, number, citation like [1], or word.
Rules: every formula or symbol with subscripts, superscripts, fractions or Greek letters goes in LaTeX between single dollar signs, like $y = \\frac{a}{b}$ or $r_{13}$; important equations may stand alone between double dollar signs. Plain words stay outside dollar signs. Never use \\( \\) or \\[ \\]. Keep line breaks and list markers.
Reply with ONLY the fixed text."""

_COMMAND = re.compile(r"\\(?:mathbf|mathrm|frac|vec|hat|sqrt|cdot|times|epsilon|pi|Delta|sum|int|text|nabla|rho|sigma|lambda|theta|phi|omega|alpha|beta|mu)\b")


def clean(text):
    text = text or ""
    text = re.sub(r"\\\[(.+?)\\\]", lambda m: f"$${m.group(1).strip()}$$", text, flags=re.S)
    text = re.sub(r"\\\((.+?)\\\)", lambda m: f"${m.group(1).strip()}$", text, flags=re.S)
    text = re.sub(r"(?<![$\\])\$(?!\$)([^$\n]+?)\$(?!\$)", lambda m: ("$" + m.group(1).strip() + "$") if re.search(r"[=\\^_{}]", m.group(1)) else m.group(0), text)   # "$ F = k $" -> "$F = k$"; "$5 and $6" is left alone
    return text


def _outside_math(text):
    """The parts of the text that are not between dollar signs."""
    parts = re.split(r"\$\$.+?\$\$|\$[^$\n]+?\$", text, flags=re.S)
    return " ".join(parts)


def broken(text):
    text = text or ""
    if text.count("$") % 2:
        return True
    outside = _outside_math(text)
    if _COMMAND.search(outside):
        return True
    if re.search(r"[A-Za-z]\^[\w{(-]|[A-Za-z]_[\w{]", outside):                    # x^2 or q_1 written as plain text
        return True
    return False


def repair(text):
    """Ask a model to fix the formatting only. Falls back to the cleaned text if no model answers or it changed too much."""
    try:
        r = llm.ask("format", [{"role": "system", "content": REPAIR_SYSTEM}, {"role": "user", "content": text}],
                    max_tokens=min(4000, max(400, len(text) // 2 + 300)))
    except llm.AllModelsBusy:
        return text
    fixed = clean(r["text"])
    if r.get("truncated") or not fixed:
        return text
    # a formatting fix may add dollar signs and braces but must keep the words and the citations
    words = lambda t: re.findall(r"[A-Za-z]{4,}|\[\d+\]", re.sub(r"\\[A-Za-z]+", " ", t))
    old, new = words(text), words(fixed)
    if old and len(set(old) - set(new)) > max(2, len(set(old)) // 10):
        return text
    return fixed


def tidy(text, use_model=True):
    text = clean(text)
    if use_model and broken(text):
        text = repair(text)
    return text


def bullets(items, use_model=False):
    """Markdown bullet list of points; math is cleaned (no model call: this runs on every screen refresh)."""
    return "\n".join(f"- {tidy(i, use_model)}" for i in items if i and i.strip())
