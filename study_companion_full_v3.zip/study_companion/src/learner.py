"""
Learner model: how well does the student know each topic, and what should they do next?

Three methods work together, each with its own job (nothing is stored except the event log, so every
number below is recomputed from the log: no drift, easy to replay, easy to simulate):

  1. BKT  (Bayesian Knowledge Tracing)  MAIN estimate. P(student knows the topic). After every answer it
          weighs the evidence with a guess chance (a lucky MCQ guess) and a slip chance (a careless
          mistake), then allows for learning. Works from the very first answer.
  2. IRT  (item-response style ability)  SUPPORT. An ability score (theta) on the same scale as question
          difficulty (easy -1, medium 0, hard +1), found by maximum-a-posteriori estimation over the recent
          answers. It gives a second opinion on mastery once there are several answers, a confidence
          (standard error), and the difficulty to aim the next questions at (about 70 percent success).
  3. SR   (spaced repetition)  SUPPORT. A memory-stability value per topic (in days) that grows when the
          student answers correctly after a gap and shrinks after a mistake. The forgetting curve
          exp(-days / stability) lowers mastery over time and says when a topic is due for review.

  mastery = (BKT blended with IRT as evidence grows, pulled toward the starting level while there are
            few answers)  x  (0.6 + 0.4 x retrievability)

FALLBACKS: with fewer than 2 scored answers the IRT part has weight 0 (BKT alone); if IRT cannot be
computed it is skipped; without timestamps nothing decays. The result says which methods were used.

EVIDENCE: ONLY scored answers move the mastery number: topic quizzes, mock exams and the diagnostic quiz all
count, each question once. Asking the tutor about a topic is NOT a result: it is counted separately and only
used as a hint ("you asked about this") when suggesting what to study.
NEW STUDENTS: a 3-tap intake sets the prior; a diagnostic quiz (1 question per topic) does the rest.

Every function takes `student` and an optional `now` (seconds), so the simulated students in the
evaluation can fast-forward days without waiting.
"""
import math
import re
import sqlite3
import time
import threading
from datetime import date, datetime

from src import outline, store

DEFAULT_STUDENT = "default"
DAY = 86400.0

# Every course has its own learner record. The app sets "the current student" at the start of every run (it is the
# course the student picked); every function below that takes student=None uses it. Kept per thread, so two
# browser tabs on two courses cannot mix their progress.
_active = threading.local()


def set_current_student(student):
    _active.student = student or DEFAULT_STUDENT


def current_student():
    return getattr(_active, "student", DEFAULT_STUDENT)


def _s(student):
    return student or current_student()

# ---- BKT settings ----
LEVEL_PRIOR = {"beginner": 0.15, "some": 0.30, "advanced": 0.50}      # P(knows a topic) before any evidence
NO_INTAKE_PRIOR = 0.25
LEARN_QUIZ = 0.06              # chance of learning something from answering one question (0.15 over-rated weak students in simulation)
LEARN_TUTOR = 0.03             # ... from reading a tutor explanation
TUTOR_DOUBT = 0.25             # weight of "they had to ask" as a wrong answer
GUESS = {"mcq": 0.25, "short": 0.10, "numerical": 0.05}
SLIP = {"easy": 0.05, "medium": 0.10, "hard": 0.18}
P_MIN, P_MAX = 0.02, 0.98

# ---- IRT settings ----
DIFFICULTY_B = {"easy": -1.0, "medium": 0.0, "hard": 1.0}
THETA_PRIOR_SD = 1.5
RECENCY = 0.92                 # an answer counts 8 percent less for every newer answer after it
TARGET_SUCCESS = 0.70          # aim questions so the student succeeds about this often

# ---- spaced repetition settings ----
S_FIRST = 2.0                  # days of memory after the first exposure
S_MAX = 180.0
SAME_SESSION_DAYS = 0.25       # answers closer than this are one study session: no big stability jump
RETENTION_TARGET = 0.70        # a topic is due when recall would fall to this
DECAY_FLOOR = 0.6              # forgetting can remove at most 40 percent of what was learned

EVIDENCE_PRIOR = 1.5           # the starting level counts like this many answers: one answer never looks like certainty
MIN_EVIDENCE = 3               # fewer scored answers than this = "too early to call" a topic weak or strong
MIN_REVIEW_GAP = 0.5           # days: a review is never due sooner than 12 hours after the last answer

WEAK_BELOW = 0.5
STRONG_ABOVE = 0.75


# =====================================================================
# 1. Storage: an event log and a small profile
# =====================================================================
_SCHEMA = """
CREATE TABLE IF NOT EXISTS learner_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, student TEXT, topic TEXT, source TEXT, score REAL,
    difficulty TEXT, qtype TEXT, question_id INTEGER, ts REAL);
CREATE UNIQUE INDEX IF NOT EXISTS learner_events_q ON learner_events(student, question_id);
CREATE TABLE IF NOT EXISTS learner_profile (
    student TEXT PRIMARY KEY, level TEXT, goal TEXT, exam_date TEXT, created REAL);
CREATE TABLE IF NOT EXISTS learner_reset (student TEXT PRIMARY KEY, ts REAL);
CREATE TABLE IF NOT EXISTS tutor_questions (student TEXT, ts REAL, question TEXT, topics TEXT);
"""


def _conn():
    conn = sqlite3.connect(store.DB_PATH)
    conn.executescript(_SCHEMA)
    return conn


def _now(now):
    return time.time() if now is None else now


def set_profile(student, level, goal=None, exam_date=None, now=None):
    """Save the intake: level ('beginner' | 'some' | 'advanced'), goal (free text), exam date ('YYYY-MM-DD')."""
    level = level if level in LEVEL_PRIOR else "some"
    conn = _conn()
    conn.execute("INSERT OR REPLACE INTO learner_profile VALUES (?,?,?,?,?)",
                 (student, level, goal or "", exam_date or "", _now(now)))
    conn.commit()
    conn.close()


def record_tutor_question(student, question, topics, now=None):
    """Keep what the student asked the tutor, in their own words (the coach uses it to personalise)."""
    text = " ".join((question or "").split())[:300]
    if not text:
        return
    import json
    conn = _conn()
    conn.execute("INSERT INTO tutor_questions VALUES (?,?,?,?)",
                 (student, _now(now), text, json.dumps(list(dict.fromkeys(topics or [])))))
    conn.commit()
    conn.close()


def recent_tutor_questions(student=None, n=5):
    """The student's latest questions to the tutor, newest first: [{'ts', 'question', 'topics'}]."""
    import json
    student = _s(student)
    conn = _conn()
    rows = conn.execute("SELECT ts, question, topics FROM tutor_questions WHERE student=? ORDER BY ts DESC LIMIT ?",
                        (student, n)).fetchall()
    cut = conn.execute("SELECT ts FROM learner_reset WHERE student=?", (student,)).fetchone()
    conn.close()
    if cut:
        rows = [r for r in rows if r[0] > cut[0]]
    return [{"ts": ts, "question": q, "topics": json.loads(t or "[]")} for ts, q, t in rows]


def get_profile(student=None):
    student = _s(student)
    conn = _conn()
    r = conn.execute("SELECT level, goal, exam_date, created FROM learner_profile WHERE student=?", (student,)).fetchone()
    conn.close()
    return {"level": r[0], "goal": r[1], "exam_date": r[2], "created": r[3]} if r else None


def event_count(student=None):
    student = _s(student)
    conn = _conn()
    n = conn.execute("SELECT COUNT(*) FROM learner_events WHERE student=? AND source != 'tutor'", (student,)).fetchone()[0]
    conn.close()
    return n


def needs_intake(student=None):
    """True for a brand-new student: no intake saved and no answers yet."""
    student = _s(student)
    return get_profile(student) is None and event_count(student) == 0


def record_answer(student, topic, score, difficulty, qtype, question_id=None, source="quiz", now=None):
    """Save one scored answer (score 0, 0.5 or 1). The same question is never counted twice."""
    if not topic:
        return False
    conn = _conn()
    try:
        conn.execute("INSERT INTO learner_events (student, topic, source, score, difficulty, qtype, question_id, ts) "
                     "VALUES (?,?,?,?,?,?,?,?)",
                     (student, topic, source, float(score), difficulty or "medium", qtype or "mcq",
                      question_id, _now(now)))
        conn.commit()
        added = True
    except sqlite3.IntegrityError:
        added = False
    conn.close()
    return added


def record_tutor(student, topics, now=None):
    """The student asked the tutor about these topics: light evidence."""
    conn = _conn()
    for t in dict.fromkeys(topics or []):
        conn.execute("INSERT INTO learner_events (student, topic, source, score, difficulty, qtype, question_id, ts) "
                     "VALUES (?,?,?,?,?,?,?,?)", (student, t, "tutor", None, None, None, None, _now(now)))
    conn.commit()
    conn.close()


def import_quiz_history(student=None, docs=None):
    """
    Count answers given before the learner model existed. Only questions of the given documents (the chosen
    course) whose topic is one of their current topics are used; the rest are ignored. Safe to call again and again.
    """
    student = _s(student)
    current = {t["topic"] for t in outline.topics(docs=docs)}
    conn = _conn()
    cut = conn.execute("SELECT ts FROM learner_reset WHERE student=?", (student,)).fetchone()
    cutoff = cut[0] if cut else 0.0                      # answers given before a reset are never brought back
    try:
        rows = conn.execute(
            "SELECT q.id, q.topic, q.difficulty, q.qtype, a.score, a.ts, s.kind FROM quiz_answers a "
            "JOIN quiz_questions q ON q.id = a.question_id JOIN quiz_sets s ON s.id = q.set_id"
            + (f" WHERE q.doc IN ({','.join('?' * len(docs))})" if docs else ""), list(docs or [])).fetchall()
    except sqlite3.OperationalError:
        conn.close()
        return 0
    conn.close()
    added = 0
    for qid, topic, diff, qtype, score, ts, kind in rows:
        if ts > cutoff and topic in current and record_answer(student, topic, score, diff, qtype, qid,
                                              "diagnostic" if kind == "diagnostic" else "quiz", ts):
            added += 1
    return added


def reset(student=None):
    student = _s(student)
    conn = _conn()
    conn.execute("DELETE FROM learner_events WHERE student=?", (student,))
    conn.execute("DELETE FROM learner_profile WHERE student=?", (student,))
    conn.execute("DELETE FROM tutor_questions WHERE student=?", (student,))
    conn.execute("INSERT OR REPLACE INTO learner_reset VALUES (?,?)", (student, time.time()))
    conn.commit()
    conn.close()


def _events(student, topic):
    conn = _conn()
    rows = conn.execute("SELECT source, score, difficulty, qtype, ts FROM learner_events "
                        "WHERE student=? AND topic=? ORDER BY ts, id", (student, topic)).fetchall()
    conn.close()
    return [{"source": r[0], "score": r[1], "difficulty": r[2], "qtype": r[3], "ts": r[4]} for r in rows]


# =====================================================================
# 2. The three methods (pure functions: easy to test and to simulate)
# =====================================================================
def prior_for(profile):
    return LEVEL_PRIOR.get((profile or {}).get("level"), NO_INTAKE_PRIOR)


def _clip(p):
    return min(P_MAX, max(P_MIN, p))


def bkt_update(p, score, qtype, difficulty, learn=LEARN_QUIZ):
    """One Bayesian Knowledge Tracing step. score in [0, 1] (0.5 = partly right)."""
    g, s = GUESS.get(qtype, 0.25), SLIP.get(difficulty, 0.10)
    if_right = p * (1 - s) / (p * (1 - s) + (1 - p) * g)
    if_wrong = p * s / (p * s + (1 - p) * (1 - g))
    posterior = score * if_right + (1 - score) * if_wrong
    return _clip(posterior + (1 - posterior) * learn)


def bkt_tutor(p):
    """A tutor question: a small doubt signal, then a small learning step."""
    doubted = (1 - TUTOR_DOUBT) * p + TUTOR_DOUBT * bkt_update(p, 0.0, "mcq", "medium", learn=0.0)
    return _clip(doubted + (1 - doubted) * LEARN_TUTOR)


def _sigmoid(x):
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, x))))


def _logit(p):
    p = min(0.999, max(0.001, p))
    return math.log(p / (1 - p))


def irt_theta(events, theta0):
    """
    Maximum-a-posteriori ability (theta) from scored answers, with a Normal prior around theta0.
    P(right) = guess + (1 - guess) * sigmoid(theta - difficulty). Newer answers count more.
    Returns (theta, standard_error). Raises ValueError if there is nothing to estimate from.
    """
    scored = [e for e in events if e["score"] is not None]
    if not scored:
        raise ValueError("no scored answers")
    n = len(scored)
    items = [(DIFFICULTY_B.get(e["difficulty"], 0.0), GUESS.get(e["qtype"], 0.25), e["score"],
              RECENCY ** (n - 1 - i)) for i, e in enumerate(scored)]
    theta = theta0
    for _ in range(30):
        grad, info = -(theta - theta0) / THETA_PRIOR_SD ** 2, 1 / THETA_PRIOR_SD ** 2
        for b, c, y, w in items:
            sig = _sigmoid(theta - b)
            p = c + (1 - c) * sig
            dp = (1 - c) * sig * (1 - sig)
            grad += w * (y - p) * dp / max(p * (1 - p), 1e-6)
            info += w * dp * dp / max(p * (1 - p), 1e-6)
        step = max(-1.0, min(1.0, grad / info))
        theta = max(-4.0, min(4.0, theta + step))
        if abs(step) < 1e-4:
            break
    return theta, 1 / math.sqrt(info)


def sr_step(stability, last_ts, ts, score, difficulty):
    """
    One spaced-repetition step. Returns the new stability in days.
    Right after a gap: grows a lot (more if the topic had been partly forgotten); partly right: a little;
    wrong: shrinks. Answers within one study session barely move it.
    """
    if stability is None:
        stability = S_FIRST
        gap = None
    else:
        gap = max(0.0, (ts - last_ts) / DAY)
    level = {"easy": 0, "medium": 1, "hard": 2}.get(difficulty, 1)
    if score >= 0.75:
        if gap is None:
            return min(S_MAX, S_FIRST * (1.3 + 0.0) * (1 + 0.15 * level))
        if gap < SAME_SESSION_DAYS:
            return min(S_MAX, stability * 1.05)
        recall = math.exp(-gap / stability)
        return min(S_MAX, stability * (1.3 + 1.2 * (1 - recall)) * (1 + 0.15 * level))
    if score >= 0.4:
        return min(S_MAX, stability * 1.1)
    return max(0.5, stability * 0.4)


def retrievability(stability, last_ts, now):
    if stability is None or last_ts is None:
        return 1.0
    return math.exp(-max(0.0, now - last_ts) / DAY / stability)


def days_until_due(stability, last_ts, now):
    """Days from now until recall falls to RETENTION_TARGET (negative = already overdue)."""
    if stability is None or last_ts is None:
        return None
    due_after = max(MIN_REVIEW_GAP, stability * math.log(1 / RETENTION_TARGET))
    return due_after - (now - last_ts) / DAY


def due_phrase(days):
    """The review date in plain words: 'in about 5 hours', 'tomorrow', 'in 3 days', 'overdue by 2 days'."""
    if days is None:
        return "-"
    if days <= -1:
        return f"overdue by {round(-days)} days"
    if days <= 0:
        return "due now"
    hours = days * 24
    if hours < 1:
        return "within the hour"
    if hours < 20:
        return f"in about {round(hours)} hours"
    if days < 1.5:
        return "tomorrow"
    return f"in {round(days)} days"


def replay(events, p0, now):
    """Run the three methods over a topic's event log. Returns the raw numbers."""
    p, stability, last_ts = p0, None, None
    scored = [e for e in events if e["score"] is not None]
    for e in events:
        if e["score"] is None:                               # a tutor question: counted below, but NOT a result
            continue
        p = bkt_update(p, e["score"], e["qtype"], e["difficulty"])
        stability = sr_step(stability, last_ts, e["ts"], e["score"], e["difficulty"])
        last_ts = e["ts"]
    theta, se, irt_ok = None, None, False
    if len(scored) >= 2:
        try:
            theta, se = irt_theta(events, _logit(p0))
            irt_ok = True
        except (ValueError, ZeroDivisionError, OverflowError):
            irt_ok = False
    return {"p_bkt": p, "stability": stability, "last_ts": last_ts, "theta": theta, "se": se,
            "irt_ok": irt_ok, "n": len(scored), "n_tutor": len(events) - len(scored)}


# =====================================================================
# 3. Mastery per topic
# =====================================================================
def topic_state(student, topic, now=None, profile=None, events=None):
    now = _now(now)
    profile = get_profile(student) if profile is None else profile
    p0 = prior_for(profile)
    events = _events(student, topic) if events is None else events
    raw = replay(events, p0, now)
    methods = ["bkt"]
    knowledge = raw["p_bkt"]
    if raw["irt_ok"]:
        w = 0.4 * min(1.0, raw["n"] / 6.0)                   # the IRT second opinion grows with the evidence
        knowledge = (1 - w) * raw["p_bkt"] + w * _sigmoid(raw["theta"])
        methods.append("irt")
    n = raw["n"]
    knowledge = p0 + (knowledge - p0) * (n / (n + EVIDENCE_PRIOR))     # few answers: stay near the starting level
    scored = [e for e in events if e["score"] is not None]
    right = sum(e["score"] for e in scored)
    recent_wrong = sum(1 for e in scored[-5:] if e["score"] < 0.5)
    recall = retrievability(raw["stability"], raw["last_ts"], now)
    if raw["stability"] is not None:
        methods.append("sr")
    mastery = _clip(knowledge * (DECAY_FLOOR + (1 - DECAY_FLOOR) * recall))
    half = 0.45 / math.sqrt(n + EVIDENCE_PRIOR) + 0.14        # how far the true level may be: measured on simulated students (about 8 in 10 inside)
    confidence = "none" if n == 0 else "low" if n < 3 else "medium" if n < 6 else "high"
    due = days_until_due(raw["stability"], raw["last_ts"], now)
    return {"topic": topic, "mastery": round(mastery, 3), "knowledge": round(knowledge, 3),
            "low": round(max(0.0, mastery - half), 3), "high": round(min(1.0, mastery + half), 3),
            "n_right": round(right, 1), "recent_wrong": recent_wrong,
            "evidence": f"{right:g} of {n} right" if n else "no answers",
            "p_bkt": round(raw["p_bkt"], 3), "theta": None if raw["theta"] is None else round(raw["theta"], 2),
            "se": None if raw["se"] is None else round(raw["se"], 2),
            "stability_days": None if raw["stability"] is None else round(raw["stability"], 1),
            "retrievability": round(recall, 3), "due_in_days": None if due is None else round(due, 1),
            "last_seen": raw["last_ts"], "n_answers": n, "n_tutor": raw["n_tutor"], "confidence": confidence,
            "assessed": n > 0, "methods": "+".join(methods)}


def all_states(student=None, now=None, docs=None):
    """One state per CURRENT topic of the uploaded material, in book order (older topic names are ignored).
    docs = only the topics of these documents (the chosen course)."""
    student = _s(student)
    profile = get_profile(student)
    now = _now(now)
    out = []
    kinds = store.doc_types()
    for t in outline.topics(docs):
        s = topic_state(student, t["topic"], now, profile)
        where = store.loc_label(kinds.get(t["doc"], "pdf"), t["page_start"], t["page_end"])
        s.update({"doc": t["doc"], "where": where, "pages": where.split(" ", 1)[1] if " " in where else where,
                  "concepts": "; ".join(t["concepts"])})
        out.append(s)
    return out


# =====================================================================
# 4. Prerequisites between topics (from the course's own tags)
# =====================================================================
def _norm(text):
    return re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).strip()


def prerequisite_map():
    """
    {topic: [earlier topics it builds on]}. A topic builds on an EARLIER topic when one of its prerequisite
    tags (written by the tagging step) is mentioned in the earlier topic's name or key concepts.
    """
    topics = outline.topics()
    conn = _conn()
    try:
        prereq = {r[0]: r[1] for r in conn.execute("SELECT unit_id, prerequisites FROM unit_tags")}
    except sqlite3.OperationalError:
        prereq = {}
    conn.close()
    texts = [_norm(t["topic"] + " " + " ".join(t["concepts"])) for t in topics]
    result = {}
    for i, t in enumerate(topics):
        wanted = {_norm(p) for uid in t["unit_ids"] for p in (prereq.get(uid) or "").split(";") if len(_norm(p)) >= 4}
        found = []
        for j in range(i):
            if topics[j]["topic"] != t["topic"] and any(w in texts[j] or (len(texts[j]) >= 6 and texts[j] in w)
                                                        for w in wanted):
                found.append(topics[j]["topic"])
        result[t["topic"]] = found[-3:]
    return result


# =====================================================================
# 5. What the model is used for
# =====================================================================
def recommend(student=None, n=4, now=None, docs=None):
    """
    The next things to study, best first: [{'topic', 'action', 'reason', 'pages', 'doc', 'priority'}].
    Order of importance: topics where the student is weak or just made mistakes (and their weak prerequisites
    before them), reviews that are due, topics with too few answers to judge, topics never tested, then stretch
    topics. Every item says why. An exam date makes everything more urgent.
    """
    student = _s(student)
    now = _now(now)
    states = all_states(student, now, docs)
    if not states:
        return []
    by_topic = {s["topic"]: s for s in states}
    prereqs = prerequisite_map()
    profile = get_profile(student) or {}
    urgency = 1.0
    if profile.get("exam_date"):
        try:
            days = (datetime.strptime(profile["exam_date"], "%Y-%m-%d").date() - date.fromtimestamp(now)).days
            urgency = 1.5 if days <= 7 else 1.25 if days <= 21 else 1.0
        except ValueError:
            pass
    items = []
    for s in states:
        m, due = s["mastery"], s["due_in_days"]
        k = s["knowledge"]                                   # what they knew when they answered (forgetting is handled by the review date)
        weak_pre = [p for p in prereqs.get(s["topic"], []) if by_topic[p]["assessed"] and by_topic[p]["knowledge"] < WEAK_BELOW]
        n_ans, right, wrong = s["n_answers"], s["n_right"], s["recent_wrong"]
        asked = f" You also asked the tutor about it {s['n_tutor']} time(s)." if s["n_tutor"] else ""
        if not s["assessed"]:
            action, pr, why = "assess", 0.45, "You have not been tested on this yet." + asked
            if s["n_tutor"]:
                pr = 0.5                                       # asked the tutor but never tested: a little more urgent
        elif n_ans < MIN_EVIDENCE and right == 0:
            action, pr = "learn", 0.9
            why = f"You missed {'the question' if n_ans == 1 else 'the questions'} on this ({n_ans} answered): study it, then retest."
        elif n_ans < MIN_EVIDENCE:
            action, pr = "assess", 0.6
            why = f"Too early to tell: {s['evidence']} so far. A few more questions will show if you really know it."
        elif k < WEAK_BELOW:
            action, pr = "learn", 1.0 - k
            why = f"Weak: about {round(100 * k)}% ({s['evidence']})."
        elif wrong and due is not None and due < 1.5:
            action, pr = "review", 0.85
            why = (f"You got {wrong} of your last answers wrong here. Reread the pages and the explanations of "
                   f"the questions you missed; retest {due_phrase(max(due, 0.5))}.")
        elif due is not None and due < 0:
            action, pr = "review", 0.55 + min(0.2, -due / 30)
            why = f"Due for review ({due_phrase(due)}): your memory of it has faded."
        elif k < STRONG_ABOVE:
            action, pr, why = "practice", 0.4 * (1 - k) + 0.2, f"Getting there: about {round(100 * k)}% ({s['evidence']}). A few harder questions will lock it in."
        else:
            action, pr, why = "challenge", 0.1, f"Strong (about {round(100 * k)}%, {s['evidence']}). Try a hard mock exam question set to stay sharp."
        if weak_pre and action in ("learn", "assess", "practice"):
            why += f" It builds on {weak_pre[0]}, which is also weak."
        items.append({"topic": s["topic"], "action": action, "reason": why, "pages": s["pages"], "where": s["where"],
                      "doc": s["doc"],
                      "priority": round(pr * urgency, 3), "weak_prereq": weak_pre[0] if weak_pre else None})
    # a weak prerequisite goes ahead of the topic that needs it
    items.sort(key=lambda x: -x["priority"])
    ordered, seen = [], set()
    for it in items:
        dep = it["weak_prereq"]
        if dep and dep not in seen:
            pre = next((x for x in items if x["topic"] == dep), None)
            if pre and pre["topic"] not in seen:
                ordered.append(pre)
                seen.add(pre["topic"])
        if it["topic"] not in seen:
            ordered.append(it)
            seen.add(it["topic"])
    return ordered[:n]


def difficulty_plan(student, topics, n, now=None):
    """
    How many easy / medium / hard questions to ask for these topics: aimed at the ability (theta) that the
    IRT method estimated, so the student succeeds about TARGET_SUCCESS of the time.
    Without enough answers it falls back to the BKT mastery, and without any it asks mostly medium.
    """
    now = _now(now)
    profile = get_profile(student)
    states = [topic_state(student, t, now, profile) for t in (topics or [])]
    states = [s for s in states if s["assessed"]]
    if not states:
        target = 0.0
    else:
        thetas = [s["theta"] if s["theta"] is not None else _logit(s["knowledge"]) for s in states]
        target = sum(thetas) / len(thetas) - _logit(TARGET_SUCCESS)         # the difficulty b with ~70 percent success
    if target < -0.5:
        shares = (0.45, 0.45, 0.10)
    elif target < 0.5:
        shares = (0.15, 0.55, 0.30)
    else:
        shares = (0.0, 0.40, 0.60)
    easy, hard = round(n * shares[0]), round(n * shares[2])
    return {"easy": easy, "medium": max(0, n - easy - hard), "hard": hard, "target_difficulty": round(target, 2)}


def topics_for_units(unit_ids):
    """The topic names (in order, no repeats) that a set of units belongs to."""
    index = {uid: t["topic"] for t in outline.topics() for uid in t["unit_ids"]}
    return list(dict.fromkeys(index[u] for u in unit_ids if u in index))


def guidance(student, topics, now=None):
    """
    How the tutor should explain, from the student's state on the topics a question is about.
    Returns {'style': 'from_basics' | 'standard' | 'concise', 'topic', 'mastery', 'note', 'caption', 'prerequisite'}.
    A topic with answers is judged by its mastery; a topic never tested falls back to the level the student
    gave at intake (if any).
    """
    now = _now(now)
    profile = get_profile(student)
    states = [topic_state(student, t, now, profile) for t in dict.fromkeys(topics or [])]
    empty = {"style": "standard", "topic": None, "mastery": None, "note": "", "caption": "", "prerequisite": None}
    if not states:
        return empty
    s = min(states, key=lambda x: x["mastery"])
    from_intake = False
    if s["assessed"] and s["n_answers"] >= 2:
        style = ("from_basics" if s["mastery"] < WEAK_BELOW else "concise" if s["mastery"] >= STRONG_ABOVE
                 else "standard")
    elif profile and profile["level"] in ("beginner", "advanced"):
        style, from_intake = ("from_basics" if profile["level"] == "beginner" else "concise"), True
    else:
        return empty
    pre_states = [topic_state(student, p, now, profile) for p in prerequisite_map().get(s["topic"], [])]
    weak = next((p["topic"] for p in pre_states if p["assessed"] and p["mastery"] < WEAK_BELOW), None)
    notes = {
        "from_basics": "The student is still weak on this topic. Explain from the basics in small steps, define every "
                       "technical term the first time you use it, and keep sentences short.",
        "standard": "The student has some grasp of this topic. Explain clearly and completely.",
        "concise": "The student knows this topic well. Be concise, skip the basics, and end with one short challenge "
                   "question they could try (do not give its answer).",
    }
    note = notes[style]
    if weak:
        note += f" If it helps, point out that this builds on '{weak}', which they should review."
    shown = {"from_basics": "explained from the basics", "standard": "standard explanation",
             "concise": "short explanation with a challenge"}[style]
    caption = (f"Adapted to the level you gave ({profile['level']}): {shown}." if from_intake else
               f"Adapted to your level in '{s['topic']}' ({round(100 * s['mastery'])}% mastery): {shown}.")
    if weak:
        caption += f" Tip: review '{weak}' first."
    return {"style": style, "topic": s["topic"], "mastery": s["mastery"], "note": note, "caption": caption,
            "prerequisite": weak}


# =====================================================================
# 6. Facts about the student, for the coach and for quiz notes
# =====================================================================
def _wrong_answers(student_topics, limit=6):
    """The latest answers that were not fully right, on the given topics: [{'topic', 'question', ...}]."""
    if not student_topics:
        return []
    conn = _conn()
    marks = ",".join("?" * len(student_topics))
    try:
        rows = conn.execute(
            f"SELECT q.topic, q.question, a.answer, a.score, q.mistake, q.qtype, q.options, q.key, q.doc, "
            f"q.page_start, q.page_end, a.ts FROM quiz_answers a JOIN quiz_questions q ON q.id = a.question_id "
            f"WHERE a.score < 1 AND q.topic IN ({marks}) ORDER BY a.ts DESC LIMIT ?",
            list(student_topics) + [limit]).fetchall()
    except sqlite3.OperationalError:
        rows = []
    conn.close()
    import json
    kinds = store.doc_types()
    out = []
    for topic, question, answer, score, mistake, qtype, options, key, doc, p0, p1, ts in rows:
        key = json.loads(key or "{}")
        options = json.loads(options or "{}")
        if qtype == "mcq":
            given = f"{answer}. {options.get(answer, '')}".strip()
            right = f"{key.get('correct')}. {options.get(key.get('correct'), '')}"
        elif qtype == "numerical":
            given, right = answer, f"{key.get('value')} {key.get('unit', '')}".strip()
        else:
            given, right = answer, key.get("reference", "")
        out.append({"topic": topic, "question": question, "given": given, "right": right, "mistake": mistake,
                    "score": score, "where": store.loc_label(kinds.get(doc, "pdf"), p0, p1), "doc": doc, "ts": ts})
    return out


def quiz_note(student, topics, now=None):
    """
    A short note for a tutor answer: what the student got wrong in their quizzes on these topics, built from
    the saved quiz data (no model, no citations). '' when there is nothing to say.
    """
    wrong = _wrong_answers(list(dict.fromkeys(topics or [])), limit=2)
    if not wrong:
        return ""
    lines = []
    for w in wrong:
        line = f"In your quiz on **{w['topic']}** you answered \"{w['given'][:120]}\" to: {w['question'][:160]}"
        if w["mistake"]:
            line += f"  \nThe usual slip: {w['mistake']}"
        line += f"  \nWorth rereading: {w['doc']}, {w['where']}."
        lines.append(line)
    return "\n\n".join(lines)


def topic_facts(student, topics, now=None):
    """
    Plain-text facts about the student on the given topics (for the short personal note under a tutor answer):
    mastery with its evidence and their recent mistakes there. '' when the student has no data on these topics.
    """
    student = _s(student)
    now = _now(now)
    lines = []
    profile = get_profile(student)
    for t in list(dict.fromkeys(topics or [])):
        st_ = topic_state(student, t, now)
        if not st_["assessed"]:
            continue
        lines.append(f"- Topic {t}: about {round(100 * st_['mastery'])}% mastery ({st_['evidence']}, from {st_['n_answers']} "
                     f"answer(s)); review {due_phrase(st_['due_in_days'])}.")
    if not lines:
        return ""
    for w in _wrong_answers(list(dict.fromkeys(topics or [])), limit=2):
        lines.append(f"- Missed in a quiz on {w['topic']}: \"{w['question'][:160]}\" | answered: {w['given'][:100]} | "
                     f"correct: {w['right'][:100]} | likely slip: {w['mistake'] or 'unknown'} | revise: {w['doc']}, {w['where']}")
    if profile and profile["goal"]:
        lines.append(f"- The student's goal: {profile['goal']}.")
    return "\n".join(lines)


def coach_facts(student=None, docs=None, now=None):
    """
    Everything the coach may say, as plain text, plus whether there is any data at all.
    Returns (text, has_data).
    """
    student = _s(student)
    now = _now(now)
    states = all_states(student, now, docs)
    assessed = [s for s in states if s["assessed"]]
    profile = get_profile(student)
    if not assessed and not any(s["n_tutor"] for s in states):
        return "", False
    lines = []
    if profile:
        lines.append(f"Student level: {profile['level']}. Goal: {profile['goal'] or 'not given'}."
                     + (f" Exam date: {profile['exam_date']}." if profile["exam_date"] else ""))
    conn = _conn()
    last = conn.execute("SELECT MAX(ts) FROM learner_events WHERE student=? AND source != 'tutor'", (student,)).fetchone()[0]
    conn.close()
    if last:
        ago = max(0.0, now - last)
        lines.append("Last quiz answer recorded: " + ("just now" if ago < 120 else f"{round(ago / 60)} minutes ago" if ago < 3600
                     else f"{round(ago / 3600)} hours ago" if ago < 2 * DAY else f"{round(ago / DAY)} days ago") + ".")
    lines.append("HOW THE NUMBERS WORK (use this if the student asks why a number or date is what it is): mastery is an "
                 "estimate built ONLY from quiz, mock exam and diagnostic answers (every quiz taken so far counts, each question "
                 "once); asking the tutor is not counted as a result. With few answers the estimate stays near the starting "
                 "level and the range is wide. The review date says when memory of the topic is expected to fade: a wrong "
                 "answer brings it forward (but never sooner than about 12 hours), a right answer pushes it out. A review "
                 "date soon after a quiz means 'revisit the questions you missed', not 'take the whole quiz again now'.")
    if profile and profile["exam_date"]:
        try:
            left = (date.fromisoformat(profile["exam_date"]) - datetime.fromtimestamp(now).date()).days
            lines.append(f"TIME LEFT: the exam is on {profile['exam_date']}, {left} day(s) from now." if left >= 0
                         else f"The exam date {profile['exam_date']} has passed.")
        except ValueError:
            pass
    conn = _conn()
    scored = [r[0] for r in conn.execute("SELECT score FROM learner_events WHERE student=? AND score IS NOT NULL "
                                         "ORDER BY ts DESC LIMIT 16", (student,))]
    conn.close()
    if len(scored) >= 6:
        half = len(scored) // 2
        now_acc, before_acc = sum(scored[:half]) / half, sum(scored[half:]) / (len(scored) - half)
        lines.append(f"TREND: over the last {half} scored answers the student got {round(100 * now_acc)}% right, "
                     f"over the {len(scored) - half} before that {round(100 * before_acc)}%.")
    asked = recent_tutor_questions(student, 5)
    if asked:
        lines.append("WHAT THE STUDENT ASKED THE TUTOR RECENTLY (their own words, newest first):")
        for a_ in asked:
            lines.append(f"- {a_['question']}" + (f"  [topics: {'; '.join(a_['topics'][:2])}]" if a_["topics"] else ""))
    lines.append("WHAT THE APP CAN DO (suggest ONLY these): take a topic quiz on a named topic or a mock exam (Quiz tab); take "
                 "the diagnostic quiz; ask the tutor about a named topic (Tutor chat); reread a named page, slide or video "
                 "time range of a named document; see mastery and review dates (Dashboard).")
    lines.append("MASTERY BY TOPIC (weakest first):")
    for s in sorted(assessed, key=lambda x: x["mastery"]):
        due = "" if s["due_in_days"] is None else f" Review: {due_phrase(s['due_in_days'])}."
        lines.append(f"- {s['topic']} ({s['doc']}, {s['where']}): about {round(100 * s['mastery'])}% mastery "
                     f"(likely range {round(100 * s['low'])}-{round(100 * s['high'])}%), {s['evidence']} from {s['n_answers']} answer(s)."
                     + (f" {s['recent_wrong']} wrong among the last answers." if s["recent_wrong"] else "")
                     + f"{due}")
    untested = [s["topic"] for s in states if not s["assessed"]]
    if untested:
        lines.append("NOT TESTED YET: " + "; ".join(untested[:8]))
    wrong = _wrong_answers([s["topic"] for s in states], limit=6)
    if wrong:
        lines.append("RECENT MISTAKES:")
        for w in wrong:
            lines.append(f"- Topic {w['topic']} ({w['doc']}, {w['where']}). Question: {w['question'][:200]} | "
                         f"Student answered: {w['given'][:150]} | Correct: {w['right'][:150]} | "
                         f"Likely slip: {w['mistake'] or 'unknown'}")
    recs = recommend(student, 3, now, docs)
    if recs:
        lines.append("SUGGESTED NEXT STEPS:")
        for r in recs:
            lines.append(f"- {r['topic']} ({r['doc']}, {r['where']}): {ACTION_WORDS[r['action']]}. {r['reason']}")
    return "\n".join(lines), True


ACTION_WORDS = {"learn": "learn it again", "review": "review it", "practice": "practise it", "assess": "test yourself on it",
                "challenge": "try harder questions"}
