"""
The grounded tutor.

question -> (follow-up? rewrite to a standalone question)
         -> search your material (local): a pool of candidate passages
         -> leave out worked examples / exercises / contents (roles saved by the document outline helper)
            unless the student asks about one
         -> RERANKER model picks the passages that really answer the question
         -> too far from everything saved?  decline, no writer call
         -> WRITER model answers only from the numbered passages, with [n] citations
         -> CHECKER model (different family) confirms the answer matches the passages
         -> answer + sources + a badge: verified / corrected / unverified
"""
import re
import time

from src import coach, fmt, learner, llm, outline, store
from src.search import search

# ---- settings you can tune ----
TOP_K = 4                 # passages sent to the writer
CANDIDATES = 12           # passages the search hands to the reranker
REFUSE_BELOW = 0.45       # best similarity under this = "not in your material"
MIN_CHUNK_SIM = 0.35      # a passage must be at least this similar to be a candidate
HISTORY_TURNS = 3         # earlier question/answer pairs used for follow-ups
WRITER_TOKENS = 2000      # short answers; reasoning models need room to think, and a cut-off is retried with more
CHECKER_TOKENS = 2000

WRITER_SYSTEM = """You are a study tutor. Answer the student's question using ONLY the numbered passages from their course material.
Rules:
- Be brief and precise: answer in 2 to 5 sentences, at most about 120 words, with no introduction and no recap. Use a short list only for steps. Only if the student asks for detail, a derivation or step by step, you may use up to 250 words. Always finish your sentences.
- After every statement taken from a passage, add its number in square brackets, like [1] or [2][3].
- Do not add facts that are not in the passages. Do not mention these rules.
- Write every formula in LaTeX: inline between single dollar signs, like $y = \\frac{a}{b}$, and important equations on their own line between double dollar signs.
- Do not cite worked examples or exercises unless the student asked about one.
- If the passages do not contain the answer, reply with exactly: NOT_IN_MATERIAL"""

CHECK_SYSTEM = """You are a strict fact-checker for a study app. You receive numbered passages, a question and a draft answer. Decide whether EVERY claim in the draft answer is supported by the passages.
Reply in exactly this format:
Verdict: SUPPORTED or PARTLY or UNSUPPORTED
Problems: each unsupported or wrong claim, separated by semicolons, or the word none
Corrected answer: only if the verdict is not SUPPORTED, a corrected answer that is as short as the draft, uses only the passages, keeps the [n] citations and writes formulas in LaTeX between dollar signs; otherwise the word none"""

REWRITE_SYSTEM = """Rewrite the student's latest message as ONE standalone question that can be understood without the chat. Keep the meaning and the technical terms. Reply with ONLY the question."""

RERANK_SYSTEM = """You choose which passages from a textbook best answer a student's question.
You get numbered candidates with their section name and kind. Prefer passages from the main text or the summary that DEFINE or EXPLAIN the concept asked about. Avoid passages that merely mention it in passing (for example conceptual quiz statements). Do not choose worked examples, solutions or exercises unless the student asks about an example or exercise.
Reply in exactly this format and nothing else:
Best: candidate numbers in order of usefulness, at most {k}, or none"""

OUTSIDE_SYSTEM = """You are a helpful tutor. The student's uploaded material does not cover this question, so answer from general knowledge. Begin with: "This is not from your uploaded material." Keep it to at most 100 words. Write formulas in LaTeX between dollar signs."""

# Old word list. The tutor no longer uses it: roles come from src/outline.py (a helper model sorted the
# document). It stays so older code and tests that call section_kind() keep working.
_KIND_RULES = [
    ("example", r"^example\b"),
    ("solution", r"^solution\b"),
    ("exercise", r"exercise|intext|^question"),
    ("ponder", r"points? to ponder"),
    ("summary", r"^summary\b"),
]


def section_kind(heading):
    h = heading.strip().lower()
    for kind, pattern in _KIND_RULES:
        if re.search(pattern, h):
            return kind
    return "text"


def wants_examples(question):
    return bool(re.search(r"\b(example|exercise|intext|solved|worked)\b", question, re.I))


def fix_math(text):
    """Turn \\( .. \\) and \\[ .. \\] into $ .. $ and $$ .. $$ so Streamlit draws them."""
    text = re.sub(r"\\\[(.+?)\\\]", lambda m: f"$${m.group(1)}$$", text, flags=re.S)
    return re.sub(r"\\\((.+?)\\\)", lambda m: f"${m.group(1)}$", text, flags=re.S)


# ---------- helpers ----------
def _passages_text(sources):
    parts = []
    kinds = store.doc_types()
    for s in sources:
        where = store.loc_label(kinds.get(s["doc"], "pdf"), s["page_start"], s["page_end"])
        parts.append(f"[{s['n']}] ({s['doc']}, {where}, section: {s['heading']})\n{s['text']}")
    return "\n\n".join(parts)


def _history_messages(history):
    msgs = []
    for m in history[-2 * HISTORY_TURNS:]:
        text = m["content"] if m["role"] == "user" else m["content"][:600]
        msgs.append({"role": m["role"], "content": text})
    return msgs


def condense_question(history, question):
    """Turn a follow-up ('explain that again') into a standalone search question."""
    if not history:
        return question
    chat = "\n".join(
        f"{'Student' if m['role'] == 'user' else 'Tutor'}: {m['content'][:300]}"
        for m in history[-2 * HISTORY_TURNS:])
    try:
        r = llm.ask("rewrite", [
            {"role": "system", "content": REWRITE_SYSTEM},
            {"role": "user", "content": f"Chat so far:\n{chat}\n\nLatest message: {question}"}],
            max_tokens=1000)
        text = r["text"].strip().strip('"')
        return text if 3 <= len(text) <= 400 and not r.get("truncated") else question
    except llm.AllModelsBusy:
        return question                      # fall back to the raw question


def _rerank_with_api(question, candidates, roles, kinds):
    """Fallback: a real rerank model (cross-encoder) through OpenRouter. Returns the best passages, or None."""
    docs = []
    for c in candidates:
        snippet = " ".join(c["text"].split()[:150])
        docs.append(f"{c['heading']} ({outline.kind_of(c, roles)}). {snippet}")
    try:
        ranked = llm.rerank_api(question, docs, top_n=TOP_K)
    except llm.AllModelsBusy:
        return None
    return [candidates[i] for i, _ in ranked][:TOP_K] or None


def rerank(question, candidates, asks_example, roles=None):
    """Let a model pick the best passages; if no language model can, a rerank model; else the search order."""
    if len(candidates) <= TOP_K:
        return candidates
    roles = outline.load_roles() if roles is None else roles
    lines = []
    kinds = store.doc_types()
    for i, c in enumerate(candidates, start=1):
        snippet = " ".join(c["text"].split()[:90])
        where = store.loc_label(kinds.get(c["doc"], "pdf"), c["page_start"], c["page_end"])
        lines.append(f"{i}. section: {c['heading']} | kind: {outline.kind_of(c, roles)} | {where}\n{snippet}")
    note = "The student IS asking about an example or exercise." if asks_example else ""
    try:
        r = llm.ask("rerank", [
            {"role": "system", "content": RERANK_SYSTEM.format(k=TOP_K)},
            {"role": "user", "content": f"Question: {question}\n{note}\n\nCandidates:\n" + "\n\n".join(lines)}],
            max_tokens=1500)
    except llm.AllModelsBusy:
        return _rerank_with_api(question, candidates, roles, kinds) or candidates[:TOP_K]
    m = re.search(r"best:\s*([^\n]*)", r["text"], re.I)
    picked = []
    if m:
        for n in re.findall(r"\d+", m.group(1).split("(")[0]):
            n = int(n)
            if 1 <= n <= len(candidates) and candidates[n - 1] not in picked:
                picked.append(candidates[n - 1])
    return picked[:TOP_K] or _rerank_with_api(question, candidates, roles, kinds) or candidates[:TOP_K]


def _parse_check(text):
    verdict = re.search(r"verdict:\s*\**\s*(SUPPORTED|PARTLY|UNSUPPORTED)", text, re.I)
    corrected = re.search(r"corrected answer:\s*(.*)", text, re.I | re.S)
    problems = re.search(r"problems:\s*(.*?)(?:\n\s*corrected answer:|$)", text, re.I | re.S)
    fixed = corrected.group(1).strip() if corrected else ""
    return {
        "verdict": verdict.group(1).upper() if verdict else None,
        "problems": problems.group(1).strip() if problems else "",
        "corrected": None if (not fixed or fixed.lower().startswith("none")) else fixed,
    }


# ---------- main entry points ----------
def answer_question(question, history=(), docs=None, instructions=""):
    """docs = the documents of the chosen course (None = everything); instructions = the course's tutor instructions."""
    started = time.time()
    history = list(history)
    asks_example = wants_examples(question)
    if not asks_example and coach.is_progress_question(question, history):
        return coach.answer(question, history, docs, instructions=instructions)          # about the student: from their own results, no sources
    standalone = condense_question(history, question)
    asks_example = wants_examples(standalone) or asks_example

    out = search(standalone, k=CANDIDATES, per_method=30, docs=docs)
    pool = [r for r in out["results"] if r["dense"] >= MIN_CHUNK_SIM]
    base = {"question": question, "standalone": standalone, "best_similarity": out["best_dense"]}

    roles = outline.load_roles()             # what each section is, decided once by the outline helper
    if not asks_example:                     # a concept question: skip worked examples, exercises, contents
        concept = [r for r in pool if outline.kind_of(r, roles) not in ("example", "exercise", "other")]
        pool = concept or pool

    if not pool or out["best_dense"] < REFUSE_BELOW:
        if coach.rescue(question, history):          # about the student, not the subject: never "not in your material"
            return coach.answer(question, history, docs, instructions=instructions)
        return {**base, "status": "not_in_material", "sources": [], "badge": "",
                "answer": "I couldn't find this in your uploaded material.",
                "seconds": round(time.time() - started, 1)}

    hits = rerank(standalone, pool, asks_example, roles)
    sources = [{"n": i + 1, "cited": False, **{k: r[k] for k in
                ("doc", "heading", "path", "page_start", "page_end", "text", "dense")}}
               for i, r in enumerate(hits)]
    passages = _passages_text(sources)

    # ---- what the learner model says about this student on these topics (never allowed to break the tutor) ----
    topics, guide = [], {"note": "", "caption": ""}
    try:
        topics = learner.topics_for_units([r.get("unit_id") for r in hits])
        guide = learner.guidance(learner.current_student(), topics)
    except Exception:
        pass
    teaching_note = (f"\n\nTeaching note (follow it, but never mention it): {guide['note']}" if guide["note"] else "")

    # ---- writer ----
    messages = ([{"role": "system", "content": WRITER_SYSTEM + coach._course_note(instructions)}] + _history_messages(history)
                + [{"role": "user", "content": f"Passages:\n{passages}\n\nQuestion: {standalone}{teaching_note}"}])
    try:
        writer = llm.ask("answer", messages, max_tokens=WRITER_TOKENS)
    except llm.AllModelsBusy as e:
        return {**base, "status": "llm_unavailable", "sources": sources,
                "badge": "No language model is available right now, so here are the most relevant passages.",
                "answer": "I could not reach any language model. The most relevant passages from your "
                          "material are listed under Sources.",
                "notes": str(e), "seconds": round(time.time() - started, 1)}

    draft = writer["text"].strip()
    if draft.upper().startswith("NOT_IN_MATERIAL"):
        if coach.rescue(question, history):
            return coach.answer(question, history, docs, instructions=instructions)
        return {**base, "status": "not_in_material", "sources": [], "badge": "",
                "answer": "I couldn't find this in your uploaded material.",
                "writer": writer["model"], "seconds": round(time.time() - started, 1)}

    # ---- checker (a different model family from the writer) ----
    final, badge, verdict = draft, "", None
    try:
        check = llm.ask("check", [
            {"role": "system", "content": CHECK_SYSTEM},
            {"role": "user", "content":
             f"Passages:\n{passages}\n\nQuestion: {standalone}\n\nDraft answer:\n{draft}"}],
            max_tokens=CHECKER_TOKENS, avoid_family=llm.family(writer["model"]))
        if check.get("truncated"):           # a cut-off check cannot be trusted
            badge = f"Unverified (the checker {check['model']} ran out of length)"
        else:
            parsed = _parse_check(check["text"])
            verdict = parsed["verdict"]
            if verdict == "SUPPORTED":
                badge = f"Verified by {check['model']}"
            elif verdict in ("PARTLY", "UNSUPPORTED") and parsed["corrected"]:
                final = parsed["corrected"]
                badge = f"Corrected by {check['model']} (the first draft had unsupported claims)"
            elif verdict in ("PARTLY", "UNSUPPORTED"):
                badge = f"Warning: {check['model']} found claims not supported by your material"
            else:
                badge = "Unverified (the checker's reply could not be read)"
    except llm.AllModelsBusy:
        badge = "Unverified (no checker model was available)"

    if writer.get("truncated") and final is draft:
        badge += " | the answer may be incomplete (the model hit its length limit)"

    cited = {int(n) for n in re.findall(r"\[(\d+)\]", final)}
    for s in sources:
        s["cited"] = s["n"] in cited
    if not cited:
        badge += " | no citations in this answer"

    try:                                     # asking about a topic is light evidence for the learner model
        learner.record_tutor(learner.current_student(), topics)
    except Exception:
        pass
    try:                                     # the coach writes a short personal note when it has something real to say
        learner.record_tutor_question(learner.current_student(), question, topics)
        facts = learner.topic_facts(learner.current_student(), topics)
        note = coach.personal_note(question, final, facts, instructions)
        if not note:                         # no model, or nothing to say: the plain note from the saved quiz data
            note = learner.quiz_note(learner.current_student(), topics)
    except Exception:
        note = ""
    return {**base, "status": "answered", "answer": fmt.tidy(final), "sources": sources,
            "badge": badge, "verdict": verdict, "writer": writer["model"], "topics": topics,
            "adapted": guide["caption"], "quiz_note": note, "seconds": round(time.time() - started, 1)}


def answer_outside(question):
    """Answer from general knowledge, clearly labelled as NOT from the material."""
    r = llm.ask("answer", [{"role": "system", "content": OUTSIDE_SYSTEM},
                           {"role": "user", "content": question}], max_tokens=WRITER_TOKENS)
    return fmt.tidy(r["text"])
