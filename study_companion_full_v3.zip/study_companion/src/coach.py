"""
The coach: questions about the STUDENT, not about the subject.

  "how am I doing", "what should I revise", "how can I improve my accuracy on electric charges",
  "which topics are my weakest", "what mistakes did I make"

These are answered from the student's own quiz results and progress (the learner model and the saved
quiz answers), never from the textbook, and never with source citations.

Two steps, both done by models:
  1. a quick filter looks for words that could mean "about me" (or a follow-up to an earlier coach answer);
     only then does a fast model decide PROGRESS or CONTENT, looking at the previous message too (so ordinary
     subject questions cost no extra call, and "but I just took that test, why is it due?" stays with the coach);
  2. a model writes a short, concrete reply from the facts in learner.coach_facts() and nothing else.
A message that looks personal is never sent to the "outside knowledge" fallback: the tutor asks rescue().
"""
import re

from src import learner, llm
from src import fmt

_ME = r"\b(my|me|i|i'm|im|i've|ive|am i|mine|myself)\b"
_ABOUT_PROGRESS = (r"\b(quiz|quizzes|test|tests|mock|diagnostic|mistake|mistakes|weak|weakest|strong|strongest|improve|improvement|"
                   r"progress|score|scores|result|results|revise|revision|review|reviews|due|overdue|mastery|performance|accuracy|"
                   r"doing|plan|schedule|attempt|attempts|answered|marks|percent|percentage|retest|confidence|study next)\b")
TRIGGER = re.compile(
    r"\b(my|me|i|i'm|im|am i|mine|myself)\b.*\b(quiz|quizzes|mistake|mistakes|weak|weakest|strong|improve|improvement|"
    r"progress|score|scores|result|results|revise|revision|performance|accuracy|doing|wrong|plan|study next|next)\b"
    r"|\b(how (can|do|should) i (improve|get better|study|revise|prepare))\b"
    r"|\b(improve|boost|raise)\b.*\b(accuracy|score|marks|performance)\b"
    r"|\b(what should i (study|revise|do|focus|practi[sc]e)|where (am i|do i) (weak|stand|go wrong)|how am i)\b"
    r"|\b(my (weak|strong) (topics|areas|points))\b"
    r"|" + _ME + r".*" + _ABOUT_PROGRESS + r"|" + _ABOUT_PROGRESS + r".*" + _ME,
    re.I | re.S)

INTENT_SYSTEM = """Decide what the student's latest message is about.
PROGRESS = it is about the student's OWN learning: their quiz results, mistakes, weak or strong topics, mastery numbers, review or due dates (and why they are what they are), how to improve, what to revise or study next, their plan or schedule.
CONTENT = it asks to learn, explain, define or solve something about the subject itself.
If the previous message was a coaching answer about the student's progress and the new message follows up on it (why, how, what do you mean, but I just did ...), it is PROGRESS.
Reply with exactly one line: Intent: PROGRESS or Intent: CONTENT"""

COACH_SYSTEM = """You are a personal study coach. You speak to the student ("you") about THEIR OWN results. Use ONLY the facts below: never invent a score, a mistake or a page. 
Rules:
- Be concise: at most 150 words. No greeting, no recap of the question.
- The facts below ARE the student's results and schedule: never say you cannot see their records. If they ask why a number or a date is what it is, explain it from the HOW THE NUMBERS WORK paragraph, honestly; if a date or label looks wrong or too early, say so plainly instead of defending it.
- Be concrete but do NOT replay the quiz report: look for the PATTERN across the facts (the same kind of slip, the same weak topic, a trend up or down) and say it in your own words, with at most one example. Say where to revise (the document and its page, slide or time given in the facts).
- Connect the advice to what the student asked the tutor recently (their own words) and to their goal and the time left, when the facts give them.
- Finish with 2 or 3 short numbered next steps. Use ONLY the actions listed under WHAT THE APP CAN DO in the facts: never invent other features, activities or timings (no self-quizzes at the end of a video, no timers, no recaps the app does not offer).
- If the student asks about one topic or chapter, focus on it; if it has no data, say it has not been tested yet and suggest a quiz on it.
- No citations, no square brackets, no source list: this answer comes from the student's quiz results, not from a textbook.
- Write formulas in LaTeX between single dollar signs."""

PERSONAL_NOTE_SYSTEM = """You add one short personal note under a tutor's answer, speaking to the student ("you").
Use ONLY the facts given about this student on the topics of the answer; never invent a score, a mistake or a page.
- At most 2 short sentences. Connect the answer to something real in the facts: a weak topic, a slip the student made in a quiz, a page worth rereading, a review that is due.
- If nothing in the facts relates to this answer, reply with exactly: NONE
- No greeting, no citations, no square brackets. Write formulas in LaTeX between single dollar signs."""


def personal_note(question, answer, facts, instructions=""):
    """A model-written note for the student under a tutor answer, or '' (nothing to say, or no model available)."""
    if not (facts or "").strip():
        return ""
    messages = [{"role": "system", "content": PERSONAL_NOTE_SYSTEM + _course_note(instructions)},
                {"role": "user", "content": f"FACTS ABOUT THE STUDENT ON THESE TOPICS:\n{facts}\n\n"
                                            f"STUDENT'S QUESTION: {question}\n\nTUTOR'S ANSWER: {answer[:1200]}"}]
    try:
        r = llm.ask("report", messages, max_tokens=300)
    except llm.AllModelsBusy:
        return ""
    text = re.sub(r"\[\d+\]", "", r["text"]).strip()
    if not text or text.upper().startswith("NONE") or r.get("truncated"):
        return ""
    return fmt.tidy(text)


NO_DATA = ("I don't have any quiz results from you yet, so I can't say where you are weak. "
           "Take the diagnostic quiz in the Quiz tab (one question per topic) and ask me again; "
           "then I can point to your weak topics and mistakes.")


def looks_personal(question):
    return bool(TRIGGER.search(question or ""))


def _course_note(instructions):
    """The student's own instructions for the course (tone, language, level). They never override the rules above."""
    text = (instructions or "").strip()[:800]
    return ("\n\nThe student wrote these instructions for this course. Follow them for tone, language and level only; "
            "the rules above always win:\n" + text) if text else ""


def previous_was_coach(history):
    """True if the last tutor message in the chat was a coaching answer (the app marks it with coach=True)."""
    return bool(history) and bool(history[-1].get("coach"))


def rescue(question, history=()):
    """True if this message should go to the coach instead of being declined as 'not in your material'."""
    return looks_personal(question) or previous_was_coach(history)


def is_progress_question(question, history=()):
    """True if a model says the message is about the student's own progress. Filters first, to save calls."""
    sticky = previous_was_coach(history)
    if not (looks_personal(question) or sticky):
        return False
    context = ""
    if history:
        last = history[-1]
        who = "tutor" if last["role"] == "assistant" else "student"
        context = (f"Previous {who} message" + (" (a coaching answer about the student's own progress)" if sticky else "")
                   + f": {last['content'][:300]}\n\n")
    try:
        r = llm.ask("rewrite", [{"role": "system", "content": INTENT_SYSTEM},
                                {"role": "user", "content": context + "Latest message: " + question}], max_tokens=300)
    except llm.AllModelsBusy:
        return sticky                                 # cannot decide: stay with the coach in a coaching chat, else a subject question
    m = re.search(r"intent:\s*\**\s*(PROGRESS|CONTENT)", r["text"], re.I)
    return bool(m and m.group(1).upper() == "PROGRESS")


def answer(question, history=(), docs=None, student=None, instructions=""):
    """A coach reply built from the student's data. Returns the same shape as tutor.answer_question."""
    import time
    started = time.time()
    student = student or learner.current_student()
    facts, has_data = learner.coach_facts(student, docs)
    base = {"question": question, "standalone": question, "best_similarity": 1.0, "sources": [], "topics": [],
            "adapted": "", "coach": True}
    if not has_data:
        return {**base, "status": "coach", "answer": NO_DATA, "badge": "Personal coach: no quiz results yet",
                "seconds": 0.0}
    messages = [{"role": "system", "content": COACH_SYSTEM + _course_note(instructions)}]
    for m in list(history)[-4:]:
        messages.append({"role": m["role"], "content": m["content"][:400]})
    messages.append({"role": "user", "content": f"FACTS ABOUT THE STUDENT:\n{facts}\n\nSTUDENT'S QUESTION: {question}"})
    try:
        r = llm.ask("report", messages, max_tokens=900)
    except llm.AllModelsBusy:
        return {**base, "status": "coach", "answer": "I could not reach a language model. Here are the facts I have:\n\n" + facts,
                "badge": "Personal coach: model unavailable", "seconds": round(time.time() - started, 1)}
    text = fmt.tidy(re.sub(r"\[\d+\]", "", r["text"]).strip())        # no stray citation marks, math tidied
    return {**base, "status": "coach", "answer": text, "badge": f"From your quiz results and progress (by {r['model']})",
            "seconds": round(time.time() - started, 1)}
