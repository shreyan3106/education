"""
Lecture videos as study material (YouTube links, up to 60 minutes).

  1. captions   : the video's own captions (youtube-transcript-api), instant, no download.
  2. Whisper    : if there are no captions, the audio is downloaded (yt-dlp), cut into pieces below the 25 MB
                  limit (ffmpeg from the imageio-ffmpeg package, nothing to install by hand) and transcribed by
                  Whisper on Groq with timestamps.
  3. units      : the transcript is cut into windows of about a minute (the searchable passages) and every
                  FIVE MINUTES becomes a unit with a title written by a model. The "page" numbers of a unit
                  and passage are SECONDS from the start, so a citation opens the video at that second.
"""
import json
import os
import re
import tempfile
import urllib.parse
import urllib.request

from src import llm

MAX_SECONDS = 60 * 60
WINDOW_SECONDS = 60
WINDOW_WORDS = 170
UNIT_SECONDS = 300
LANGUAGES = ["en", "en-US", "en-GB", "en-IN", "hi"]
WHISPER_MODEL = "whisper-large-v3-turbo"
PIECE_SECONDS = 600               # 10 minutes of 64 kbit/s audio is about 5 MB

TITLE_SYSTEM = """You title the parts of a lecture video. You get numbered parts of the transcript, each with its time range and its first words. Give each part a short descriptive title (3 to 8 words) naming what is taught in it, in the speaker's own terms. Reply with one line per part, exactly like this and nothing else:
1 | title
2 | title"""


def video_id(url):
    """The 11-character YouTube id from a link, or None."""
    url = (url or "").strip()
    if re.fullmatch(r"[\w-]{11}", url):
        return url
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower()
    if "youtu.be" in host:
        cand = parsed.path.strip("/").split("/")[0]
    elif "youtube.com" in host:
        if parsed.path.startswith(("/embed/", "/shorts/", "/live/")):
            cand = parsed.path.split("/")[2]
        else:
            cand = urllib.parse.parse_qs(parsed.query).get("v", [""])[0]
    else:
        return None
    return cand if re.fullmatch(r"[\w-]{11}", cand or "") else None


def watch_url(vid):
    return f"https://www.youtube.com/watch?v={vid}"


def fetch_title(vid):
    """The video's title through YouTube's public oEmbed address, or the id if it cannot be fetched."""
    try:
        q = urllib.parse.quote(watch_url(vid), safe="")
        with urllib.request.urlopen(f"https://www.youtube.com/oembed?url={q}&format=json", timeout=6) as r:
            return json.loads(r.read().decode("utf-8")).get("title") or vid
    except Exception:
        return vid


NAME_CHARS = 120                  # characters of the video title kept in the saved name (the video id makes it unique)
FETCH_REAL_DURATION = True        # ask YouTube for the real length (captions often end a second after the video)


def safe_name(title, vid):
    clean = re.sub(r"[^\w\- ]+", "", title).strip()[:NAME_CHARS].strip() or "video"
    return f"{clean} [{vid}].youtube"


def fetch_duration(vid):
    """The video's real length in whole seconds from YouTube's metadata (no download), or None if it cannot be had."""
    try:
        import yt_dlp
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True}) as ydl:
            info = ydl.extract_info(watch_url(vid), download=False)
        return int(info.get("duration") or 0) or None
    except Exception:
        return None


# ---------- 1. captions ----------
def fetch_captions(vid, _api=None):
    """[{'text', 'start', 'duration'}] from the video's captions. Raises RuntimeError if there are none."""
    try:
        if _api is None:
            from youtube_transcript_api import YouTubeTranscriptApi as _api
        try:
            fetched = _api().fetch(vid, languages=LANGUAGES)                 # version 1.x
            snippets = [{"text": s.text, "start": s.start, "duration": s.duration} for s in fetched]
        except (AttributeError, TypeError):
            snippets = [dict(s) for s in _api.get_transcript(vid, languages=LANGUAGES)]   # older versions
    except ImportError:
        raise RuntimeError("The youtube-transcript-api package is not installed (pip install youtube-transcript-api).")
    except Exception as e:
        raise RuntimeError(f"No captions could be fetched ({type(e).__name__}).")
    snippets = [s for s in snippets if (s.get("text") or "").strip()]
    if not snippets:
        raise RuntimeError("The video has no captions.")
    return snippets


# ---------- 2. Whisper fallback ----------
def transcribe_audio(vid, _download=None, _split=None, _whisper=None):
    """Download the audio, cut it into pieces, transcribe each with Whisper on Groq: [{'text','start','duration'}]."""
    download = _download or _download_audio
    split = _split or _split_audio
    whisper = _whisper or _whisper_groq
    with tempfile.TemporaryDirectory() as tmp:
        audio, seconds = download(vid, tmp)
        if seconds > MAX_SECONDS:
            raise ValueError(f"This video is {seconds // 60} minutes long; the limit is {MAX_SECONDS // 60} minutes.")
        out = []
        for offset, piece in split(audio, tmp):
            for seg in whisper(piece):
                out.append({"text": seg["text"], "start": seg["start"] + offset,
                            "duration": max(0.0, seg["end"] - seg["start"])})
    if not out:
        raise RuntimeError("Nothing could be transcribed from the audio.")
    return out


def _download_audio(vid, folder):
    try:
        import yt_dlp
    except ImportError:
        raise RuntimeError("The yt-dlp package is not installed (pip install yt-dlp).")
    opts = {"format": "bestaudio/best", "outtmpl": os.path.join(folder, "audio.%(ext)s"), "quiet": True, "noprogress": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(watch_url(vid), download=False)
        if (info.get("duration") or 0) > MAX_SECONDS:
            raise ValueError(f"This video is {int(info['duration']) // 60} minutes long; the limit is {MAX_SECONDS // 60} minutes.")
        ydl.process_ie_result(info, download=True)
    path = next(os.path.join(folder, f) for f in os.listdir(folder) if f.startswith("audio."))
    return path, int(info.get("duration") or 0)


def _split_audio(path, folder):
    import subprocess
    import imageio_ffmpeg
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    pattern = os.path.join(folder, "piece_%03d.mp3")
    subprocess.run([ffmpeg, "-y", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k", "-f", "segment",
                    "-segment_time", str(PIECE_SECONDS), pattern], check=True, capture_output=True)
    pieces = sorted(f for f in os.listdir(folder) if f.startswith("piece_"))
    return [(i * PIECE_SECONDS, os.path.join(folder, f)) for i, f in enumerate(pieces)]


def _whisper_groq(piece_path):
    from openai import OpenAI
    key = llm._api_key("groq")
    if not key:
        raise RuntimeError("No GROQ_API_KEY in .env, so the audio cannot be transcribed.")
    client = OpenAI(base_url=llm.PROVIDERS["groq"]["base_url"], api_key=key, timeout=120.0, max_retries=0)
    with open(piece_path, "rb") as fh:
        r = client.audio.transcriptions.create(model=WHISPER_MODEL, file=fh, response_format="verbose_json",
                                               timestamp_granularities=["segment"])
    segments = getattr(r, "segments", None) or []
    return [{"text": (s["text"] if isinstance(s, dict) else s.text).strip(),
             "start": float(s["start"] if isinstance(s, dict) else s.start),
             "end": float(s["end"] if isinstance(s, dict) else s.end)} for s in segments]


# ---------- 3. units ----------
def _windows(snippets):
    """Group caption lines into windows of about a minute: [(start_seconds, text)]."""
    out, cur, cur_start, words = [], [], None, 0
    for s in snippets:
        if cur_start is None:
            cur_start = s["start"]
        cur.append(" ".join(s["text"].split()))
        words += len(s["text"].split())
        if s["start"] + s.get("duration", 0) - cur_start >= WINDOW_SECONDS or words >= WINDOW_WORDS:
            out.append((int(cur_start), " ".join(cur)))
            cur, cur_start, words = [], None, 0
    if cur:
        out.append((int(cur_start), " ".join(cur)))
    return out


def duration_of(snippets):
    return int(max(s["start"] + s.get("duration", 0) for s in snippets))


def title_parts(parts):
    """parts = [(start, end, first words)]. A model titles them; unreachable models give 'Part n'."""
    from src.store import fmt_time
    titles = {}
    for i in range(0, len(parts), 25):
        batch = parts[i:i + 25]
        body = "\n".join(f"{k + 1} | {fmt_time(a)}-{fmt_time(b)} | {words}" for k, (a, b, words) in enumerate(batch))
        try:
            r = llm.ask("extract", [{"role": "system", "content": TITLE_SYSTEM}, {"role": "user", "content": body}],
                        max_tokens=1200)
        except llm.AllModelsBusy:
            continue
        for line in r["text"].splitlines():
            m = re.match(r"^\W*(\d+)\s*\|\s*(.+)$", line)
            if m and 1 <= int(m.group(1)) <= len(batch):
                titles[i + int(m.group(1)) - 1] = m.group(2).strip(" *`\"")
    return titles


def to_units(snippets):
    """Transcript -> units (five minutes each) whose paragraphs are the one-minute windows."""
    windows = _windows(snippets)
    groups, cur = [], []
    for w in windows:
        if cur and w[0] - cur[0][0] >= UNIT_SECONDS:
            groups.append(cur)
            cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    end_of = lambda g, k: groups[k + 1][0][0] if k + 1 < len(groups) else duration_of(snippets)
    parts = [(g[0][0], end_of(g, k), " ".join(g[0][1].split()[:40])) for k, g in enumerate(groups)]
    titles = title_parts(parts)
    from src.store import fmt_time
    units = []
    for k, g in enumerate(groups):
        start, end = g[0][0], max(g[0][0], end_of(g, k))
        heading = titles.get(k) or f"Part {k + 1} ({fmt_time(start)}-{fmt_time(end)})"
        paragraphs = [{"page": t, "text": text} for t, text in g]
        units.append({"heading": heading, "level": 1 if k == 0 else 2, "path": heading, "page_start": start,
                      "page_end": max(end, g[-1][0]), "paragraphs": paragraphs,
                      "text": "\n\n".join(p["text"] for p in paragraphs)})
    return units


def read_video(url, _captions=None, _whisper_path=None):
    """
    Everything the pipeline needs for a YouTube link:
    {'name', 'url', 'title', 'units', 'duration', 'source': 'captions' | 'whisper'}.
    Raises ValueError for a bad link or a video over the time limit, RuntimeError if no transcript can be had.
    """
    vid = video_id(url)
    if not vid:
        raise ValueError("That does not look like a YouTube link.")
    source = "captions"
    try:
        snippets = (_captions or fetch_captions)(vid)
    except RuntimeError as caption_problem:
        try:
            snippets = (_whisper_path or transcribe_audio)(vid)
            source = "whisper"
        except (RuntimeError, ValueError) as e:
            if isinstance(e, ValueError):
                raise
            raise RuntimeError(f"{caption_problem} Audio transcription also failed: {e}")
    duration = (fetch_duration(vid) if FETCH_REAL_DURATION else None) or duration_of(snippets)
    if duration > MAX_SECONDS:
        raise ValueError(f"This video is {duration // 60} minutes long; the limit is {MAX_SECONDS // 60} minutes.")
    title = fetch_title(vid)
    return {"name": safe_name(title, vid), "url": watch_url(vid), "title": title, "units": to_units(snippets),
            "duration": duration, "source": source}
