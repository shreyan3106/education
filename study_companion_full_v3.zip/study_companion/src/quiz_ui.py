"""The Quiz tab: make a quiz or mock exam, answer with instant feedback, submit, read the report."""
import datetime

import streamlit as st

from src import fmt, learner, library, quiz, store, viewer

fix_math = fmt.clean          # every piece of model text is cleaned before it is drawn

TYPE_NAMES = {"mcq": "Multiple choice", "short": "Short answer", "numerical": "Numerical"}
KIND_NAMES = {"topic": "Topic quiz", "mock": "Mock exam", "diagnostic": "Diagnostic quiz"}


def _pages(q):
    return store.loc_label(store.doc_type(q["doc"]), q["page_start"], q["page_end"])


def _docs():
    """The documents of the chosen course (None = everything)."""
    return library.docs_in(st.session_state.get("course"))


def _show_source(q):
    st.markdown(f"**Source:** {q['doc']}, {_pages(q)}  (section: {q['heading']})")
    viewer.show_source(q["doc"], q["page_start"], q["page_end"], key=f"q{q['id']}", heading=q["heading"])


def _show_feedback(q, locked):
    """Feedback under a question: verdict, right answer, explanation, source. locked = quiz already submitted."""
    a = q["answer"]
    if a:
        if a["score"] >= 1:
            st.success("Correct")
        elif a["score"] > 0:
            st.warning("Partly correct")
        else:
            st.error("Incorrect")
        got = quiz.marks_of(q["qtype"]) * a["score"]
        st.markdown(f"**Marks:** {got:g} / {quiz.marks_of(q['qtype'])}")
        if q["qtype"] == "mcq":
            chosen = a["answer"]
            st.markdown(f"**Your answer:** {chosen}. " + fix_math(q["options"].get(chosen, "")))
        else:
            st.markdown(f"**Your answer:** {a['answer']}")
        if a["feedback"]:
            st.markdown(fix_math(a["feedback"]))
    else:
        st.info("Not answered.")
    st.markdown("**Correct answer:** " + fix_math(quiz.correct_answer_text(q)))
    if q["qtype"] == "short":
        st.markdown("**Key points**\n" + fmt.bullets(q["key"]["points"]))
    st.markdown(fix_math(q["explanation"]))
    _show_source(q)
    st.caption(f"Question written by {q['writer_model']}  |  answer key prepared and checked by "
               f"{q['checker_model']}"
               + (f"  |  answer graded by {a['graded_by']}" if a and a["graded_by"] not in ("code", None) else ""))


def _render_question(q, locked):
    st.markdown(f"**Question {q['pos']}**")
    n_marks = quiz.marks_of(q["qtype"])
    st.caption(f"{TYPE_NAMES[q['qtype']]}  |  {n_marks} mark{'s' if n_marks != 1 else ''}  |  difficulty: {q['difficulty']}  |  topic: {q['topic']}  |  "
               f"concept: {q['concept'] or '-'}  |  source: {q['doc']}, {_pages(q)}")
    st.markdown(fix_math(q["question"]))
    answered = q["answer"] is not None

    if q["qtype"] == "mcq":
        if answered or locked:
            for letter, text in q["options"].items():
                tags = []
                if letter == q["key"]["correct"]:
                    tags.append("correct answer")
                if answered and letter == q["answer"]["answer"]:
                    tags.append("your answer")
                tag = ("  (" + ", ".join(tags) + ")") if tags else ""
                st.markdown(f"**{letter}.** {fix_math(text)}{tag}")
        else:
            labels = [f"{L}. {fix_math(t)}" for L, t in q["options"].items()]
            choice = st.radio("Choose one", labels, index=None, key=f"mcq-{q['id']}",
                              label_visibility="collapsed")
            if choice is not None:                     # the moment an option is clicked
                quiz.answer_question(q["id"], choice[0])
                st.rerun()
    elif not answered and not locked:
        hint = ("Type a number, for example 0.25, 3e8 or 3 x 10^8" if q["qtype"] == "numerical"
                else "Write your answer in a sentence or two")
        with st.form(key=f"form-{q['id']}", border=False):
            text = st.text_input("Your answer", key=f"txt-{q['id']}", placeholder=hint)
            send = st.form_submit_button("Check answer")
        if send:
            try:
                with st.spinner("Checking your answer..."):
                    result = quiz.answer_question(q["id"], text)
            except Exception as e:
                result = {"ok": False, "message": f"Something went wrong ({e}). Press the button again."}
            if result["ok"]:
                st.rerun()
            else:
                st.warning(result["message"])

    if answered or locked:
        _show_feedback(q, locked)


def _show_report(report):
    st.subheader("Your report")
    c1, c2, c3 = st.columns(3)
    c1.metric("Marks", f"{report.get('marks', report['score']):g} / {report.get('marks_total', report['asked'])}")
    c2.metric("Percent", f"{report['percent']}%")
    c3.metric("Answered", f"{report['answered']} of {report['asked']}")

    weak = [t for t in report["topics"] if t["weak"]]
    if weak:
        st.markdown("**Weak topics (revise these first)**")
        for t in weak:
            st.markdown(f"- **{t['topic']}**: {t['percent']}% ({t['answered']} of {t['asked']} answered)"
                        + (f". Go back to {t['revise']}." if t["revise"] else ""))
    else:
        st.success("No weak topics in this quiz. Well done.")

    if report["misconceptions"]:
        st.markdown("**Likely misconceptions**")
        for m in report["misconceptions"]:
            st.markdown(f"- *{m['topic']}*: {m['text']}")

    st.markdown("**By topic**")
    st.table([{"topic": t["topic"], "answered": f"{t['answered']} of {t['asked']}",
               "marks": (f"{t['marks']:g} / {t['marks_asked']}" if "marks" in t else "-"), "score": f"{t['percent']}%",
               "revise": t["revise"]} for t in report["topics"]])
    if report["difficulty"]:
        st.markdown("**By difficulty**")
        st.table([{"difficulty": d["difficulty"], "answered": d["answered"], "score": f"{d['percent']}%"}
                  for d in report["difficulty"]])


def _show_topics(topics):
    """Sections of the material in book order: section, pages, key concepts (one table per file)."""
    docs = list(dict.fromkeys(t["doc"] for t in topics))
    for doc in docs:
        if len(docs) > 1:
            st.markdown(f"**{doc}**")
        st.table([{"Section": t["topic"], "Where": t["where"], "Key concepts": t["concepts"]}
                  for t in topics if t["doc"] == doc])


def _suggestions(n):
    """Topics the learner model suggests, or [] for a brand-new student. Never allowed to break the tab."""
    try:
        if learner.event_count(learner.current_student()) == 0:
            return []
        return [r for r in learner.recommend(learner.current_student(), n, docs=_docs()) if r["action"] != "challenge"]
    except Exception:
        return []


def _pick_topic(topic):
    st.session_state["quiz_topic"] = topic


def _make_form():
    topics = quiz.available_topics(_docs())
    diag = f"Diagnostic (1 question per topic, up to {quiz.DIAGNOSTIC_TOPICS})"
    mode = st.radio("What do you want?", [f"Topic quiz ({quiz.TOPIC_QUIZ_SIZE} questions)",
                                          f"Mock exam ({quiz.MOCK_SIZE} questions, {quiz.MOCK_TOPICS} topics)", diag],
                    horizontal=True, key="quiz_mode")
    is_mock, is_diag = mode.startswith("Mock"), mode.startswith("Diagnostic")
    topic, chosen, ready = "", [], True
    if is_diag:
        st.caption("A short first test. It shows what you already know, so later quizzes and the tutor can fit you. "
                   "It is also useful again after a long break.")
        if not topics:
            st.warning("No sections have been found yet. Add material to this course first (Course tab).")
            ready = False
    elif is_mock:
        names = [t["topic"] for t in topics]
        if "quiz_mock_topics" not in st.session_state:
            st.session_state["quiz_mock_topics"] = [r["topic"] for r in _suggestions(quiz.MOCK_TOPICS)
                                                    if r["topic"] in names][:quiz.MOCK_TOPICS]
        chosen = st.multiselect(f"Choose exactly {quiz.MOCK_TOPICS} sections from your material", names,
                                max_selections=quiz.MOCK_TOPICS, key="quiz_mock_topics")
        ready = len(chosen) == quiz.MOCK_TOPICS
        if not ready:
            st.caption(f"{len(chosen)} of {quiz.MOCK_TOPICS} chosen.")
        if not names:
            st.warning("No sections have been found yet. Add material to this course first (Course tab).")
    else:
        sug = _suggestions(3)
        if sug:
            st.caption("Suggested for you (from your progress):")
            cols = st.columns(len(sug))
            for col, r in zip(cols, sug):
                col.button(r["topic"][:40], key=f"sug-{r['topic']}", help=r["reason"],
                           on_click=_pick_topic, args=(r["topic"],))
        elif learner.needs_intake(learner.current_student()):
            st.caption("New here? Take the diagnostic quiz first (choose it above), and set your level in the Dashboard tab.")
        topic = st.text_input("Type the topic you want to be quizzed on", key="quiz_topic",
                              placeholder="a topic from your material, see the list below")
        ready = len(topic.strip()) >= 2
    if topics:
        with st.expander("Sections found in your material (book order)"):
            _show_topics(topics)

    if st.button("Make the quiz", type="primary", disabled=not ready, key="quiz_make"):
        bar = st.progress(0.0, text="Choosing passages and writing questions...")

        def progress(done, total):
            bar.progress(min(done / total, 1.0),
                         text=f"{done} of {total} questions written, checked and saved")

        try:
            result = (quiz.create_diagnostic(progress, _docs()) if is_diag else
                      quiz.create_mock_exam(chosen, progress) if is_mock else quiz.create_topic_quiz(topic, progress, _docs()))
        except Exception as e:                       # never leave the student with a traceback
            result = {"ok": False, "message": f"Something went wrong: {e}", "set_id": None, "notes": []}
        bar.empty()
        for note in result.get("notes", []):
            st.warning(note)
        if result["ok"]:
            st.session_state["quiz_set_id"] = result["set_id"]
            if result["message"]:
                st.session_state["quiz_notice"] = result["message"]
            st.rerun()
        else:
            st.error(result["message"])
            if result.get("dropped"):
                with st.expander("Why questions were rejected"):
                    st.write(result["dropped"])


def render_quiz_tab():
    if not _docs():
        st.info("Add material to this course first (Course tab). Then you can be quizzed on it here.")
        return

    set_id = st.session_state.get("quiz_set_id")
    current = quiz.load_set(set_id) if set_id else None

    if current is None:
        _make_form()
    else:
        locked = bool(current["submitted"])
        kind = KIND_NAMES.get(current["kind"], "Quiz")
        head, new = st.columns([4, 1])
        head.subheader(f"{kind}: {current['scope']}")
        if new.button("Start a new quiz", key="quiz_new"):
            st.session_state.pop("quiz_set_id", None)
            st.session_state.pop("quiz_notice", None)
            st.rerun()
        if st.session_state.get("quiz_notice"):
            st.info(st.session_state["quiz_notice"])

        qs = current["questions"]
        done = sum(1 for q in qs if q["answer"])
        st.progress(done / len(qs) if qs else 0.0, text=f"{done} of {len(qs)} answered")
        for q in qs:
            with st.container(border=True):
                _render_question(q, locked)

        if locked:
            _show_report(current["report"])
        else:
            if done < len(qs):
                st.caption(f"{len(qs) - done} question(s) not answered yet. They count as zero if you submit now.")
            if st.button("Submit and see the report", type="primary", key="quiz_submit"):
                with st.spinner("Preparing your report..."):
                    quiz.submit_set(current["id"])
                st.rerun()

    with st.expander("Earlier quizzes"):
        rows = quiz.list_sets(_docs())
        if rows:
            fmt_time = lambda ts: datetime.datetime.fromtimestamp(ts).strftime("%d %b %Y, %I:%M %p")
            st.table([{"#": i, "type": KIND_NAMES.get(r["kind"], "Quiz"),
                       "scope": r["scope"][:60], "questions": r["questions"], "answered": r["answered"],
                       "marks": (f"{r['marks']:g} / {r['marks_total']}" if r["marks"] is not None else "-"),
                       "started": fmt_time(r["created"]),
                       "submitted": fmt_time(r["submitted_at"]) if r["submitted_at"] else "not yet"}
                      for i, r in enumerate(rows, start=1)])
            st.caption("Numbered from 1 in this course, oldest first.")
        else:
            st.caption("Nothing yet.")
