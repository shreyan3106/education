"""Tests for courses (src/library.py): create, add material, settings, per-course progress, move, delete.
Fake models and fake embeddings: no internet, no keys."""
import os, sys, tempfile, re, hashlib, threading
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, llm, outline, pipeline, library, learner

tmp = tempfile.mkdtemp()
store.DB_PATH = os.path.join(tmp, "t.db")
store.FILES_DIR = os.path.join(tmp, "files")


def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), 64), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
        out[i] /= (np.linalg.norm(out[i]) or 1)
        if progress:
            progress(i + 1, len(texts))
    return out, "fake-model"
embed.embed_texts = fake_embed
pipeline.embed_texts = fake_embed
llm.ask = lambda *a, **k: {"text": "", "model": "x", "truncated": False}       # tagging etc.: nothing, must not crash


def make(name, heading, course, words="alpha beta gamma "):
    text = words * 20
    units = [{"heading": heading, "level": 1, "path": heading, "page_start": 1, "page_end": 1,
              "paragraphs": [{"page": 1, "text": text}], "text": text}]
    pipeline.save_material(name, 1, units, "pdf", course=course)


# ---------------- 1. a course can be created empty, with settings ----------------
c = library.create_course("  UPSC   Polity ", "CDS exam preparation", "Explain simply")
assert c["course"] == "UPSC Polity" and c["docs"] == [] and c["description"] == "CDS exam preparation" and c["instructions"] == "Explain simply"
assert [x["course"] for x in library.courses()] == ["UPSC Polity"]
for bad in ("", "   ", "upsc polity"):
    try:
        library.create_course(bad)
        raise SystemExit("should have raised")
    except ValueError:
        pass
print("1: empty course created, names checked ok")

# ---------------- 2. material is added INTO a course; a course may mix subjects ----------------
make("polity.pdf", "Fundamental Rights", "UPSC Polity")
make("history.pdf", "The Revolt of 1857", "UPSC Polity")                     # another subject in the same course
make("physics.pdf", "Coulomb Law", "Semester 1") if False else None
library.create_course("Semester 1")
make("physics.pdf", "Coulomb Law", "Semester 1")
cs = {x["course"]: x for x in library.courses()}
assert set(cs["UPSC Polity"]["docs"]) == {"polity.pdf", "history.pdf"} and cs["Semester 1"]["docs"] == ["physics.pdf"]
assert library.docs_in("UPSC Polity") and library.docs_in("nope") is None and library.docs_in(None) is None
assert library.course_of("physics.pdf") == "Semester 1"
print("2: material lives inside courses ok")

# ---------------- 3. an implicit (file-named) course disappears with its last file; yours stays ----------------
make("solo notes.pdf", "Notes", None)
assert "solo notes" in {x["course"] for x in library.courses()}
library.delete_material("solo notes.pdf")
assert "solo notes" not in {x["course"] for x in library.courses()}
library.delete_material("physics.pdf")
assert library.get_course("Semester 1") is not None and library.get_course("Semester 1")["docs"] == []     # yours stays, empty
make("physics.pdf", "Coulomb Law", "Semester 1")
print("3: implicit vs explicit courses ok")

# ---------------- 4. settings and rename ----------------
sid_before = library.student_for("UPSC Polity")
r = library.update_course("UPSC Polity", description="new description", instructions="x" * 2000, new_name="UPSC CDS")
assert r["course"] == "UPSC CDS" and r["description"] == "new description" and len(r["instructions"]) == library.MAX_INSTRUCTIONS
assert set(r["docs"]) == {"polity.pdf", "history.pdf"} and library.course_of("polity.pdf") == "UPSC CDS"
assert library.student_for("UPSC CDS") == sid_before, "progress must follow a rename"
assert library.instructions_of("UPSC CDS") == "x" * library.MAX_INSTRUCTIONS and library.instructions_of(None) == ""
try:
    library.update_course("UPSC CDS", new_name="semester 1")
    raise SystemExit("should have raised")
except ValueError:
    pass
print("4: settings and rename ok")

# ---------------- 5. every course has its own progress ----------------
sa, sb = library.student_for("UPSC CDS"), library.student_for("Semester 1")
assert sa != sb and sa.startswith("course-") and library.student_for(None) == learner.DEFAULT_STUDENT
ta = outline.topics(docs=["polity.pdf"])[0]["topic"]
tb = outline.topics(docs=["physics.pdf"])[0]["topic"]
for k in range(3):
    learner.record_answer(sa, ta, 1.0, "medium", "mcq", 100 + k)
learner.record_answer(sb, tb, 0.0, "medium", "mcq", 200)
assert learner.event_count(sa) == 3 and learner.event_count(sb) == 1
assert {s["topic"] for s in learner.all_states(sa, docs=library.docs_in("UPSC CDS")) if s["assessed"]} == {ta}
assert {s["topic"] for s in learner.all_states(sb, docs=library.docs_in("Semester 1")) if s["assessed"]} == {tb}
learner.set_current_student(sa)
assert learner.current_student() == sa and learner.event_count() == 3 and learner.get_profile() is None
seen = {}
t = threading.Thread(target=lambda: seen.update(other=learner.current_student())); t.start(); t.join()
assert seen["other"] == learner.DEFAULT_STUDENT, "another thread (another browser tab) must not see this course"
learner.set_current_student(sb)
assert learner.event_count() == 1
learner.set_profile(sb, "beginner")
assert learner.get_profile()["level"] == "beginner" and learner.get_profile(sa) is None
print("5: separate progress per course, per thread ok")

# ---------------- 6. quiz history import stays inside the course ----------------
conn = store._db()
conn.executescript("""CREATE TABLE IF NOT EXISTS quiz_sets (id INTEGER PRIMARY KEY, kind TEXT, scope TEXT, wanted INTEGER, created REAL, submitted REAL, report TEXT);
CREATE TABLE IF NOT EXISTS quiz_questions (id INTEGER PRIMARY KEY, set_id INTEGER, pos INTEGER, doc TEXT, chunk_id INTEGER, topic TEXT, qtype TEXT, difficulty TEXT, question TEXT);
CREATE TABLE IF NOT EXISTS quiz_answers (question_id INTEGER PRIMARY KEY, set_id INTEGER, answer TEXT, score REAL, feedback TEXT, graded_by TEXT, ts REAL);""")
conn.execute("INSERT INTO quiz_sets (id, kind, scope, wanted, created) VALUES (1,'topic','x',2,1)")
conn.execute("INSERT INTO quiz_questions (id, set_id, pos, doc, topic, qtype, difficulty, question) VALUES (501,1,1,'polity.pdf',?, 'mcq','easy','q1')", (ta,))
conn.execute("INSERT INTO quiz_questions (id, set_id, pos, doc, topic, qtype, difficulty, question) VALUES (502,1,2,'physics.pdf',?, 'mcq','easy','q2')", (tb,))
conn.execute("INSERT INTO quiz_answers VALUES (501,1,'A',1.0,'','code',5000)")
conn.execute("INSERT INTO quiz_answers VALUES (502,1,'A',1.0,'','code',5000)")
conn.commit(); conn.close()
# (no reset here: a reset would deliberately hide older answers)
added = learner.import_quiz_history("fresh", docs=["polity.pdf"])
assert added == 1 and learner.event_count("fresh") == 1, added                   # the physics answer is NOT imported
print("6: history import is course-scoped ok")

# ---------------- 7. moving material takes its progress along ----------------
learner.record_answer(sa, ta, 1.0, "medium", "mcq", 501)                          # an answer on polity.pdf, in course A
learner.record_tutor(sa, [ta])
n_a_before, n_b_before = learner.event_count(sa), learner.event_count(sb)
moved = library.move_material("polity.pdf", "Semester 1")
assert moved == 1 and library.course_of("polity.pdf") == "Semester 1" and set(library.docs_in("UPSC CDS")) == {"history.pdf"}
assert learner.event_count(sa) == n_a_before - 1 and learner.event_count(sb) == n_b_before + 1
assert learner._events(sb, ta) and any(e["source"] == "tutor" for e in learner._events(sb, ta))
assert library.move_material("polity.pdf", "Semester 1") == 0
try:
    library.move_material("polity.pdf", "Nowhere")
    raise SystemExit("should have raised")
except ValueError:
    pass
library.move_material("polity.pdf", "UPSC CDS")                                  # and back
print("7: move ok")

# ---------------- 8. progress saved before courses were separate is adopted once ----------------
library.create_course("Old data")
make("old.pdf", "Old topic", "Old data")
to = outline.topics(docs=["old.pdf"])[0]["topic"]
learner.set_profile(learner.DEFAULT_STUDENT, "advanced", "exam", None)
conn = store._db()
conn.execute("INSERT INTO quiz_questions (id, set_id, pos, doc, topic, qtype, difficulty, question) VALUES (601,1,3,'old.pdf',?, 'mcq','easy','q3')", (to,))
conn.commit(); conn.close()
learner.record_answer(learner.DEFAULT_STUDENT, to, 1.0, "easy", "mcq", 601)
learner.record_answer(learner.DEFAULT_STUDENT, to, 1.0, "easy", "mcq", None)
default_before = learner.event_count(learner.DEFAULT_STUDENT)
got = library.adopt_legacy("Old data")
so = library.student_for("Old data")
assert got == 1 and learner.event_count(so) == 1 and learner.event_count(learner.DEFAULT_STUDENT) == default_before - 1
assert learner.get_profile(so)["level"] == "advanced"                            # the intake is copied
assert library.adopt_legacy("Old data") == 0 and learner.event_count(so) == 1    # once only
assert library.adopt_legacy("Semester 1") >= 0 and library.adopt_legacy(None) == 0
print("8: legacy progress adopted once ok")

# ---------------- 9. deleting a course removes everything in it, and only it ----------------
learner.set_profile(so, "some")
before_other = learner.event_count(sb)
removed = library.delete_course("Old data")
assert removed["materials"] == 1 and library.get_course("Old data") is None
assert "old.pdf" not in [d["file"] for d in store.list_docs()] and learner.event_count(so) == 0 and learner.get_profile(so) is None
assert learner.event_count(sb) == before_other and library.get_course("Semester 1")["docs"] == ["physics.pdf"]
assert library.delete_course("Old data") == {"materials": 0, "quizzes": 0, "answers": 0}
print("9: delete course ok")
# ---------------- 10. a NEW course does not inherit the old shared intake ----------------
learner.set_profile(learner.DEFAULT_STUDENT, "advanced", "exam", None)
library.create_course("Fresh start")
make("fresh.pdf", "Fresh topic", "Fresh start")
sf = library.student_for("Fresh start")
assert library.adopt_legacy("Fresh start") == 0
assert learner.get_profile(sf) is None and learner.needs_intake(sf), "a new course must ask for the intake again"
print("10: new course starts with no intake ok")
print("ALL COURSE TESTS PASSED")
