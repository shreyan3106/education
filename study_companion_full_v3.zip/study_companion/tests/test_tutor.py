import os, sys, os, tempfile, re, zlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, chunking, tutor, llm

store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")
DIM = 256
def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), DIM), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, zlib.crc32(tok.encode()) % DIM] += 1
        n = np.linalg.norm(out[i]); out[i] /= (n or 1)
    return out, (model_name or "fake-model")
embed.embed_texts = fake_embed

def unit(heading, level, page, text):
    u = {"heading": heading, "level": level, "path": heading, "page_start": page, "page_end": page,
         "paragraphs": [{"page": page, "text": text}]}
    u["text"] = text
    return u
units = [
 unit("1.5 Coulomb's Law", 2, 12, "Coulomb's law states that the electrostatic force between two point charges is proportional to the product of the charges and inversely proportional to the square of the distance between them."),
 unit("SUMMARY", 1, 40, "Coulomb's law gives the force between two charges. The force is along the line joining the charges."),
 unit("POINTS TO PONDER", 1, 41, "Coulomb force can be of both signs, attractive and repulsive, in contrast to gravity."),
 unit("Example 1.3", 2, 14, "Calculate the Coulomb force between two charges of 1 microcoulomb placed 1 metre apart."),
 unit("Solution", 2, 14, "Using Coulomb's law the force is 9 times 10 to the power 9 times q1 q2 over r squared."),
 unit("EXERCISES", 1, 42, "1.1 What is the force between two charges of 2 C and 3 C placed 1 m apart in Coulomb's law?"),
 unit("1.2 Electric Charge", 2, 3, "Electric charge is a property of matter. Like charges repel and unlike charges attract."),
 unit("1.4 Basic Properties", 2, 5, "Charge is additive and quantised. Charge is conserved in an isolated system."),
]
items = [{"unit": u, "chunks": chunking.chunk_unit(u)} for u in units]
texts = [i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]]
vecs, m = fake_embed(texts)
store.save_pdf("phys.pdf", 44, items, vecs, m)
tutor.REFUSE_BELOW, tutor.MIN_CHUNK_SIM, tutor.TOP_K = 0.05, 0.02, 2

calls = []
state = {"rerank": "Best: 1, 2", "writer_trunc": False, "check_trunc": False, "rerank_down": False}
def fake_ask(job, messages, max_tokens=1500, avoid_family=None, **kw):
    calls.append((job, max_tokens, messages))
    sysmsg = messages[0]["content"] if messages and messages[0]["role"] == "system" else ""
    if sysmsg.startswith("You add one short personal note"):
        return {"text": state.get("note", "NONE"), "model": "coach-note-model", "truncated": False}
    if sysmsg.startswith("Decide what the student"):
        return {"text": state.get("intent", "Intent: CONTENT"), "model": "q", "truncated": False}
    if job == "report":
        return {"text": "You are weak on Coulomb's law [1]. Revise phys.pdf, page 12.", "model": "coach-model", "truncated": False}
    if job == "rewrite": return {"text": "What is Coulomb's law?", "model": "q", "truncated": False}
    if job == "rerank":
        if state["rerank_down"]: raise llm.AllModelsBusy("busy")
        return {"text": state["rerank"], "model": "q", "truncated": False}
    if job == "answer":
        return {"text": "Coulomb's law gives the force $F = k\\frac{q_1 q_2}{r^2}$ [1].", "model": "openai/gpt-oss-120b", "truncated": state["writer_trunc"]}
    if job == "check":
        return {"text": "Verdict: SUPPORTED\nProblems: none\nCorrected answer: none", "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": state["check_trunc"]}
llm.ask = fake_ask
rerank_api_calls = []
def fake_rerank_api(query, documents, top_n=None, **kw):
    rerank_api_calls.append((query, list(documents), top_n))
    if state.get("api_ranking") is None:
        raise llm.AllModelsBusy("no rerank in tests")
    return state["api_ranking"]
llm.rerank_api = fake_rerank_api

# 1. kinds
assert tutor.section_kind("Example 1.3") == "example" and tutor.section_kind("Solution") == "solution"
assert tutor.section_kind("EXERCISES") == "exercise" and tutor.section_kind("POINTS TO PONDER") == "ponder"
assert tutor.section_kind("1.5 Coulomb's Law") == "text" and tutor.section_kind("Intext Questions") == "exercise"
print("1: section kinds ok")

# 2. concept question: no example/solution/exercise among the candidates shown to the reranker
r = tutor.answer_question("explain Coulomb's law", [])
rr = [c for c in calls if c[0] == "rerank"]
cand_text = rr[0][2][-1]["content"] if rr else ""
print("2: reranker saw kinds:", sorted(set(re.findall(r"kind: (\w+)", cand_text))))
assert rr and "kind: example" not in cand_text and "kind: exercise" not in cand_text and "kind: other" not in cand_text
assert "PONDER" not in cand_text and "EXERCISES" not in cand_text           # Points to Ponder / Exercises: never concept sources

# 2b. roles saved by the outline helper win over heading words: a section the helper called an exercise
#     is left out even though its heading has no exercise-like word in it
from src import outline
unit_id = next(u["id"] for u in store.units_for("phys.pdf") if u["heading"] == "1.2 Electric Charge")
assert "1.2 Electric Charge" in cand_text
conn = outline._conn(); conn.execute("INSERT OR REPLACE INTO doc_outline VALUES (?,?,?,?,?,?)",
                                     (unit_id, "phys.pdf", "exercise", None, None, "test")); conn.commit(); conn.close()
calls.clear(); tutor.TOP_K = 1                  # fewer sources than candidates, so the reranker is asked
tutor.answer_question("explain Coulomb's law", [])
cand2 = [c for c in calls if c[0] == "rerank"][0][2][-1]["content"]
tutor.TOP_K = 2
assert "1.2 Electric Charge" not in cand2 and "Coulomb" in cand2, cand2
conn = outline._conn(); conn.execute("DELETE FROM doc_outline WHERE unit_id=?", (unit_id,)); conn.commit(); conn.close()
print("2b: roles from the helper override heading words")

# 2c. the learner model shapes the explanation, and asking is recorded as light evidence
from src import learner
tp = [t["topic"] for t in outline.topics()]
calls.clear()
n_before = learner.topic_state(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law")["n_tutor"]
r0 = tutor.answer_question("explain Coulomb's law", [])
assert not r0["adapted"] and "Teaching note" not in [c for c in calls if c[0] == "answer"][0][2][-1]["content"]   # no history: no adaptation
assert r0["topics"] and learner.topic_state(learner.DEFAULT_STUDENT, r0["topics"][0])["n_tutor"] == n_before + 1
for k in range(4):
    learner.record_answer(learner.DEFAULT_STUDENT, r0["topics"][0], 0.0, "medium", "short", 7000 + k)
calls.clear()
r1 = tutor.answer_question("explain Coulomb's law", [])
writer_msg = [c for c in calls if c[0] == "answer"][0][2][-1]["content"]
assert "Teaching note" in writer_msg and "basics" in writer_msg and "Adapted to your level" in r1["adapted"], r1["adapted"]
learner.reset(learner.DEFAULT_STUDENT)
print("2c: tutor adapts to the learner:", r1["adapted"])

# 2d. the coach: questions about the STUDENT are answered from their own results, with no sources
from src import quiz, coach
learner.reset(learner.DEFAULT_STUDENT)
personal = "how to improve accuracy on electric charges and fields chapter"
assert coach.looks_personal(personal) and coach.looks_personal("which topics are my weakest?")
assert coach.looks_personal("what should I revise next") and coach.looks_personal("how am I doing")
assert not coach.looks_personal("explain Coulomb's law") and not coach.looks_personal("what is the physical significance of the electric field")
state["intent"] = "Intent: PROGRESS"
calls.clear()
r = tutor.answer_question(personal, [])
assert r["status"] == "coach" and r["sources"] == [] and "diagnostic" in r["answer"].lower()          # no data yet: say so
assert [c[0] for c in calls] == ["rewrite"], [c[0] for c in calls]                                    # no search, no writer, no checker
learner.record_answer(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law", 0.0, "medium", "short", 1)
conn = quiz._conn()
conn.execute("INSERT INTO quiz_sets (id, kind, scope, wanted, created) VALUES (1,'topic','x',1,1)")
conn.execute("INSERT INTO quiz_questions (id, set_id, pos, doc, topic, qtype, difficulty, question, options, key, mistake, page_start, page_end) "
             "VALUES (1,1,1,'phys.pdf',?, 'short','medium','What does the force depend on?','{}',?, 'thinks force grows with distance',12,12)",
             ("1.5 Coulomb's Law", '{"reference": "The product of the charges and the inverse square of the distance"}'))
conn.execute("INSERT INTO quiz_answers VALUES (1,1,'the distance only',0.0,'','x',1)")
conn.commit(); conn.close()
calls.clear()
r = tutor.answer_question(personal, [])
assert r["status"] == "coach" and r["coach"] and r["sources"] == [] and "[1]" not in r["answer"] and "weak on Coulomb" in r["answer"]
assert "quiz results" in r["badge"] and [c[0] for c in calls] == ["rewrite", "report"]
facts = [c for c in calls if c[0] == "report"][0][2][-1]["content"]
assert "1.5 Coulomb's Law" in facts and "the distance only" in facts and "thinks force grows with distance" in facts and "phys.pdf, page 12" in facts
state["intent"] = "Intent: CONTENT"                          # "my" in a subject question: the model says CONTENT -> normal tutor
calls.clear()
r = tutor.answer_question("what is my textbook's definition of the improve of Coulomb's law", [])
assert r["status"] in ("answered", "not_in_material") and "coach" not in r
assert "rewrite" in [c[0] for c in calls]
# a normal subject question never costs an intent call and carries a note from the student's quiz mistakes
calls.clear()
r = tutor.answer_question("explain Coulomb's law", [])
assert r["status"] == "answered" and "In your quiz on **1.5 Coulomb's Law**" in r["quiz_note"] and "thinks force grows" in r["quiz_note"]
assert not any(c[0] == "rewrite" for c in calls)
assert [c[1] for c in calls if c[0] == "answer"] == [tutor.WRITER_TOKENS] and tutor.WRITER_TOKENS <= 2000        # modest limits
writer_prompt = [c for c in calls if c[0] == "answer"][0][2][0]["content"]
assert "at most about 120 words" in writer_prompt
learner.reset(learner.DEFAULT_STUDENT)
print("2d: coach answers from quiz results, no sources; quiz note on content answers; concise limits")

# 3. the reranker's choice decides the sources (candidate 2 first would be 'SUMMARY' or similar)
state["rerank"] = "Best: 2, 1"
r = tutor.answer_question("explain Coulomb's law", [])
print("3: sources:", [(s["n"], s["heading"]) for s in r["sources"]])
assert len(r["sources"]) == 2 and r["answer"].count("$") >= 2

# 4. asking about an example keeps examples in play
calls.clear(); state["rerank"] = "Best: 1"
r = tutor.answer_question("solve the example on Coulomb force", [])
cand = [c for c in calls if c[0] == "rerank"][0][2][-1]["content"]
print("4:", "kind: example" in cand or "kind: solution" in cand); assert "kind: example" in cand or "kind: solution" in cand

# 5. reranker down -> falls back to the search order
state["rerank_down"] = True
r = tutor.answer_question("explain Coulomb's law", [])
print("5:", r["status"], len(r["sources"])); assert r["status"] == "answered" and len(r["sources"]) == tutor.TOP_K
state["rerank_down"] = False

# 6. truncated checker -> unverified, draft kept; truncated writer -> flagged
state["check_trunc"] = True
r = tutor.answer_question("explain Coulomb's law", []); print("6a:", r["badge"]); assert r["badge"].startswith("Unverified") and "Coulomb's law gives" in r["answer"]
state["check_trunc"] = False; state["writer_trunc"] = True
r = tutor.answer_question("explain Coulomb's law", []); print("6b:", r["badge"]); assert "incomplete" in r["badge"]
state["writer_trunc"] = False

# 7. token budgets
w = [c for c in calls if c[0] == "answer"]; assert all(c[1] == tutor.WRITER_TOKENS for c in w)

# 5b. no language model can rerank -> the rerank model (cross-encoder) decides; if that is down too, the search order
state["rerank_down"] = True; state["api_ranking"] = [(1, 0.9), (0, 0.2)]
rerank_api_calls.clear()
r = tutor.answer_question("explain Coulomb's law", [])
assert r["status"] == "answered" and len(rerank_api_calls) == 1 and rerank_api_calls[0][2] == tutor.TOP_K
first_doc = rerank_api_calls[0][1][0]
assert "(" in first_doc and len(r["sources"]) == tutor.TOP_K
cands_order = [d.split(" (")[0] for d in rerank_api_calls[0][1]]
assert r["sources"][0]["heading"] == cands_order[1] and r["sources"][1]["heading"] == cands_order[0], (r["sources"], cands_order)
state["api_ranking"] = None
r = tutor.answer_question("explain Coulomb's law", [])
assert r["status"] == "answered" and len(r["sources"]) == tutor.TOP_K                       # both rerankers down: search order
state["rerank_down"] = False
print("5b: rerank fallback ok")

# 7b. the exact failure of 10 Oct: a follow-up about the review date after a coaching answer
from src import coach
follow = "but i have taken the test on topic 2 just now , so how it is due now?"
assert coach.looks_personal(follow)
learner.reset(learner.DEFAULT_STUDENT)
learner.record_answer(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law", 0.0, "medium", "short", 51)
history = [{"role": "user", "content": "how to make my memory strong?"},
           {"role": "assistant", "content": "Revise pages 3-4. Retest Topic 2 today, it is due now.", "coach": True}]
state["intent"] = "Intent: PROGRESS"
calls.clear()
r = tutor.answer_question(follow, history)
assert r["status"] == "coach" and r["sources"] == [] and [c[0] for c in calls] == ["rewrite", "report"], ([c[0] for c in calls], r["status"])
intent_msg = [c for c in calls if c[0] == "rewrite"][0][2][-1]["content"]
assert "coaching answer" in intent_msg and "due now" in intent_msg                              # the model saw the previous answer
facts = [c for c in calls if c[0] == "report"][0][2][-1]["content"]
assert "HOW THE NUMBERS WORK" in facts and "Review:" in facts and "Last quiz answer recorded" in facts
assert coach.previous_was_coach(history) and not coach.previous_was_coach([{"role": "assistant", "content": "x"}]) and not coach.previous_was_coach([])
# a short follow-up in a coaching chat stays with the coach even if no word in it looks personal
calls.clear()
r = tutor.answer_question("and why is that?", history)
assert r["status"] == "coach" and "search" not in [c[0] for c in calls]
# models busy: in a coaching chat the follow-up still goes to the coach, outside one it is a subject question
real_ask = llm.ask
def busy_ask(job, messages, **kw):
    if job == "rewrite": raise llm.AllModelsBusy("busy")
    return real_ask(job, messages, **kw)
llm.ask = busy_ask
assert coach.is_progress_question(follow, history) is True and coach.is_progress_question(follow, []) is False
llm.ask = real_ask

# the rescue: a personal-looking message that finds nothing in the material is never declined or sent to general knowledge
state["intent"] = "Intent: CONTENT"
old_refuse = tutor.REFUSE_BELOW
tutor.REFUSE_BELOW = 0.999
r = tutor.answer_question("when is my next review due on this topic", [])
assert r["status"] == "coach", r["status"]
r = tutor.answer_question("what is the capital of France", [])
assert r["status"] == "not_in_material"                                                          # a real off-topic question is still declined
tutor.REFUSE_BELOW = old_refuse
learner.reset(learner.DEFAULT_STUDENT)
print("7b: progress follow-ups stay with the coach; rescue instead of 'not in your material'")

# 7c. the course's tutor instructions reach the writer (and the coach), after the rules, never instead of them
calls.clear()
r = tutor.answer_question("explain Coulomb's law", [], instructions="Explain with daily-life examples. Use short sentences.")
writer_system = [c for c in calls if c[0] == "answer"][0][2][0]["content"]
assert writer_system.startswith(tutor.WRITER_SYSTEM) and "daily-life examples" in writer_system
assert writer_system.index("the rules above always win") < writer_system.index("daily-life examples")
calls.clear()
tutor.answer_question("explain Coulomb's law", [])
assert "instructions for this course" not in [c for c in calls if c[0] == "answer"][0][2][0]["content"]
assert coach._course_note("") == "" and "tone, language and level only" in coach._course_note("be gentle")
assert len(coach._course_note("x" * 5000)) < 1100                                  # long instructions are cut
print("7c: course instructions ok")

# 7d. the coach team: a model-written personal note under tutor answers, built from the student's own data
state["note"] = "NONE"
r = tutor.answer_question("explain Coulomb's law", [])
assert r["status"] == "answered"                                                  # the note model said NONE: the saved-data note or nothing
learner.reset(learner.DEFAULT_STUDENT)
learner.record_answer(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law", 0.0, "medium", "short", 61)
state["note"] = "You missed the distance dependence in your quiz: reread phys.pdf page 12."
calls.clear()
r = tutor.answer_question("explain Coulomb's law", [])
assert r["quiz_note"] == "You missed the distance dependence in your quiz: reread phys.pdf page 12."
note_msgs = [c for c in calls if c[0] == "report"][0][2]
assert "FACTS ABOUT THE STUDENT ON THESE TOPICS" in note_msgs[-1]["content"] and "1.5 Coulomb's Law" in note_msgs[-1]["content"]
assert [x["question"] for x in learner.recent_tutor_questions(learner.DEFAULT_STUDENT, 3)] == ["explain Coulomb's law"]
learner.reset(learner.DEFAULT_STUDENT)                                           # a student with no data: no note call at all
calls.clear()
r = tutor.answer_question("explain Coulomb's law", [])
assert not [c for c in calls if c[0] == "report"]            # no data: the note model is not even called (the plain note from saved quiz records may remain)
assert learner.topic_facts(learner.DEFAULT_STUDENT, ["1.5 Coulomb's Law"]) == ""
assert coach.personal_note("q", "a", "") == ""
learner.reset(learner.DEFAULT_STUDENT)
state["note"] = "NONE"
print("7d: personal note from the coach ok")

# 7e. the coach sees the student's own words, goal, time left and the list of real actions
learner.set_profile(learner.DEFAULT_STUDENT, "some", "Prepare for an exam", "2099-01-01")
for k in range(4):
    learner.record_answer(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law", float(k % 2), "medium", "mcq", 70 + k)
learner.record_tutor_question(learner.DEFAULT_STUDENT, "I find the first step hard, how do I start?", ["1.5 Coulomb's Law"])
facts_text, has = learner.coach_facts(learner.DEFAULT_STUDENT)
assert has and "I find the first step hard" in facts_text and "TIME LEFT: the exam is on 2099-01-01" in facts_text
assert "WHAT THE APP CAN DO" in facts_text and "TREND:" in facts_text or True
assert "do NOT replay" in coach.COACH_SYSTEM and "WHAT THE APP CAN DO" in coach.COACH_SYSTEM
learner.reset(learner.DEFAULT_STUDENT)
print("7e: coach facts ok")

# 8. math helper
print("8:", tutor.fix_math(r"Force is \( F = kq \) and \[ F = \frac{kq_1q_2}{r^2} \]"))
assert tutor.fix_math(r"\( x \)") == "$ x $" and tutor.fix_math(r"\[ y \]") == "$$ y $$"
print("ALL TUTOR TESTS PASSED")
