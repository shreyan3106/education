"""Tests for src/outline.py with a fake helper model: no internet or keys needed.
Two documents in very different styles prove that nothing depends on one book."""
import os, sys, tempfile, re, hashlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, chunking, llm, outline

store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")


def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), 64), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
        out[i] /= (np.linalg.norm(out[i]) or 1)
    return out, "fake-model"
embed.embed_texts = fake_embed


def unit(heading, level, page, text):
    u = {"heading": heading, "level": level, "path": heading, "page_start": page, "page_end": page,
         "paragraphs": [{"page": page, "text": text}]}
    u["text"] = text
    return u


def save(name, specs):
    units = [unit(h, lv, 1 + i, f"{h} " + "words about it " * 12) for i, (h, lv) in enumerate(specs)]
    items = [{"unit": u, "chunks": chunking.chunk_unit(u)} for u in units]
    vecs, m = fake_embed([i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]])
    store.save_pdf(name, 50, items, vecs, m)
    return store.units_for(name)


# physics-style: numbered sections
PHYS = [("ELECTRIC CHARGES AND FIELDS", 1), ("1.1 Introduction", 2), ("1.2 Electric Charge", 2),
        ("1.3 Conductors and Insulators", 2), ("1.4 Coulomb's Law", 2), ("Example 1.1", 2), ("Solution", 3),
        ("1.5 Electric Field", 2), ("1.5.1 Field lines", 3), ("SUMMARY", 1), ("POINTS TO PONDER", 1), ("EXERCISES", 1)]
# history-style: no numbers, different words
HIST = [("The Roman Republic", 1), ("Early Settlements", 2), ("The Seven Kings", 2), ("Life in the Village", 3),
        ("Rise of the Republic", 2), ("Case Study: The Punic Wars", 2), ("Fall of the Republic", 2),
        ("Chapter Summary", 1), ("Review Questions", 1)]
phys, hist = save("physics.pdf", PHYS), save("history.pdf", HIST)

# ---------------- 1. rules only (no model): style-agnostic ----------------
r = outline.rules_outline(phys, "physics.pdf")
roles = {u["heading"]: r[u["id"]] for u in phys}
assert roles["ELECTRIC CHARGES AND FIELDS"][0] == "title" and roles["1.2 Electric Charge"] == ("section", "1.2 Electric Charge")
assert roles["Example 1.1"] == ("example", "1.4 Coulomb's Law") and roles["Solution"] == ("example", "1.4 Coulomb's Law")
assert roles["1.5.1 Field lines"] == ("subsection", "1.5 Electric Field")
assert roles["SUMMARY"] == ("summary", None) and roles["POINTS TO PONDER"][0] == "exercise" and roles["EXERCISES"][0] == "exercise"
h = outline.rules_outline(hist, "history.pdf")
hroles = {u["heading"]: h[u["id"]] for u in hist}
assert hroles["The Roman Republic"][0] == "title" and hroles["Early Settlements"] == ("section", "Early Settlements")
assert hroles["Life in the Village"] == ("subsection", "The Seven Kings")
assert hroles["Case Study: The Punic Wars"] == ("example", "Rise of the Republic")
assert hroles["Chapter Summary"] == ("summary", None) and hroles["Review Questions"] == ("exercise", None)
print("1: rules sort both a numbered physics chapter and an unnumbered history chapter")

# a document with no usable headings at all
flat = save("flat.pdf", [("(before first heading)", 0)])
assert outline.rules_outline(flat, "flat.pdf")[flat[0]["id"]] == ("section", "flat")

# ---------------- 2. reading the helper's reply ----------------
ids = {1, 2, 3, 4}
text = """Here you go:
Topics:
T1 = **Early settlements**
T2: Kings and the village
Units:
1 | title | -
- 2 | Section | T1
**3 | subsection | T2**
4 | exercise | T2
99 | section | T1
5 | nonsense | T1
"""
topics, rows = outline.parse_outline(text, ids)
assert topics == {1: "Early settlements", 2: "Kings and the village"}, topics
assert rows == {1: ("title", None), 2: ("section", 1), 3: ("subsection", 2), 4: ("exercise", 2)}, rows
print("2: helper reply parsing ok")

# ---------------- 3. the helper model sorts a document (windows of 4 units) ----------------
outline.WINDOW = 4
calls, state = [], {"busy": False, "garbage": False}


def fake_ask(job, messages, max_tokens=1500, **kw):
    calls.append(job)
    assert job == "outline" and messages[0]["content"].startswith("You sort the structure")
    if state["busy"]:
        raise llm.AllModelsBusy("busy")
    user = messages[-1]["content"]
    if state["garbage"]:
        return {"text": "I cannot do that.", "model": "m1", "truncated": False}
    lines = [l for l in user.split("Units:\n")[1].splitlines()]
    heads = {int(l.split(" | ")[0]): l.split(" | ")[4] for l in lines}
    out, topics = ["Topics:"], []
    body = ["Units:"]
    for uid, head in heads.items():
        hl = head.lower()
        if hl in ("the roman republic",):
            body.append(f"{uid} | title | -")
        elif "summary" in hl or "review" in hl or "exercise" in hl:
            body.append(f"{uid} | {'summary' if 'summary' in hl else 'exercise'} | -")
        else:
            name = ("Origins of Rome" if hl in ("early settlements", "the seven kings", "life in the village")
                    else "The Republic")
            if name not in topics:
                topics.append(name)
            role = "example" if "case study" in hl else "subsection" if "village" in hl else "section"
            body.append(f"{uid} | {role} | T{topics.index(name) + 1}")
    out += [f"T{i + 1} = {t}" for i, t in enumerate(topics)]
    return {"text": "\n".join(out + body), "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": False}
llm.ask = fake_ask

note = outline.build("history.pdf")
assert note == "" and len(calls) == 3, (note, calls)                 # 9 units in windows of 4 -> 3 calls
t = [x for x in outline.topics() if x["doc"] == "history.pdf"]
assert [x["topic"] for x in t] == ["Origins of Rome", "The Republic"], [x["topic"] for x in t]   # same name reused across windows
roles_db = outline.load_roles()
by_head = {u["heading"]: roles_db[u["id"]] for u in hist}
assert by_head["Case Study: The Punic Wars"] == "example" and by_head["Chapter Summary"] == "summary"
assert outline.source_of("history.pdf") == "nvidia/nemotron-3-super-120b-a12b"
tab = outline.table("history.pdf")
assert tab[0]["Role"] == "Title" and tab[0]["Topic"] == "" and tab[1]["Heading"].startswith("· ") and tab[1]["Topic"] == "Origins of Rome"
assert outline.build("history.pdf") == "" and len(calls) == 3         # already sorted by a model: nothing repeated
print("3: helper sorts in windows, topic names reused, table ready:", [x["topic"] for x in t])

# ---------------- 4. validation: exercises never keep a topic; forgotten sections get their own ----------------
exercise = next(u for u in hist if u["heading"] == "Review Questions")
assert outline.table("history.pdf")[-1]["Topic"] == "" and roles_db[exercise["id"]] == "exercise"
print("4: no topic on exercises ok")

# ---------------- 5. no model / unreadable reply -> rules, with a note ----------------
state["busy"] = True
note = outline.build("physics.pdf", force=True)
assert "sorted by simple rules" in note and outline.source_of("physics.pdf") == "rules"
assert [x["topic"] for x in outline.topics() if x["doc"] == "physics.pdf"] == [
    "1.1 Introduction", "1.2 Electric Charge", "1.3 Conductors and Insulators", "1.4 Coulomb's Law", "1.5 Electric Field"]
state["busy"] = False; state["garbage"] = True
note = outline.build("physics.pdf", force=True)
assert "sorted by simple rules" in note
state["garbage"] = False
print("5: model busy or unreadable -> rules used:", note[:60])

# a document sorted only by rules is sorted by the model next time (no force needed)
before = len(calls)
note = outline.build("physics.pdf")
assert len(calls) > before and outline.source_of("physics.pdf").startswith("nvidia/")
print("   rules-only document re-sorted by the model without force")

# ---------------- 5b. debris headings (formula pieces) are fragments, never topics ----------------
JUNK = [("Electric Charges and Fields", 1), ("1.1 Introduction", 2), ("2 1 2 q q F k", 2), ("1 2 2 1 4", 3),
        ("0 = 8.854 x 10-12 C2 N-1m-2", 3), ("Coulomb's Law", 2), ("i i", 3), ("1 2 1 0", 3), ("Summary", 1)]
junk = save("junk.pdf", JUNK)
assert [outline.looks_like_fragment(h) for h, _ in JUNK] == [False, False, True, True, True, False, True, True, False]
assert outline.looks_like_fragment("Electric Dipole Field") is False and outline.looks_like_fragment("") is True
jr = outline.rules_outline(junk, "junk.pdf")
jroles = {u["heading"]: jr[u["id"]] for u in junk}
assert jroles["2 1 2 q q F k"] == ("fragment", "1.1 Introduction") and jroles["1 2 1 0"] == ("fragment", "Coulomb's Law")
assert jroles["Coulomb's Law"] == ("section", "Coulomb's Law")
# the helper model is told which lines are suspect, and even if it calls debris a section the code does not believe it
seen_lines = []
real_fake = llm.ask


def junk_ask(job, messages, **kw):
    user = messages[-1]["content"]
    seen_lines.extend(l for l in user.split("Units:\n")[1].splitlines())
    rows = []
    for l in user.split("Units:\n")[1].splitlines():
        uid, head = int(l.split(" | ")[0]), l.split(" | ")[4]
        rows.append(f"{uid} | section | T1" if "suspect" in head else f"{uid} | section | T2")
    return {"text": "Topics:\nT1 = 2 1 2 q q F k\nT2 = Real topic\nUnits:\n" + "\n".join(rows), "model": "m9", "truncated": False}


llm.ask = junk_ask
outline.build("junk.pdf", force=True)
llm.ask = real_fake
assert sum("[suspect]" in l for l in seen_lines) == 5, [l for l in seen_lines if "suspect" in l]
jt = [x["topic"] for x in outline.topics() if x["doc"] == "junk.pdf"]
assert jt and all(not outline.looks_like_fragment(t) for t in jt), jt             # no garbled topic name survives
jroles_db = outline.load_roles()
assert {jroles_db[u["id"]] for u in junk if u["heading"] in ("2 1 2 q q F k", "i i")} == {"fragment"}
assert outline.kind_of({"unit_id": [u["id"] for u in junk if u["heading"] == "i i"][0], "heading": "i i"}, jroles_db) == "text"
print("5b: debris headings become fragments, topics are real words:", jt)

# a document opened by 'docs' only lists its own topics
assert {x["doc"] for x in outline.topics(docs=["junk.pdf"])} == {"junk.pdf"}

# ---------------- 6. what the tutor and quiz read ----------------
roles_db = outline.load_roles()
chunk = {"unit_id": hist[5]["id"], "heading": "Case Study: The Punic Wars"}
assert outline.kind_of(chunk, roles_db) == "example"
assert outline.kind_of({"unit_id": 10 ** 9, "heading": "EXERCISES"}, roles_db) == "exercise"      # unknown unit -> word rules
assert outline.kind_of({"unit_id": 10 ** 9, "heading": "Plain heading"}, roles_db) == "text"
tp = outline.topics()
assert all(x["unit_ids"] and x["page_start"] <= x["page_end"] for x in tp)
# an old document without any outline is sorted by rules on the spot
# drop its rows and ask again
conn = outline._conn(); conn.execute("DELETE FROM doc_outline WHERE doc='flat.pdf'"); conn.commit(); conn.close()
assert [x["topic"] for x in outline.topics() if x["doc"] == "flat.pdf"] == ["flat"]
print("6: kinds and topics for tutor and quiz ok")
# ---------------- 7. front matter and tiny pages are not topics ----------------
assert outline.looks_like_front_matter("Gifted with Blessings by Deshraj Sir to Future Defence Officers")
assert outline.looks_like_front_matter("Dedication") and outline.looks_like_front_matter("Message from the author")
assert not outline.looks_like_front_matter("1. Historical Background, Constituent Assembly & Preamble (1-25)")
assert not outline.looks_like_front_matter("Introduction") and not outline.looks_like_front_matter("Union Executive")
polity = save("polity.pdf", [("Gifted with Blessings by Deshraj Sir to Future Defence Officers", 2),
                            ("1. Historical Background", 2), ("2. Citizenship and Fundamental Rights", 2), ("A tiny page", 2)])
tiny = next(u for u in polity if u["heading"] == "A tiny page")
conn = store._db(); conn.execute("UPDATE pdf_units SET text='just a few words' WHERE id=?", (tiny["id"],)); conn.commit(); conn.close()
outline.ensure_rules("polity.pdf")
names = [x["topic"] for x in outline.topics() if x["doc"] == "polity.pdf"]
assert names == ["1. Historical Background", "2. Citizenship and Fundamental Rights"], names
print("7: title pages and tiny pages are not topics:", names)
# ---------------- 8. the model decides what KIND of document it is; a practice sheet is filed under one heading ----------------
assert outline.parse_kind("Kind: PRACTICE\nTopics:") == "practice" and outline.parse_kind("**Kind:** Mixed") == "mixed"
assert outline.parse_kind("Topics:\nT1 = x") is None and outline.parse_kind("kind = teaching") == "teaching"
sheet = save("sheet.pdf", [("Practice Sheet", 1), ("1. Z", 1), ("2. Z1", 1), ("3. Z4", 1)])
ids = [u["id"] for u in sheet]
real_ask_o = outline.llm.ask
def practice_ask(job, messages, **kw):
    lines = "\n".join(f"{i} | exercise | -" for i in ids)
    return {"text": "Kind: PRACTICE\nTopics:\nUnits:\n" + lines, "model": "helper-x", "truncated": False}
outline.llm.ask = practice_ask
note = outline.build("sheet.pdf", force=True)
assert "practice document" in note and "Practice questions" in note and "No helper model" not in note, note
assert outline.doc_kind("sheet.pdf") == "practice"
assert [x for x in outline.topics() if x["doc"] == "sheet.pdf"] == []                       # no quiz topics from a question list
tbl = outline.table("sheet.pdf")
assert {r["Topic"] for r in tbl} == {"Practice questions"} and {r["Role"] for r in tbl} == {"Exercise"}
# the helper answered but found no teaching sections (not marked practice): an honest message, not "no helper model"
def no_topic_ask(job, messages, **kw):
    lines = "\n".join(f"{i} | other | -" for i in ids)
    return {"text": "Kind: TEACHING\nTopics:\nUnits:\n" + lines, "model": "helper-x", "truncated": False}
outline.llm.ask = no_topic_ask
note = outline.build("sheet.pdf", force=True)
assert "answered but found no teaching sections" in note and "No helper model" not in note, note
# nothing answered: the true reason
def busy_ask(job, messages, **kw):
    raise outline.llm.AllModelsBusy("all resting")
outline.llm.ask = busy_ask
note = outline.build("sheet.pdf", force=True)
assert note.startswith("No helper model answered"), note
outline.llm.ask = real_ask_o
print("8: document kind decided by the model, practice sheet under one heading, honest messages ok")
print("ALL OUTLINE TESTS PASSED")
