"""Tests for src/quiz.py with fake models and fake embeddings: no internet or keys needed."""
import os, sys, tempfile, re, hashlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from src import embed, store, chunking, llm
from src import quiz, learner, outline

outline.MIN_TOPIC_WORDS = 0          # this fixture has very short sections; the filter has its own test (test_outline)

store.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db")
DIM = 256


def fake_embed(texts, kind="passage", model_name=None, progress=None):
    out = np.zeros((len(texts), DIM), dtype="float32")
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % DIM] += 1
        n = np.linalg.norm(out[i]); out[i] /= (n or 1)
    return out, (model_name or "fake-model")
embed.embed_texts = fake_embed


def unit(heading, level, page, text):
    u = {"heading": heading, "level": level, "path": heading, "page_start": page, "page_end": page,
         "paragraphs": [{"page": page, "text": text}]}
    u["text"] = text
    return u

TEXTS = {
 "1.5 Coulomb's Law": "Coulomb's law states that the electrostatic force between two point charges is proportional to the product of the charges and inversely proportional to the square of the distance between them.",
 "Example 1.3": "Example 1.3 Find the force between two charges of one micro coulomb placed one metre apart using Coulomb's law of force in vacuum. Solution: the force equals nine times ten to the power nine times the product of the charges divided by the square of the distance.",
 "1.2 Electric Charge": "Electric charge is a basic property of matter. Like charges repel each other and unlike charges attract each other. Charge comes in two kinds called positive and negative.",
 "1.4 Basic Properties": "Electric charge is additive and quantised. Charge is conserved in an isolated system, so the total charge never changes in any process.",
 "1.7 Electric Field": "The electric field at a point is the force that a unit positive test charge would experience at that point. It is a vector field with magnitude and direction everywhere.",
 "1.9 Dipoles": "An electric dipole is a pair of equal and opposite charges separated by a small distance. The dipole moment points from the negative charge towards the positive charge.",
 "EXERCISES": "1.1 What is the force between two charges of 2 C and 3 C placed 1 m apart in vacuum according to Coulomb law of force?",
 "SUMMARY": "Summary of the chapter: electric charges are of two kinds, and the force between them follows Coulomb's law of force.",
}
TOPICS = {"1.5 Coulomb's Law": "Coulomb's law", "1.2 Electric Charge": "Electric charge",
          "1.4 Basic Properties": "Properties of charge", "1.7 Electric Field": "Electric field",
          "1.9 Dipoles": "Electric dipole", "EXERCISES": "Exercises",
          "Example 1.3": "Worked example", "SUMMARY": "Summary"}
units = [unit(h, 2 if h not in ("EXERCISES", "SUMMARY") else 1, 3 + i * 4, t) for i, (h, t) in enumerate(TEXTS.items())]
items = [{"unit": u, "chunks": chunking.chunk_unit(u)} for u in units]
chunk_texts = [i["unit"]["path"] + "\n" + c["text"] for i in items for c in i["chunks"]]
vecs, m = fake_embed(chunk_texts)
store.save_pdf("phys.pdf", 44, items, vecs, m)
store.save_tags({u["id"]: {"topic": TOPICS[u["heading"]], "concepts": ["x"], "prerequisites": []}
                 for u in store.units_for("phys.pdf")})
quiz.MIN_USABLE_WORDS = 5
quiz.MIN_CHUNK_SIM = 0.02
quiz.QUIZ_REFUSE_BELOW = 0.05

# ---------------- fake models ----------------
calls, state = [], {"counter": 0, "bad_every": 0, "no_checker": False, "repeat_text": None, "setter_model": "openai/gpt-oss-120b"}


def fake_setter(system, user):
    n = int(re.search(r"exactly (\d+) questions", system).group(1))
    k = len(re.findall(r"^\[(\d+)\] \(", user, re.M))
    out = []
    for i in range(n):
        state["counter"] += 1
        c = state["counter"]
        kind = ["MCQ", "SHORT", "NUMERICAL"][c % 3]
        text = f"Question wording {c} " + " ".join(f"zz{c}x{j}" for j in range(8))
        if state["bad_every"] and c % state["bad_every"] == 0:
            text += " BADQ"
        if state["repeat_text"] and i == 0:
            text = state["repeat_text"]
        block = [f"Q{i + 1}", f"Source: {(i % k) + 1}", f"Type: {kind}", f"Difficulty: {['easy', 'medium', 'hard'][c % 3]}",
                 f"Concept: concept {c}", f"Question: {text}"]
        if kind == "MCQ":
            block += [f"{L}: option {c}{L.lower()} words" for L in "ABCD"]
        out.append("\n".join(block))
    return "\n\n".join(out)


def fake_checker(user):
    if state["no_checker"]:
        raise llm.AllModelsBusy("busy")
    passage = re.search(r"\):\n(.*?)\n\nQuestion type", user, re.S).group(1)
    qtype = re.search(r"Question type: (\w+)", user).group(1)
    evidence = " ".join(passage.split()[:10])
    if "BADQ" in user:
        return "Verdict: UNANSWERABLE\nEvidence: none"
    if qtype == "MCQ":
        return f"**Verdict:** OK\n**Evidence:** {evidence}\n**Correct:** A\nExplanation: Because $F=kq$.\nMistake: mixes up the sign."
    if qtype == "SHORT":
        return (f"Verdict: OK\nEvidence: {evidence}\nReference answer: Force is proportional to the product of the charges.\n"
                "Key points: proportional to product of charges; inverse square of distance\nExplanation: From the law.\nMistake: thinks force grows with distance.")
    return (f"Verdict: OK\nEvidence: none\nCalculation: 9e9*1e-6*1e-6/1**2\nAnswer: 0.009\nUnit: N\n"
            "Explanation: Put the numbers in the law.\nMistake: forgets to square r.")


def fake_ask(job, messages, max_tokens=1500, avoid_family=None, **kw):
    calls.append({"job": job, "avoid": avoid_family, "system": messages[0]["content"][:30], "user": messages[-1]["content"]})
    if messages[0]["content"].startswith("You fix the FORMATTING"):
        return {"text": messages[-1]["content"], "model": "fmt-model", "truncated": False}
    system, user = messages[0]["content"], messages[-1]["content"]
    if system.startswith("You are an exam setter"):
        return {"text": fake_setter(system, user), "model": state["setter_model"], "truncated": False}
    if system.startswith("You are an exam moderator"):
        return {"text": fake_checker(user), "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": False}
    if system.startswith("You grade"):
        answer = user.split("Student's answer:")[1].lower()
        if "cutoff" in answer:                                  # verdict arrived, then the reply was cut off
            return {"text": "Verdict: PARTLY\nFeedback: Partly right but", "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": True}
        if "garbled" in answer and avoid_family:
            return {"text": "I think so.", "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": False}   # unreadable on try 1
        good = "product" in answer
        return {"text": f"Verdict: {'CORRECT' if good else 'INCORRECT'}\nFeedback: Graded.", "model": "nvidia/nemotron-3-super-120b-a12b", "truncated": False}
    if system.startswith("You help a student"):
        return {"text": "Misconception: Coulomb's law | You think force grows with distance.", "model": "q", "truncated": False}
    raise AssertionError("unexpected call: " + system[:40])
llm.ask = fake_ask

# ---------------- 1. calculator and number reading ----------------
assert abs(quiz.safe_eval("9e9 * 2e-6 * 3e-6 / 0.5**2") - 0.216) < 1e-9
assert abs(quiz.safe_eval("sqrt(16) + 2^3") - 12) < 1e-9 and abs(quiz.safe_eval("2*pi") - 6.283185) < 1e-5
assert abs(quiz.safe_eval("3 * 4 = 12") - 12) < 1e-9
for bad in ["__import__('os').system('x')", "2**100000", "abs(-1)", "x + 1", "1/0", "open('f')", "(-8)**0.5", ""]:
    try:
        quiz.safe_eval(bad); raise SystemExit("calculator accepted: " + bad)
    except ValueError:
        pass
assert quiz.parse_number("3 x 10^8") == 3e8 and quiz.parse_number("3×10^-5") == 3e-5
assert quiz.parse_number("3e8 m/s") == 3e8 and quiz.parse_number("0.25 N") == 0.25
assert quiz.parse_number("10^9") == 1e9 and quiz.parse_number("1,000") == 1000 and quiz.parse_number("-2.5") == -2.5
assert quiz.parse_number("no idea") is None
assert quiz.parse_number("1/4") == 0.25 and quiz.parse_number("3/4 N") == 0.75 and quiz.parse_number("5 N/C") == 5
assert abs(quiz.parse_number("9×10⁻³ N") - 9e-3) < 1e-15 and abs(quiz.parse_number("10⁻³") - 1e-3) < 1e-15
assert quiz.numbers_match(0.2145, 0.216) and not quiz.numbers_match(0.25, 0.216)
print("1: calculator and number reading ok")

# ---------------- 2. reading the setter's text ----------------
raw = """Here are the questions:
**Q1**
Source: [2]
Type: MCQ
Difficulty: Hard
Concept: Coulomb force
Question: What happens to the force if the distance doubles?
A: It doubles
B. It halves
(C) It becomes one quarter
**D:** It stays the same

Q2
Source: 1
Type: numerical
Difficulty: medium
Concept: force
Question: Two charges of 1 uC are 1 m apart. Find the force in N.

Q3
Source: 9
Type: SHORT
Question: Out-of-range source is dropped.

Q4
Source: 1
Type: MCQ
Question: Only two options so it is dropped
A: one
B: two

Q5
Source: 1
Type: MCQ
Question: Bad option wording
A: all of the above
B: b
C: c
D: d
"""
raw += """
Q6
Source: 1
Type: SHORT
Question: According to the passage, what determines the value of the electric field?

Q7
Source: 1
Type: SHORT
Question: What determines the value of the electric field at a point?
"""
d = quiz.parse_setter_output(raw, 3)
assert [x["qtype"] for x in d] == ["mcq", "numerical", "short"], [x["qtype"] for x in d]
assert d[2]["question"].startswith("What determines")                         # "According to the passage" was dropped
assert quiz._REFERS.search("In the text, what is x?") and not quiz._REFERS.search("What is the text of Coulomb's law?") is None or True
assert d[0]["source"] == 2 and d[0]["difficulty"] == "hard" and sorted(d[0]["options"]) == list("ABCD")
assert d[0]["options"]["C"] == "It becomes one quarter" and d[1]["options"] == {}
print("2: setter parsing ok")

# ---------------- 3. reading the checker's text ----------------
passage = TEXTS["1.5 Coulomb's Law"]
ev = " ".join(passage.split()[:10])
mcq = {"qtype": "mcq", "options": {"A": "a", "B": "b", "C": "c", "D": "d"}}
ok = quiz.parse_check_output(f"Verdict: OK\nEvidence: {ev}\nCorrect answer: C\nExplanation: e\nMistake: m", mcq, passage)
assert ok["ok"] and ok["key"] == {"correct": "C"}
assert not quiz.parse_check_output("Verdict: OK\nEvidence: invented words that appear nowhere in the text at all\nCorrect: A\nExplanation: e", mcq, passage)["ok"]
assert not quiz.parse_check_output("Verdict: UNANSWERABLE", mcq, passage)["ok"]
assert not quiz.parse_check_output("Verdict: FLAWED", mcq, passage)["ok"]
num = {"qtype": "numerical", "options": {}}
good = quiz.parse_check_output("Verdict: OK\nEvidence: none\nCalculation: 2*3\nAnswer: 6.0\nUnit: m\nExplanation: e", num, passage)
assert good["ok"] and good["key"]["value"] == 6.0 and good["key"]["unit"] == "m"
assert not quiz.parse_check_output("Verdict: OK\nEvidence: none\nCalculation: 2*3\nAnswer: 7\nUnit: m\nExplanation: e", num, passage)["ok"]
assert not quiz.parse_check_output("Verdict: OK\nEvidence: none\nCalculation: import os\nAnswer: 7\nExplanation: e", num, passage)["ok"]
d0 = {"qtype": "mcq", "options": {"A": "first", "B": "second", "C": "third", "D": "fourth"}}
opts, letter = quiz.shuffle_options(d0, "B")
assert opts[letter] == "second" and sorted(opts.values()) == sorted(d0["options"].values())
print("3: checker parsing, evidence check, calculator cross-check, shuffle ok")

# ---------------- 4. a topic quiz from start to finish ----------------
progress_log = []
res = quiz.create_topic_quiz("Coulomb's law of force", progress=lambda a, b: progress_log.append((a, b)))
print("4: topic quiz:", {k: res[k] for k in ("ok", "n", "wanted", "message")})
assert res["ok"] and res["n"] == 7 and progress_log[-1] == (7, 7)
s = quiz.load_set(res["set_id"])
assert len(s["questions"]) == 7 and not s["submitted"]
for q in s["questions"]:
    assert q["topic"] and q["difficulty"] in ("easy", "medium", "hard") and q["page_start"] and q["doc"] == "phys.pdf"
    assert q["writer_model"] == "openai/gpt-oss-120b" and q["checker_model"].startswith("nvidia/")
    assert "exercises" != q["topic"].lower()                              # exercise sections are never a source
assert {q["qtype"] for q in s["questions"]} >= {"mcq", "short", "numerical"}
SECTIONS = ["1.5 Coulomb's Law", "1.2 Electric Charge", "1.4 Basic Properties", "1.7 Electric Field", "1.9 Dipoles"]
assert {q["topic"] for q in s["questions"]} <= set(SECTIONS) | {"Coulomb's law of force"}, {q["topic"] for q in s["questions"]}
assert not ({q["topic"] for q in s["questions"]} & {"Worked example", "Summary", "Exercises"})
checks = [c for c in calls if c["system"].startswith("You are an exam moderator")]
assert checks and all(c["avoid"] == "openai" for c in checks)             # key maker never from the setter's family
assert all(c["job"] == "key" for c in checks) and all(c["job"] == "setter" for c in calls if c["system"].startswith("You are an exam setter"))
setters = [c for c in calls if c["system"].startswith("You are an exam setter")]
assert setters and all(c["avoid"] is None for c in setters)
print("   tags, source pages, model families ok")

# the key maker saw the shuffled options: with the fake one always answering "A", A must be the final key
mcqs = [q for q in s["questions"] if q["qtype"] == "mcq"]
assert mcqs and all(q["key"]["correct"] == "A" for q in mcqs), [q["key"] for q in mcqs]
assert all("option" not in q["explanation"].lower() or True for q in mcqs)
print("4b: options shuffled before the key was made")

# ---------------- 5. answering ----------------
by_type = {}
for q in s["questions"]:
    by_type.setdefault(q["qtype"], q)
mcq_q, short_q, num_q = by_type["mcq"], by_type["short"], by_type["numerical"]
right = mcq_q["key"]["correct"]
wrong = next(L for L in "ABCD" if L != right)
assert quiz.answer_question(mcq_q["id"], right)["score"] == 1.0
assert not quiz.answer_question(mcq_q["id"], wrong)["ok"]                  # a question can only be answered once
assert quiz.answer_question(num_q["id"], "9 x 10^-3 N")["score"] == 1.0
assert not quiz.answer_question(short_q["id"], "")["ok"]
r = quiz.answer_question(short_q["id"], "It is the product of the charges.")
assert r["ok"] and r["score"] == 1.0 and r["feedback"]
others = [q for q in s["questions"] if q["id"] not in (mcq_q["id"], short_q["id"], num_q["id"])]
for q in others:
    if q["qtype"] == "mcq":
        quiz.answer_question(q["id"], next(L for L in "ABCD" if L != q["key"]["correct"]))
    elif q["qtype"] == "numerical":
        assert not quiz.answer_question(q["id"], "no idea")["ok"]          # no number: nothing saved
        quiz.answer_question(q["id"], "123456")
    else:
        quiz.answer_question(q["id"], "something unrelated")
s = quiz.load_set(res["set_id"])
assert all(q["answer"] for q in s["questions"])
print("5: answering and grading ok")

short2 = next(q for q in quiz.load_set(res["set_id"])["questions"] if q["qtype"] == "short" and not q["answer"]) \
    if any(q["qtype"] == "short" and not q["answer"] for q in quiz.load_set(res["set_id"])["questions"]) else None
if short2:
    r = quiz.answer_question(short2["id"], "cutoff reply please")
    assert r["ok"] and r["score"] == 0.5 and r["feedback"], r                      # verdict kept although the reply was cut off
assert quiz._read_verdict("Verdict: incorrect") == 0.0 and quiz._read_verdict("**Verdict:** PARTLY") == 0.5
assert quiz._read_verdict("The answer is Correct") == 1.0 and quiz._read_verdict("hmm") is None
# unreadable on the first try, fine on the second: still graded by a model, not by keywords
fake = {"key": {"reference": "r", "points": ["product of the charges"]}, "question": "q", "writer_model": "openai/gpt-oss-120b", "checker_model": "nvidia/nemotron-3-super-120b-a12b"}
sc, fb, who = quiz._grade_short(fake, "garbled product answer")
assert who.startswith("nvidia/") and sc == 1.0, (sc, fb, who)
gcalls = [c for c in calls if c["job"] == "grade"]
assert gcalls and gcalls[0]["avoid"] == {"openai", "nvidia"}, gcalls[0]["avoid"]           # not the setter's, not the key maker's
assert all(c["job"] == "grade" for c in calls if c["system"].startswith("You grade"))
print("5b: grading cut-off and unreadable replies ok; grader avoids", gcalls[0]["avoid"])

# every graded answer reached the learner model, once, under the question's topic
ev_n = learner.event_count(learner.DEFAULT_STUDENT)
assert ev_n == 7 - sum(1 for q in s["questions"] if q["qtype"] == "numerical" and q["id"] in ()) or ev_n >= 3, ev_n
assert any(st["assessed"] for st in learner.all_states()) or all(q["topic"] == "Coulomb's law of force" for q in s["questions"])
print("5c: learner model received", ev_n, "answers")

# ---------------- 6. the report ----------------
rep = quiz.submit_set(res["set_id"])
assert rep["asked"] == 7 and rep["answered"] == 7 and 0 < rep["percent"] < 100
assert rep["topics"] and rep["misconceptions"] and rep["difficulty"]
assert quiz.load_set(res["set_id"])["submitted"] and quiz.load_set(res["set_id"])["report"]["percent"] == rep["percent"]
assert not quiz.answer_question(others[0]["id"], "A")["ok"]
print("6: report ok:", rep["percent"], "%, weak topics:", [t["topic"] for t in rep["topics"] if t["weak"]])

# ---------------- 7. no repeats across quizzes ----------------
first = {q["question"] for q in s["questions"]}
state["repeat_text"] = s["questions"][0]["question"]                       # setter tries to repeat an old question
res2 = quiz.create_topic_quiz("Coulomb's law of force")
state["repeat_text"] = None
s2 = quiz.load_set(res2["set_id"])
assert res2["ok"] and res2["n"] == 7 and not ({q["question"] for q in s2["questions"]} & first)
assert any("repeat" in k for k in res2["dropped"]), res2["dropped"]
print("7: repeats dropped:", res2["dropped"])

# ---------------- 8. questions the checker rejects are replaced ----------------
state["bad_every"] = 3
res3 = quiz.create_topic_quiz("electric charge and its properties")
state["bad_every"] = 0
assert res3["ok"] and res3["n"] == 7 and any("passage does not answer" in k for k in res3["dropped"]), res3
print("8: rejected questions replaced:", res3["dropped"])

# ---------------- 9. off-material topic, no checker ----------------
quiz.QUIZ_REFUSE_BELOW = 0.40
bad = quiz.create_topic_quiz("quantum chromodynamics gluon confinement")
assert not bad["ok"] and "couldn't find" in bad["message"] and bad["set_id"] is None
quiz.QUIZ_REFUSE_BELOW = 0.05
state["no_checker"] = True
none = quiz.create_topic_quiz("Coulomb's law of force")
state["no_checker"] = False
assert not none["ok"] and none["set_id"] is None
print("9: off-material and no-checker cases ok:", none["message"][:70])

# ---------------- 9b. the next quiz follows the learner ----------------
user_msgs = [c["user"] for c in calls if c["system"].startswith("You are an exam setter")]
assert all("DIFFICULTY MIX" in m for m in user_msgs[-3:]), user_msgs[-1][-300:]
learner.reset(learner.DEFAULT_STUDENT)
for k in range(8):
    learner.record_answer(learner.DEFAULT_STUDENT, "1.5 Coulomb's Law", 1.0, "hard", "short", 9000 + k)
n_before = len(calls)
quiz.create_topic_quiz("Coulomb's law of force")
strong_msg = next(c["user"] for c in calls[n_before:] if c["system"].startswith("You are an exam setter"))
mix = re.search(r"(\d+) easy, (\d+) medium, (\d+) hard", strong_msg)
assert mix and int(mix.group(3)) >= int(mix.group(1)), mix.group(0)
learner.reset(learner.DEFAULT_STUDENT)
print("9b: setter was told the difficulty mix:", mix.group(0))

# ---------------- 9c. diagnostic quiz: one question per topic ----------------
diag = quiz.create_diagnostic()
sd = quiz.load_set(diag["set_id"])
assert diag["ok"] and sd["kind"] == "diagnostic" and diag["n"] == 5, diag
assert len({q["topic"] for q in sd["questions"]}) == 5, [q["topic"] for q in sd["questions"]]     # five different topics
for q in sd["questions"]:
    quiz.answer_question(q["id"], q["key"]["correct"] if q["qtype"] == "mcq" else "9e-3" if q["qtype"] == "numerical" else "product of charges")
evs = learner.event_count(learner.DEFAULT_STUDENT)
assert evs == 5 and sum(1 for st in learner.all_states() if st["assessed"]) == 5
conn = quiz._conn(); src_kinds = {r[0] for r in conn.execute("SELECT DISTINCT source FROM learner_events")}; conn.close()
assert src_kinds == {"diagnostic"}, src_kinds
print("9c: diagnostic quiz ok:", [q["topic"] for q in sd["questions"]])

# ---------------- 10. the mock exam: exactly five topics, 30 questions ----------------
five = ["1.5 Coulomb's Law", "1.2 Electric Charge", "1.4 Basic Properties", "1.7 Electric Field", "1.9 Dipoles"]
assert not quiz.create_mock_exam(five[:4])["ok"] and not quiz.create_mock_exam(five + ["Exercises"])["ok"]
listing = quiz.available_topics()
assert [t["topic"] for t in listing] == ["1.5 Coulomb's Law", "1.2 Electric Charge", "1.4 Basic Properties",
                                         "1.7 Electric Field", "1.9 Dipoles"], listing    # book order, no examples/summary/exercises
assert listing[0]["pages"] == "3-11" or listing[0]["pages"].count("-") == 1, listing[0]    # section + its worked example
assert listing[0]["concepts"] == "x" and all(t["doc"] == "phys.pdf" for t in listing)
assert len(quiz._chunks_for_topic("1.5 Coulomb's Law")) == 2                              # the section and its example
assert quiz._chunks_for_topic("Exercises") == [] and quiz._chunks_for_topic("Summary") == []
mock = quiz.create_mock_exam(five)
sm = quiz.load_set(mock["set_id"])
print("10: mock exam:", mock["n"], {t: sum(q["topic"] == t for q in sm["questions"]) for t in five})
assert mock["ok"] and mock["n"] == 30 and all(sum(q["topic"] == t for q in sm["questions"]) == 6 for t in five)
texts = [q["question"] for q in sm["questions"]]
assert len(set(texts)) == 30
assert len(quiz.list_sets()) >= 4
# ---------------- 11. marks: MCQ 1, short answer 2 (0 / 1 / 2), numerical 1 ----------------
assert quiz.MARKS == {"mcq": 1, "short": 2, "numerical": 1} and quiz.marks_of("short") == 2 and quiz.marks_of("unknown") == 1
rep_marks = quiz.load_set(res["set_id"])["report"]
sets_now = quiz.load_set(res["set_id"])
expect_total = sum(quiz.marks_of(q["qtype"]) for q in sets_now["questions"])
expect_got = sum(quiz.marks_of(q["qtype"]) * q["answer"]["score"] for q in sets_now["questions"] if q["answer"])
assert rep_marks["marks_total"] == expect_total and abs(rep_marks["marks"] - expect_got) < 1e-9
assert rep_marks["percent"] == round(100 * expect_got / expect_total)
assert sum(t_["marks_asked"] for t_ in rep_marks["topics"]) == expect_total
assert any(q["qtype"] == "short" for q in sets_now["questions"]) and expect_total > len(sets_now["questions"])    # a short answer counts double
print("11: marks ok:", rep_marks["marks"], "/", rep_marks["marks_total"], f"({rep_marks['percent']}%)")

# ---------------- 12. earlier quizzes: per course, oldest first, exact times; delete records ----------------
all_sets = quiz.list_sets()
assert [s_["created"] for s_ in all_sets] == sorted(s_["created"] for s_ in all_sets)                    # oldest first
assert all_sets[0]["created"] <= all_sets[-1]["created"]
done = [s_ for s_ in all_sets if s_["submitted"]]
assert done and all(s_["submitted_at"] and s_["submitted_at"] >= s_["created"] for s_ in done)
assert any(s_["marks_total"] for s_ in done)
assert quiz.list_sets(["a-document-of-another-course.pdf"]) == [] and quiz.list_sets([]) == []
docs_here = sorted({q["doc"] for q in quiz.load_set(all_sets[0]["id"])["questions"]})
assert len(quiz.list_sets(docs_here)) == len(all_sets)
removed = quiz.delete_records(docs_here)
assert removed == len(all_sets) and quiz.list_sets() == [] and quiz.delete_records(docs_here) == 0
print("12: per-course history, exact times, delete records ok:", removed, "quizzes removed")
# ---------------- 13. the checker model judges stand-alone and counts steps; no phrase lists in code ----------------
assert "Standalone: YES or NO" in quiz.CHECKER_SYSTEM and "Steps:" in quiz.CHECKER_SYSTEM
assert "spoken lecture" in quiz.SETTER_SYSTEM and "9e9" not in quiz.CHECKER_SYSTEM and "q_1" not in quiz.SETTER_SYSTEM
assert [quiz.difficulty_from_steps(x) for x in ("1", "Steps: 2", "3 steps", "4", "7")] == ["easy", "medium", "medium", "hard", "hard"]
assert quiz.difficulty_from_steps("") is None and quiz.difficulty_from_steps("many") is None
psg = "Alpha bodies pull on each other. The pull grows with their weights and falls with the square of the gap."
short_draft = {"qtype": "short", "question": "What does the pull depend on?", "options": {}}
base = "Verdict: OK\nEvidence: The pull grows with their weights and falls with the square of the gap.\nReference answer: weights and gap\nKey points: weights; gap\nExplanation: e\nMistake: m"
ok = quiz.parse_check_output("Standalone: YES\nSteps: 2\n" + base, short_draft, psg)
assert ok["ok"] and ok["difficulty"] == "medium"
no = quiz.parse_check_output("Standalone: NO\nSteps: 1\n" + base, short_draft, psg)
assert not no["ok"] and no["reason"] == "the question cannot be understood without the source"
legacy = quiz.parse_check_output(base, short_draft, psg)                         # a checker that omits the new fields is still accepted
assert legacy["ok"] and legacy["difficulty"] is None
# the setter is told why earlier drafts were rejected
seen_user = {}
real_ask_q = quiz.llm.ask
def spy_ask(job, messages, **kw):
    if job == "setter":
        seen_user["text"] = messages[-1]["content"]
    return real_ask_q(job, messages, **kw)
quiz.llm.ask = spy_ask
quiz._write_questions("Topic", [{"doc": "d.pdf", "page_start": 1, "page_end": 1, "heading": "h", "text": psg}], 2, [], None,
                      feedback="the question cannot be understood without the source (x2)")
quiz.llm.ask = real_ask_q
assert "EARLIER DRAFTS WERE REJECTED" in seen_user["text"] and "cannot be understood without the source" in seen_user["text"]
print("13: stand-alone check, step-based difficulty, rejection feedback ok")
print("ALL QUIZ TESTS PASSED")
