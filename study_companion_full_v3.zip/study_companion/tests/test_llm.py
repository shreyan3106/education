"""Tests for the model ladder (src/llm.py) using fake models: no internet or keys needed."""
import os, sys, tempfile, time, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import src.llm as llm

tmp = tempfile.mkdtemp()
llm.DB_PATH = os.path.join(tmp, "t.db")
llm.LADDER_FILE = os.path.join(tmp, "ladders.json")


class Err(Exception):
    def __init__(self, code):
        self.status_code = code


class Reply:
    def __init__(self, text, finish="stop"):
        choice = type("C", (), {"message": type("M", (), {"content": text})(), "finish_reason": finish})()
        self.choices = [choice]
        self.usage = type("U", (), {"total_tokens": 100})()


down, cut, cut_small, calls, limits = set(), set(), set(), [], []


def make_client(provider):
    class Completions:
        def create(self, **kw):
            calls.append(kw["model"])
            limits.append(kw["max_tokens"])
            if kw["model"] in down:
                raise Err(429)
            if kw["model"] in cut:
                return Reply("The force can", "length")
            if kw["model"] in cut_small and kw["max_tokens"] < 1500:        # fine once it has more room
                return Reply("The force can", "length")
            return Reply("reply from " + kw["model"])
    return type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()


def ask(job, text, **kw):
    return llm.ask(job, [{"role": "user", "content": text}], _client=make_client, **kw)


# ---- 1. best first: the first model of each ladder answers when everything works ----
for job in ("answer", "extract", "outline", "setter", "key", "grade", "report"):
    first = llm.LADDERS[job][0][1]
    assert ask(job, "first " + job)["model"] == first, job
assert llm.LADDERS["outline"][0][1] == "nvidia/nemotron-3-super-120b-a12b" and llm.LADDERS["vision"][0][1] == "CohereLabs/command-a-vision-07-2025:cohere"
assert all(len(l) >= 4 for l in llm.LADDERS.values())
# the two tiny live jobs use fast models only; free OpenRouter models stay out of them
assert all(p != "openrouter" for p, _ in llm.LADDERS["rewrite"] + llm.LADDERS["rerank"])
# parked models are still there, as they were
assert ("nvidia", "google/gemma-4-31b-it") in llm.LADDERS["answer"] and ("nvidia", "deepseek-ai/deepseek-v4.1-flash") in llm.LADDERS["answer"]
print("1: best-first ladders ok")

# ---- 2. a rate-limited model is skipped, rests, and the next one answers ----
top = llm.LADDERS["answer"][0][1]
second = llm.LADDERS["answer"][1][1]
down.add(top)
assert ask("answer", "a2")["model"] == second
n = len(calls); ask("answer", "a3")
assert top not in calls[n:], "a resting model must not be called again"
down.clear(); llm._cooldown_until.clear()

# ---- 3. the same question is answered from the cache ----
n = len(calls); r = ask("answer", "a2")
assert r["cached"] and len(calls) == n

# ---- 4. cut-off replies: more room first, then the next model; never a half answer if avoidable ----
llm._cooldown_until.clear(); calls.clear(); limits.clear()
cut_small.add(top)
r = ask("answer", "cut1", max_tokens=1000)
assert r["model"] == top and not r["truncated"], r                    # same model, asked again with a bigger limit
assert limits[:2] == [1000, 1800], limits
cut_small.clear(); cut.add(top)
r = ask("answer", "cut2", max_tokens=1000)
assert r["model"] != top and not r["truncated"]                       # a model that stays cut off is passed over
cut.update({m for _, m in llm.LADDERS["answer"]})
r = ask("answer", "cut3")
assert r["truncated"], "if every model is cut off the text is returned but flagged"
cut.clear(); llm._cooldown_until.clear()
print("4: cut-off handling ok")

# ---- 5. quiz roles: several families can be avoided at once ----
r = ask("grade", "g1", avoid_family={"z-ai", "openai"})
assert llm.family(r["model"]) not in {"z-ai", "openai"}
r = ask("key", "k1", avoid_family="z-ai")
assert llm.family(r["model"]) != "z-ai"
r = ask("check", "c2", avoid_family=["z-ai", "nvidia", "openai", "moonshotai"])
assert llm.family(r["model"]) not in {"z-ai", "nvidia", "openai", "moonshotai"}
assert llm.family("z-ai/glm-5.3") == "z-ai" and llm.family("google/gemma-4-31b-it") == "google"
print("5: multi-family avoid ok")

# ---- 6. vision messages ----
png = b"\x89PNG\r\n\x1a\n" + b"0" * 20
msg = llm.image_message("what is this?", [png])
assert msg["content"][0]["type"] == "text" and msg["content"][1]["image_url"]["url"].startswith("data:image/png;base64,")
seen = {}


def vclient(provider):
    class C:
        def create(self, **kw):
            seen["messages"] = kw["messages"]; seen["model"] = kw["model"]
            return Reply("a diagram of two charges")
    return type("Client", (), {"chat": type("Chat", (), {"completions": C()})()})()


r = llm.ask("vision", [llm.image_message("describe", [png])], _client=vclient)
assert r["model"] == llm.LADDERS["vision"][0][1] and isinstance(seen["messages"][0]["content"], list)
print("6: vision call ok")

# ---- 7. a saved order from the Model check tab wins; new models are appended ----
saved_order = [list(p) for p in reversed(llm.LADDERS["key"])]
json.dump({"key": saved_order}, open(llm.LADDER_FILE, "w"))
assert llm.ladder_for("key")[0] == tuple(saved_order[0]) and llm.ladder_for("answer") == llm.LADDERS["answer"]
json.dump({"key": [["nvidia", "no-such-model"], ["nvidia", "z-ai/glm-5.3"]]}, open(llm.LADDER_FILE, "w"))
assert llm.ladder_for("key")[0] == ("nvidia", "z-ai/glm-5.3") and len(llm.ladder_for("key")) == len(llm.LADDERS["key"])
os.remove(llm.LADDER_FILE)
print("7: saved ladder order ok")

# ---- 8. provider-wide request cap (NVIDIA: requests per minute) ----
llm._cooldown_until.clear()
conn = llm._db()
for _ in range(llm.PROVIDER_LIMITS["nvidia"]["rpm"]):
    conn.execute("INSERT INTO llm_usage VALUES (?,?,?,?)", (time.time(), "nvidia", "google/gemma-4-31b-it", 10))
conn.commit(); conn.close()
assert ask("extract", "e2")["provider"] != "nvidia"

# ---- 9. no key at all: a clear error instead of a crash ----
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY"):
    os.environ.pop(key, None)
try:
    llm.ask("answer", [{"role": "user", "content": "no keys"}])
    raise SystemExit("should have raised AllModelsBusy")
except llm.AllModelsBusy:
    pass


# ---- 10. the three new chat models are in the ladders ----
for pair in (("openrouter", "inclusionai/ling-3.1-flash"), ("openrouter", "apodex/apodex-1.1-mini:free"),
             ("openrouter", "nvidia/nemotron-3-super-120b-a12b:free")):
    assert pair in llm.all_models() and pair in llm.LADDERS["answer"] and pair in llm.LADDERS["outline"], pair
    assert pair not in llm.LADDERS["rewrite"] and pair not in llm.LADDERS["rerank"]
assert llm.family("inclusionai/ling-3.1-flash") == "inclusionai" and llm.family("nvidia/nemotron-3-super-120b-a12b:free") == "nvidia"
print("10: new models ok")

# ---- streaming fakes ----
_c = llm._db(); _c.execute("DELETE FROM llm_usage"); _c.commit(); _c.close()   # forget test 8's usage
llm.START_WAIT, llm.SILENCE_LIMIT = 0.4, 0.4
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY"):
    os.environ[key] = "x"
llm._rest_loaded_for = None; llm._db().close()          # the keys are now 'x': remembered, so a restart with the same keys keeps the rests


class Piece:
    def __init__(self, text=None, finish=None, usage=None):
        delta = type("D", (), {"content": text})()
        self.choices = [type("C", (), {"delta": delta, "finish_reason": finish})()]
        self.usage = usage


class Plan:
    """What a fake model does: a list of ('say', text) / ('wait', seconds) / ('boom', error) steps."""
    def __init__(self, *steps):
        self.steps = steps


plans, seen_messages = {}, []


def stream_client(provider):
    class Completions:
        def create(self, **kw):
            seen_messages.append((kw["model"], kw["messages"]))
            calls.append(kw["model"])
            plan = plans.get(kw["model"])
            if plan is None:
                return Reply("reply from " + kw["model"])          # a whole reply object: also supported

            def gen():
                for kind, arg in plan.steps:
                    if kind == "wait":
                        time.sleep(arg)
                    elif kind == "say":
                        yield Piece(arg)
                    elif kind == "think":
                        yield Piece(None)                           # a thinking piece: alive, no text
                    elif kind == "boom":
                        raise arg
                yield Piece(None, finish="stop")
            return gen()
    return type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()


def sask(job, text, ladder, **kw):
    return llm.ask(job, [{"role": "user", "content": text}], _client=stream_client, ladder=ladder, **kw)


A, B, C = ("nvidia", "slow/model-a"), ("nvidia", "mid/model-b"), ("groq", "fast/model-c")

# ---- 11. a reply that arrives in pieces is put together ----
plans.clear(); llm._cooldown_until.clear()
plans["slow/model-a"] = Plan(("say", "Hello "), ("say", "there."))
r = sask("format", "s1", [A])
assert r["text"] == "Hello there." and r["handovers"] == 0 and r["first_seconds"] >= 0
print("11: streamed pieces ok")

# ---- 12. the 60-second START rule: nothing starts in time -> rests, next model answers ----
plans.clear(); llm._cooldown_until.clear()
plans["slow/model-a"] = Plan(("wait", 1.5), ("say", "too late"))
t0 = time.time()
r = sask("format", "s2", [A, B])
assert r["model"] == "mid/model-b" and time.time() - t0 < 1.2, (r, time.time() - t0)
assert any("no reply within" in a for a in r["attempts"])
assert llm._cooldown_until.get(A, 0) > time.time() + 500            # rests about 10 minutes
conn = llm._db(); row = conn.execute("SELECT until FROM llm_rest WHERE model=?", (A[1],)).fetchone(); conn.close()
assert row and row[0] > time.time() + 500, "the rest must be saved in SQLite"
llm._cooldown_until.clear(); llm._rest_loaded_for = None            # simulate a restart of the app
conn = llm._db(); conn.close()
assert llm._cooldown_until.get(A, 0) > time.time() + 500, "a restart must not forget the rest"
print("12: start rule + saved rest ok")

# ---- 13. NO total time limit while a model keeps answering ----
plans.clear(); llm._cooldown_until.clear()
plans["slow/model-a"] = Plan(*[step for i in range(8) for step in (("say", f"w{i} "), ("wait", 0.15))])   # about 1.2 s in total > START_WAIT
t0 = time.time()
r = sask("format", "s3", [A, B])
assert r["model"] == "slow/model-a" and time.time() - t0 > 1.0 and r["text"].startswith("w0 w1"), r
print("13: slow but answering = no cap ok")

# ---- 14. thinking pieces count as 'started' ----
plans.clear(); llm._cooldown_until.clear()
plans["slow/model-a"] = Plan(("think", None), ("wait", 0.3), ("think", None), ("wait", 0.3), ("think", None), ("say", "Answer."))
r = sask("format", "s4", [A, B])
assert r["model"] == "slow/model-a" and r["text"] == "Answer."
print("14: thinking counts ok")

# ---- 15. silence in the middle of a reply -> hand over; the next model is the FASTEST and CONTINUES the text ----
plans.clear(); llm._cooldown_until.clear(); seen_messages.clear()
first_part = ("The Constitution of India came into force on 26 January 1950, replacing the Government of India Act 1935 as the "
              "governing document of the country, and it is ")
plans["slow/model-a"] = Plan(("say", first_part), ("wait", 1.5), ("say", "never seen"))
plans["fast/model-c"] = Plan(("say", "the longest written constitution."))
t0 = time.time()
r = sask("answer", "s5 what is the constitution", [A, B, C])
assert r["model"] == "fast/model-c", r                              # B comes before C in the ladder, C is faster
assert r["handovers"] == 1 and time.time() - t0 < 1.4
assert r["text"].startswith("The Constitution of India came into force on 26 January 1950") and r["text"].endswith("the longest written constitution.")
msgs = [m for model, m in seen_messages if model == "fast/model-c"][0]
assert msgs[0]["content"].startswith("s5") and msgs[1]["role"] == "assistant" and msgs[1]["content"].startswith("The Constitution of India")
assert msgs[2]["role"] == "user" and "Continue" in msgs[2]["content"], msgs
assert not any(model == "mid/model-b" for model, _ in seen_messages), "the fastest model must go first after a break"
print("15: silence -> hand-over to the fastest, text continued, context kept ok")

# ---- 16. an error in the middle of a reply is handed over at once (no waiting) ----
plans.clear(); llm._cooldown_until.clear(); seen_messages.clear()
plans["slow/model-a"] = Plan(("say", "x" * 150 + " and then "), ("boom", ConnectionError("dropped")))
t0 = time.time()
r = sask("report", "s6", [A, C])
assert r["model"] == "fast/model-c" and time.time() - t0 < 0.5 and r["handovers"] == 1
assert r["text"].startswith("x" * 150)
print("16: connection error mid-reply -> instant hand-over ok")

# ---- 17. a strict-format job starts the SAME task again instead of continuing (same context) ----
plans.clear(); llm._cooldown_until.clear(); seen_messages.clear()
plans["slow/model-a"] = Plan(("say", '{"a": 1, "b": ' + "9" * 150), ("wait", 1.5))
plans["fast/model-c"] = Plan(("say", '{"a": 1, "b": 2}'))
r = sask("extract", "s7 give json", [A, C])
assert r["text"] == '{"a": 1, "b": 2}', r
msgs = [m for model, m in seen_messages if model == "fast/model-c"][0]
assert len(msgs) == 1 and msgs[0]["content"] == "s7 give json", msgs
print("17: strict job restarts with the same messages ok")

# ---- 18. a partial reply that is too short is not continued ----
plans.clear(); llm._cooldown_until.clear(); seen_messages.clear()
plans["slow/model-a"] = Plan(("say", "The force"), ("wait", 1.5))
plans["fast/model-c"] = Plan(("say", "Charges attract or repel."))
r = sask("answer", "s8", [A, C])
msgs = [m for model, m in seen_messages if model == "fast/model-c"][0]
assert r["text"] == "Charges attract or repel." and len(msgs) == 1
print("18: short partial not continued ok")

# ---- 19. joining texts ----
assert llm._join("The force between two charges can", "force between two charges can be attractive") == "The force between two charges can be attractive"
assert llm._join("It can", "can be so") == "It can can be so"          # short overlaps are left alone
assert llm._join("one two ", "three") == "one two three" and llm._join("A.", "B.") == "A. B." and llm._join("", " x ") == "x"
assert llm._trim_tail("the force is attrac") == "the force is " and llm._trim_tail("done.") == "done."
print("19: joining ok")

# ---- 20. every model silent: AllModelsBusy lists why; a partial text is returned flagged ----
plans.clear(); llm._cooldown_until.clear()
plans["slow/model-a"] = Plan(("say", "y" * 200), ("wait", 1.5))
r = sask("answer", "s9", [A])
assert r["truncated"] and r["text"].startswith("y" * 150), r
plans["mid/model-b"] = Plan(("wait", 1.5))
llm._cooldown_until.clear()
try:
    sask("extract", "s10", [B])
    raise SystemExit("should have raised AllModelsBusy")
except llm.AllModelsBusy as e:
    assert "no reply within" in str(e)
print("20: all fail ok")

# ---- 21. rerank fallback through the rerank endpoint ----
llm._cooldown_until.clear()
posted = {}


def fake_post(url, headers, body, timeout):
    posted.update(url=url, body=body, timeout=timeout, auth=headers["Authorization"])
    return {"results": [{"index": 2, "relevance_score": 0.9}, {"index": 0, "relevance_score": 0.2}, {"index": 1, "relevance_score": 0.5}]}


ranked = llm.rerank_api("what is a writ", ["a", "b", "c"], top_n=2, _post=fake_post)
assert [i for i, _ in ranked] == [2, 1, 0] and posted["url"].endswith("/rerank") and posted["body"]["model"] == llm.RERANK_MODEL
assert posted["body"]["top_n"] == 2 and posted["timeout"] == llm.START_WAIT and posted["auth"] == "Bearer x"


def bad_post(url, headers, body, timeout):
    raise Err(429)


try:
    llm.rerank_api("q", ["a", "b"], _post=bad_post)
    raise SystemExit("should have raised")
except llm.AllModelsBusy:
    pass
try:                                                                  # now it rests
    llm.rerank_api("q", ["a", "b"], _post=fake_post)
    raise SystemExit("should be resting")
except llm.AllModelsBusy as e:
    assert "resting" in str(e)
llm._cooldown_until.clear()
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY"):
    os.environ.pop(key, None)
try:
    llm.rerank_api("q", ["a"])
    raise SystemExit("no key must raise")
except llm.AllModelsBusy:
    pass
print("21: rerank fallback ok")

# ---- 22. measured speed decides the order after a break ----
conn = llm._db()
for _ in range(3):
    conn.execute("INSERT INTO llm_speed VALUES (?,?,?,?,?,?)", (time.time(), "nvidia", "mid/model-b", 40.0, 90.0, 500))
    conn.execute("INSERT INTO llm_speed VALUES (?,?,?,?,?,?)", (time.time(), "nvidia", "other/model-d", 0.5, 2.0, 500))
order = llm._fastest_first(conn, [("nvidia", "mid/model-b"), ("nvidia", "other/model-d"), ("groq", "fast/model-c")])
conn.close()
assert order[0] == ("nvidia", "other/model-d") or order[0] == ("groq", "fast/model-c"), order
assert order[-1] == ("nvidia", "mid/model-b"), order
print("22: measured speed order ok")


# ---- 23. Hugging Face provider: a vision backup, rests for hours when its credits run out (402) ----
assert llm.PROVIDERS["huggingface"]["base_url"] == "https://router.huggingface.co/v1" and llm.PROVIDERS["huggingface"]["key_env"] == "HF_TOKEN"
hf_pairs = [p for p in llm.all_models() if p[0] == "huggingface"]
assert len(hf_pairs) == len(llm.HF_MODELS) >= 4 and all(p in llm.LADDERS["vision"] for p in hf_pairs)
assert all(p not in llm.LADDERS["answer"] and p not in llm.LADDERS["rerank"] for p in hf_pairs)
os.environ.pop("HF_TOKEN", None); os.environ["HUGGINGFACE_HUB_TOKEN"] = "tok"
assert llm._api_key("huggingface") == "tok"
os.environ.pop("HUGGINGFACE_HUB_TOKEN")
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"):
    os.environ[key] = "x"
llm._cooldown_until.clear()
calls.clear()
hf_first = llm.LADDERS["vision"][0]


def hf_client(provider):
    class Completions:
        def create(self, **kw):
            calls.append((provider, kw["model"]))
            if provider == "huggingface":
                raise Err(402)
            return Reply("seen: a circle")
    return type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()


r = llm.ask("vision", [{"role": "user", "content": "describe v1"}], _client=hf_client)
assert r["provider"] != "huggingface" and "credits used up" in " ".join(r["attempts"]), r["attempts"]
assert all(llm._cooldown_until.get(p, 0) > time.time() + 5 * 3600 for p in hf_pairs), "all Hugging Face models must rest for hours"
n_calls = len(calls)
r = llm.ask("vision", [{"role": "user", "content": "describe v2"}], _client=hf_client)
assert not any(p == "huggingface" for p, _ in calls[n_calls:]), "must not ask Hugging Face again while it rests"
llm._cooldown_until.clear()
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"):
    os.environ.pop(key, None)
print("23: Hugging Face backup ok")


# ---- 24. a bad key must not lock the models for an hour; a new key clears old rests; setup tools ----
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"):
    os.environ[key] = "badkey"
llm._cooldown_until.clear()
llm._rest_loaded_for = None; llm._db().close()          # remember the bad keys as 'the keys of this run'
calls.clear()


def refused_client(provider):
    class Completions:
        def create(self, **kw):
            calls.append((provider, kw["model"]))
            raise Err(401)
    return type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()


try:
    llm.ask("extract", [{"role": "user", "content": "refused 1"}], _client=refused_client)
    raise SystemExit("should have failed")
except llm.AllModelsBusy:
    pass
left = [s_ for _, _, s_ in llm.rest_report()]
assert left and max(left) <= llm.AUTH_REST, "a refused key may rest for minutes, never an hour"
# the key is fixed: a different key value wipes the saved rests of that provider
llm._rest_loaded_for = None
os.environ["GROQ_API_KEY"] = "goodkey"
conn = llm._db(); conn.close()
assert not [1 for p, _, _ in llm.rest_report() if p == "groq"] and [1 for p, _, _ in llm.rest_report() if p == "nvidia"]
# the button: forget every rest
assert llm.clear_rests() > 0 and llm.rest_report() == []
conn = llm._db(); assert conn.execute("SELECT COUNT(*) FROM llm_rest").fetchone()[0] == 0; conn.close()


def ping_client(provider):
    class Completions:
        def create(self, **kw):
            if provider == "groq":
                return Reply("OK")
            if provider == "nvidia":
                raise Err(401)
            raise ConnectionError("blocked")
    return type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()


d = llm.diagnose(_client=ping_client)
assert d["groq"]["ok"] and not d["nvidia"]["ok"] and "refused" in d["nvidia"]["problem"] and "Wi-Fi" in d["openrouter"]["problem"]
assert llm.rest_report() == [], "diagnose must not change any rest"
assert "no reply within" in llm.explain_error(llm.StartTimeout("x")) and "credits" in llm.explain_error(Err(402))
for key in ("NVIDIA_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"):
    os.environ.pop(key, None)
llm._cooldown_until.clear()
print("24: bad keys do not lock models, new key clears rests, diagnose ok")

assert llm.parse_labeled_lines("Concepts: a; b\nPrerequisites: x") == {"concepts": ["a", "b"], "prerequisites": ["x"]}
assert ("nvidia", "z-ai/glm-5.3") in llm.all_models() and ("openrouter", "thinkingmachines/inkling-small:free") in llm.all_models()
print("ALL LLM TESTS PASSED")
