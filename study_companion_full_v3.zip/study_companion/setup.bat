@echo off
rem One-time setup. Double-click this file. It always works from ITS OWN folder, so the "wrong folder" problem cannot happen.
cd /d "%~dp0"
echo ============================================================
echo  Study Companion: one-time setup (takes several minutes)
echo ============================================================
set PY=python
where python >nul 2>nul || set PY=py
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo.
  echo PROBLEM: Python was not found. Install Python 3.12 from python.org and TICK "Add python.exe to PATH" in the installer, then run this again.
  pause
  exit /b 1
)
echo Using:
%PY% --version
if exist venv\Scripts\python.exe (
  venv\Scripts\python.exe -c "import sys" >nul 2>nul || %PY% -m venv venv --clear
) else (
  %PY% -m venv venv
)
if not exist venv\Scripts\activate.bat (
  echo PROBLEM: the virtual environment could not be created.
  pause
  exit /b 1
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python download_embedding_model.py
echo.
python check_setup.py
echo.
echo When nothing above is marked PROBLEM, double-click run.bat to start the app.
pause
