"""
Run this FIRST on a new computer, from the project folder:

    python check_setup.py

It checks, in plain words: the folder, Python, the virtual environment, the packages, the .env file, the embedding
model and every API key (one tiny real call each). It never prints your keys. Fix what it marks PROBLEM, then run it
again until nothing is marked PROBLEM. Then start the app with:

    python -m streamlit run app.py
"""
import importlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
problems = []


def ok(text):
    print(f"  OK       {text}")


def warn(text):
    print(f"  CHECK    {text}")


def bad(text, fix):
    print(f"  PROBLEM  {text}")
    print(f"           -> {fix}")
    problems.append(text)


print("\n== 1. The project folder ==")
print(f"  This file is in: {HERE}")
missing = [f for f in ("app.py", "requirements.txt", os.path.join("src", "llm.py")) if not os.path.exists(os.path.join(HERE, f))]
if missing:
    bad(f"These files are missing from the folder: {', '.join(missing)}",
        "You are probably in the wrong (outer) folder. Open the folder that directly contains app.py in VS Code "
        "(File > Open Folder), then open a new terminal.")
else:
    ok("app.py, requirements.txt and src\\llm.py are here")
if os.path.abspath(os.getcwd()) != HERE:
    warn(f"Your terminal is in {os.getcwd()}, not here. Type:  cd \"{HERE}\"  and run the commands from there.")

print("\n== 2. Python and the virtual environment ==")
v = sys.version_info
print(f"  Python {v.major}.{v.minor}.{v.micro}  ({sys.executable})")
if (v.major, v.minor) < (3, 10) or (v.major, v.minor) > (3, 12):
    warn("Python 3.11 or 3.12 is the safe choice for this project (newer versions may miss some packages).")
else:
    ok("Python version is fine")
in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
if not in_venv:
    warn("No virtual environment is active. That can work, but the clean way is:  python -m venv venv   then   venv\\Scripts\\activate.bat")
elif not os.path.abspath(sys.prefix).lower().startswith(HERE.lower()):
    bad(f"The active virtual environment belongs to another folder: {sys.prefix}",
        "Type  deactivate  then  python -m venv venv  then  venv\\Scripts\\activate.bat  and  python -m pip install -r requirements.txt  "
        "inside THIS folder.")
else:
    ok("The virtual environment is this project's own")

print("\n== 3. Packages ==")
PACKAGES = [("streamlit", "streamlit"), ("fitz", "pymupdf"), ("openai", "openai"), ("dotenv", "python-dotenv"),
            ("numpy", "numpy"), ("sentence_transformers", "sentence-transformers"), ("rank_bm25", "rank-bm25"),
            ("pptx", "python-pptx"), ("youtube_transcript_api", "youtube-transcript-api"), ("yt_dlp", "yt-dlp"),
            ("PIL", "pillow"), ("imageio_ffmpeg", "imageio-ffmpeg")]
missing_pkgs = []
for module, pip_name in PACKAGES:
    try:
        importlib.import_module(module)
    except Exception:
        missing_pkgs.append(pip_name)
if missing_pkgs:
    bad("Not installed in this environment: " + ", ".join(missing_pkgs),
        "Run:  python -m pip install -r requirements.txt   (use 'python -m pip', so the right pip is used)")
else:
    ok("All packages are installed")
try:
    importlib.import_module("faiss")
    ok("faiss is installed (fast search)")
except Exception:
    warn("faiss is not installed: the app still works with a built-in search, only slower on big books.")

print("\n== 4. The .env file (your keys) ==")
env_path = os.path.join(HERE, ".env")
KEYS = ["GROQ_API_KEY", "NVIDIA_API_KEY", "OPENROUTER_API_KEY", "HF_TOKEN"]
values = {}
if not os.path.exists(env_path):
    if os.path.exists(env_path + ".txt"):
        bad("The file is called .env.txt (Windows hides the .txt)",
            "Rename it to exactly .env  (in File Explorer: View > Show > File name extensions, then rename).")
    else:
        bad("There is no .env file in this folder",
            "Copy .env.example to a new file named exactly .env and paste your keys after the = signs.")
else:
    ok(f".env found: {env_path}")
    with open(env_path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, val = line.partition("=")
                values[k.strip()] = val
    for k in KEYS:
        val = values.get(k, "")
        if not val.strip():
            print(f"  empty    {k}")
        elif val != val.strip() or val.strip()[0] in "\"'" or " " in val.strip():
            bad(f"{k} has a quote or a space around it", "Write it as KEY=value with nothing else on the line: no quotes, no spaces.")
        else:
            ok(f"{k} is set ({len(val.strip())} characters)")
    if not any(values.get(k, "").strip() for k in KEYS):
        bad("No key is filled in", "Paste at least one key (Groq or NVIDIA is enough to start).")

print("\n== 5. The embedding model ==")
cache = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")
cache = os.environ.get("HF_HUB_CACHE", os.environ.get("HF_HOME", cache))
if os.path.isdir(cache) and any("bge-small" in d or "MiniLM" in d for d in os.listdir(cache)):
    ok("An embedding model is already downloaded")
else:
    warn("The embedding model is not downloaded yet. Run once:  python download_embedding_model.py  (about 130 MB)")

print("\n== 6. Do the keys work? (one tiny real request per provider, ~20 seconds) ==")
if os.path.exists(os.path.join(HERE, "src", "llm.py")):
    sys.path.insert(0, HERE)
    try:
        from src import llm
        results = llm.diagnose()
        any_ok = False
        for name, r in results.items():
            if not r["key"]:
                print(f"  empty    {name}: no key set")
            elif r["ok"]:
                any_ok = True
                ok(f"{name}: works ({r['seconds']} s)")
            else:
                bad(f"{name}: {r['problem']}", "Fix this key (or the network), run this check again.")
        if not any_ok and any(r["key"] for r in results.values()):
            bad("No provider answered", "If the keys are right, the Wi-Fi may block these services: try a phone hotspot.")
        resting = llm.rest_report()
        if resting:
            warn(f"{len(resting)} models are 'resting' after earlier failures. They wake up by themselves; the Model check tab "
                 f"has a button to forget the rests now.")
    except Exception as e:
        bad(f"Could not run the key check: {type(e).__name__}: {e}", "Fix the packages above first, then run this again.")
else:
    print("  skipped (src folder not found)")

print("\n" + "=" * 60)
if problems:
    print(f"{len(problems)} PROBLEM(S) above. Fix them in order, then run:  python check_setup.py")
else:
    print("Everything looks fine. Start the app with:   python -m streamlit run app.py")
